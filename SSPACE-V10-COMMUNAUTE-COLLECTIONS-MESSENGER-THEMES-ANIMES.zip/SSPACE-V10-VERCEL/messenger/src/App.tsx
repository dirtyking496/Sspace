import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { MessageCircle, Search, Settings, Phone, Video, Plus, Send, Paperclip, Smile, LogOut, ShieldCheck, ArrowLeft, CheckCheck, ExternalLink, Bell, Mic, MicOff, VideoOff, PhoneOff, Minimize2, Maximize2 } from 'lucide-react';

type Profile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null; last_seen_at?: string | null; show_online?: boolean | null };
type Conversation = { id: string; user_one: string; user_two: string; updated_at: string; other?: Profile; last_message?: Message | null; unread_count?: number };
type Message = { id: string; conversation_id: string; sender_id: string; body: string; created_at: string; read_at: string | null; message_type?: string; media_path?: string | null; link_url?: string | null };
type CallKind = 'audio' | 'video';
type CallState = {
  callId: string; peerId: string; peerName: string; peerAvatar: string; mediaType: CallKind;
  role: 'caller' | 'callee'; phase: 'ringing-in' | 'ringing-out' | 'connecting' | 'active';
  pc: RTCPeerConnection | null; localStream: MediaStream | null; remoteStream: MediaStream | null;
  pendingIce: RTCIceCandidateInit[]; startedAt: number | null; muted: boolean; cameraEnabled: boolean; minimized: boolean;
};

const STUN_SERVERS: RTCIceServer[] = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }
];
const turnUrls = (import.meta.env.VITE_TURN_URLS as string | undefined)?.split(',').map(v => v.trim()).filter(Boolean) ?? [];
if (turnUrls.length) STUN_SERVERS.push({ urls: turnUrls, username: import.meta.env.VITE_TURN_USERNAME as string | undefined, credential: import.meta.env.VITE_TURN_CREDENTIAL as string | undefined });
const RING_TIMEOUT_MS = 45_000;

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState(''); const [notice, setNotice] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]); const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]); const [draft, setDraft] = useState(''); const [search, setSearch] = useState('');
  const [profile, setProfile] = useState<Profile | null>(null); const [showMobileChat, setShowMobileChat] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem('sspace-messenger-theme') || 'ocean');
  const [animations, setAnimations] = useState(() => localStorage.getItem('sspace-messenger-animations') !== 'off');
  const [showAppearance, setShowAppearance] = useState(false);
  useEffect(() => { localStorage.setItem('sspace-messenger-theme', theme); }, [theme]);
  useEffect(() => { localStorage.setItem('sspace-messenger-animations', animations ? 'on' : 'off'); }, [animations]);
  const [unreadTotal, setUnreadTotal] = useState(0); const [call, setCall] = useState<CallState | null>(null); const [recording,setRecording]=useState(false); const [uploading,setUploading]=useState(false); const fileRef=useRef<HTMLInputElement|null>(null); const recorderRef=useRef<MediaRecorder|null>(null);
  const callRef = useRef<CallState | null>(null); const callSeen = useRef(new Set<string>());
  const callTimeoutRef = useRef<number | null>(null); const callClockRef = useRef<number | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null); const remoteVideoRef = useRef<HTMLVideoElement | null>(null); const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const activeConversation = conversations.find(c => c.id === activeId) ?? null;
  const filtered = useMemo(() => conversations.filter(c => (c.other?.display_name ?? c.other?.username ?? '').toLowerCase().includes(search.toLowerCase())), [conversations, search]);

  const publishCall = (next: CallState | null) => { callRef.current = next; setCall(next ? { ...next } : null); };
  const isCurrentCall = (id: string) => callRef.current?.callId === id;

  useEffect(() => {
    if (!supabase || !window.opener) return;
    const nonce = new URLSearchParams(window.location.search).get('sspace_link_nonce');
    if (!nonce) return;
    const socialOrigin = window.location.origin;
    const receiveSession = async (event: MessageEvent) => {
      if (event.origin !== socialOrigin || event.source !== window.opener || event.data?.type !== 'SSPACE_SESSION' || event.data?.nonce !== nonce) return;
      const sessionData = event.data.session;
      if (!sessionData?.access_token || !sessionData?.refresh_token) return;
      const { error } = await supabase!.auth.setSession({ access_token: sessionData.access_token, refresh_token: sessionData.refresh_token });
      if (error) setAuthError('La liaison automatique a échoué : ' + error.message);
      else { window.history.replaceState({}, document.title, window.location.pathname); setNotice('Compte SSpace connecté automatiquement.'); }
      window.removeEventListener('message', receiveSession);
    };
    window.addEventListener('message', receiveSession);
    window.opener.postMessage({ type: 'SSPACE_MESSENGER_READY', nonce }, socialOrigin);
    return () => window.removeEventListener('message', receiveSession);
  }, []);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    supabase.auth.getSession().then(({data}) => { setSession(data.session); setAuthLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadConversations() {
    if (!supabase || !session) return;
    const me = session.user.id;
    const { data: rows, error } = await supabase.from('conversations').select('id,user_one,user_two,updated_at').or(`user_one.eq.${me},user_two.eq.${me}`).order('updated_at', {ascending:false});
    if (error) { setNotice('Chargement des conversations impossible : ' + error.message); return; }
    const convs = rows ?? [];
    if (!convs.length) { setConversations([]); setUnreadTotal(0); return; }
    const otherIds = [...new Set(convs.map((c:any) => c.user_one === me ? c.user_two : c.user_one))];
    const ids = convs.map((c:any) => c.id);
    const [{data: people}, {data: recent}, {data: unread}] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').in('id', otherIds),
      supabase.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').in('conversation_id', ids).order('created_at',{ascending:false}).limit(Math.min(500, Math.max(100, ids.length * 10))),
      supabase.from('messages').select('id,conversation_id').in('conversation_id', ids).neq('sender_id', me).is('read_at', null)
    ]);
    const personMap = new Map((people ?? []).map((p:any) => [p.id, p]));
    const latest = new Map<string, Message>();
    (recent ?? []).forEach((m:any) => { if (!latest.has(m.conversation_id)) latest.set(m.conversation_id, m); });
    const unreadMap = new Map<string, number>();
    (unread ?? []).forEach((m:any) => unreadMap.set(m.conversation_id, (unreadMap.get(m.conversation_id) ?? 0) + 1));
    const enriched: Conversation[] = convs.map((c:any) => ({...c, other:personMap.get(c.user_one === me ? c.user_two : c.user_one), last_message:latest.get(c.id) ?? null, unread_count:unreadMap.get(c.id) ?? 0}));
    enriched.sort((a,b) => Date.parse(b.last_message?.created_at ?? b.updated_at) - Date.parse(a.last_message?.created_at ?? a.updated_at));
    setConversations(enriched); setUnreadTotal(enriched.reduce((n,c) => n + (c.unread_count ?? 0), 0));
  }

  useEffect(() => {
    if (!session || !supabase) { setProfile(null); setConversations([]); setUnreadTotal(0); return; }
    let alive = true;
    supabase.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').eq('id', session.user.id).maybeSingle().then(({data}) => { if (alive && data) setProfile(data as Profile); });
    loadConversations();
    const channel = supabase.channel('sspace-messenger-inbox').on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},payload=>{if(alive){loadConversations();if(payload.new?.sender_id!==session.user.id&&document.visibilityState==='hidden'&&'Notification' in window&&Notification.permission==='granted')new Notification('SSpace Messenger',{body:'Nouveau message reçu'});}}).subscribe();
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') loadConversations(); }, 15000);
    return () => { alive=false; window.clearInterval(timer); supabase?.removeChannel(channel); };
  }, [session]);

  async function markConversationRead(id: string) {
    if (!supabase || !session) return;
    const { error } = await supabase.from('messages').update({read_at:new Date().toISOString()}).eq('conversation_id',id).neq('sender_id',session.user.id).is('read_at',null);
    if (error) setNotice('Les messages sont ouverts, mais leur état de lecture n’a pas pu être synchronisé : ' + error.message);
    await loadConversations();
  }

  useEffect(() => {
    if (!activeId || !supabase || !session) { setMessages([]); return; }
    let alive=true;
    const load = async () => {
      const {data,error}=await supabase!.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').eq('conversation_id',activeId).order('created_at',{ascending:true}).limit(300);
      if (!error && alive) { setMessages((data??[]) as Message[]); await markConversationRead(activeId); }
      else if(error && alive) setNotice('Messages indisponibles : '+error.message);
    };
    load();
    const channel=supabase.channel(`sspace-messenger-chat-${activeId}`).on('postgres_changes',{event:'*',schema:'public',table:'messages',filter:`conversation_id=eq.${activeId}`},()=>load()).subscribe();
    return ()=>{alive=false;supabase?.removeChannel(channel);};
  },[activeId,session]);

  async function authenticate(e:FormEvent) { e.preventDefault(); setAuthError(''); setNotice(''); if(!supabase)return; const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) setAuthError(error.message); }
  async function sendMessage(e:FormEvent) { e.preventDefault(); const body=draft.trim(); if(!body||!activeId||!session||!supabase)return; setDraft(''); const {error}=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body,message_type:'text'}); if(error){setDraft(body);setNotice('Message non envoyé : '+error.message);} }
  async function sendFile(file:File,type:string){if(!supabase||!session||!activeId)return;if(file.size>25*1024*1024){setNotice('Limite de fichier : 25 Mo.');return;}setUploading(true);try{const path=`${session.user.id}/${activeId}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;const up=await supabase.storage.from('chat-attachments').upload(path,file,{contentType:file.type||'application/octet-stream'});if(up.error)throw up.error;const m=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body:type==='voice'?'Message vocal':type==='image'?'Photo':'Fichier joint',message_type:type,media_path:path});if(m.error)throw m.error;}catch(err){setNotice('Échec du fichier : '+(err instanceof Error?err.message:'erreur'));}finally{setUploading(false);}}
  async function recordVoice(){if(recording){recorderRef.current?.stop();setRecording(false);return;}try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});const rec=new MediaRecorder(stream);recorderRef.current=rec;const chunks:BlobPart[]=[];rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};rec.onstop=()=>{stream.getTracks().forEach(t=>t.stop());const blob=new Blob(chunks,{type:rec.mimeType||'audio/webm'});if(blob.size)void sendFile(new File([blob],`vocal-${Date.now()}.webm`,{type:blob.type}),'voice');};rec.start();setRecording(true);}catch(e){setNotice('Accès au micro impossible : '+(e instanceof Error?e.message:''));}}
  async function signOut(){ if(callRef.current) endCall(false); await supabase?.auth.signOut();setActiveId(null);setShowMobileChat(false); }
  async function createConversation(){
    if(!supabase||!session)return;
    const username=window.prompt('Nom d’utilisateur SSpace de la personne à contacter'); if(!username)return;
    const normalized=username.trim().replace(/^@/, '').toLowerCase(); if(!normalized)return;
    const {data:target,error:lookupError}=await supabase.from('profiles').select('id').ilike('username',normalized).maybeSingle();
    if(lookupError||!target){setNotice(lookupError?.message??'Utilisateur introuvable.');return;}
    const {data:friendship,error:friendError}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${session.user.id},receiver_id.eq.${target.id}),and(sender_id.eq.${target.id},receiver_id.eq.${session.user.id})`).maybeSingle();
    if(friendError||!friendship){setNotice('Vous devez être amis sur SSpace pour démarrer une conversation.');return;}
    const pair=[session.user.id,target.id].sort();
    let {data:existing,error}=await supabase.from('conversations').select('id,user_one,user_two').eq('user_one',pair[0]).eq('user_two',pair[1]).maybeSingle();
    if(error){setNotice('Recherche de conversation impossible : '+error.message);return;}
    if(!existing){const created=await supabase.from('conversations').insert({user_one:pair[0],user_two:pair[1]}).select('id,user_one,user_two').single(); existing=created.data; error=created.error;}
    if(error||!existing){setNotice('Création impossible : '+(error?.message??'erreur inconnue'));return;}
    await loadConversations(); setActiveId(existing.id); setShowMobileChat(true);
  }

  function callSupported() { return typeof navigator.mediaDevices?.getUserMedia === 'function' && typeof window.RTCPeerConnection === 'function'; }
  async function areFriends(peerId: string) {
    if (!supabase || !session) return false;
    const me=session.user.id;
    const {data,error}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${me},receiver_id.eq.${peerId}),and(sender_id.eq.${peerId},receiver_id.eq.${me})`).maybeSingle();
    return !error && Boolean(data);
  }
  async function sendCallSignal(kind: string, payload: Record<string,unknown>, to: string, callId: string) {
    if (!supabase || !session || !to || !callId) return false;
    const {error}=await supabase.from('call_signals').insert({call_id:callId,sender_id:session.user.id,receiver_id:to,kind,payload});
    if(error){console.error('WebRTC signal error',kind,error);setNotice(/call_signals|relation|schema cache/i.test(error.message)?'Les appels ne sont pas activés dans Supabase : applique la migration SQL call_signals.':'Signal d’appel impossible : '+error.message);return false;}
    return true;
  }
  function clearCallTimers(){ if(callTimeoutRef.current!==null)window.clearTimeout(callTimeoutRef.current); if(callClockRef.current!==null)window.clearInterval(callClockRef.current); callTimeoutRef.current=null;callClockRef.current=null; }
  function endCall(notifyPeer: boolean, message?: string) {
    const st=callRef.current; if(!st)return;
    clearCallTimers();
    if(notifyPeer) void sendCallSignal('hangup',{},st.peerId,st.callId);
    try{st.pc?.close();}catch{}
    st.localStream?.getTracks().forEach(track=>track.stop());
    if(localVideoRef.current)localVideoRef.current.srcObject=null;
    if(remoteVideoRef.current)remoteVideoRef.current.srcObject=null;
    if(remoteAudioRef.current)remoteAudioRef.current.srcObject=null;
    publishCall(null);
    if(message)setNotice(message);
  }
  async function makePeer(st: CallState) {
    if(st.pc)return st.pc;
    const pc=new RTCPeerConnection({iceServers:STUN_SERVERS}); st.pc=pc;
    st.localStream?.getTracks().forEach(track=>pc.addTrack(track,st.localStream!));
    pc.onicecandidate=e=>{if(e.candidate)void sendCallSignal('ice',{candidates:[e.candidate.toJSON()]},st.peerId,st.callId);};
    pc.ontrack=e=>{
      const stream=e.streams?.[0]??new MediaStream([e.track]); st.remoteStream=stream; publishCall(st);
      if(st.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=stream;void remoteVideoRef.current.play().catch(()=>{});}
      if(remoteAudioRef.current){remoteAudioRef.current.srcObject=stream;void remoteAudioRef.current.play().catch(()=>{});}
    };
    pc.onconnectionstatechange=()=>{
      if(callRef.current?.callId!==st.callId)return;
      if(pc.connectionState==='connected'){
        st.phase='active';st.startedAt=Date.now();publishCall(st);clearCallTimers();
        callClockRef.current=window.setInterval(()=>{const latest=callRef.current;if(latest?.callId===st.callId)publishCall({...latest});},1000);
      } else if(pc.connectionState==='failed') endCall(true,'Connexion WebRTC échouée. Un serveur TURN peut être nécessaire sur ce réseau.');
      else if(pc.connectionState==='disconnected') { window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&pc.connectionState!=='connected')endCall(true,'Connexion interrompue.');},9000); }
    };
    publishCall(st); return pc;
  }
  async function startCall(mediaType: CallKind) {
    if(!session||!activeConversation?.other||!supabase)return;
    if(!callSupported()){setNotice('Ce navigateur ne prend pas en charge les appels WebRTC. Utilise HTTPS et autorise le micro/la caméra.');return;}
    if(callRef.current){setNotice('Un appel est déjà en cours.');return;}
    const peer=activeConversation.other;
    if(!(await areFriends(peer.id))){setNotice('Les appels sont réservés aux amis SSPACE acceptés.');return;}
    const st:CallState={callId:crypto.randomUUID(),peerId:peer.id,peerName:peer.display_name??peer.username??'Membre SSPACE',peerAvatar:peer.avatar_url??'',mediaType,role:'caller',phase:'ringing-out',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
    publishCall(st);
    try{st.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:mediaType==='video'?{facingMode:'user',width:{ideal:1280},height:{ideal:720}}:false});}
    catch(err){publishCall(null);setNotice(err instanceof Error?`Accès au ${mediaType==='video'?'micro et à la caméra':'micro'} refusé : ${err.message}`:'Impossible d’accéder au micro ou à la caméra.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    const ok=await sendCallSignal('invite',{mediaType},st.peerId,st.callId);
    if(!ok){endCall(false);return;}
    callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-out'){void sendCallSignal('hangup',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Pas de réponse.');}},RING_TIMEOUT_MS);
  }
  async function acceptCall() {
    const st=callRef.current;if(!st||st.phase!=='ringing-in')return;
    clearCallTimers();st.phase='connecting';publishCall(st);
    try{st.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:st.mediaType==='video'?{facingMode:'user',width:{ideal:1280},height:{ideal:720}}:false});}
    catch(err){await sendCallSignal('reject',{reason:'media-permission'},st.peerId,st.callId);endCall(false,err instanceof Error?`Permission micro/caméra refusée : ${err.message}`:'Permission micro/caméra refusée.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(st.mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    await makePeer(st);await sendCallSignal('accept',{},st.peerId,st.callId);
  }
  async function handleCallSignal(signal:any) {
    if(!signal?.id||callSeen.current.has(signal.id))return;
    callSeen.current.add(signal.id);if(callSeen.current.size>500)callSeen.current.delete(callSeen.current.values().next().value as string);
    const current=callRef.current;
    const belongs=current&&current.callId===signal.call_id&&current.peerId===signal.sender_id;
    if(signal.kind==='invite'){
      if(!session||!supabase)return;
      if(current){await sendCallSignal('busy',{},signal.sender_id,signal.call_id);return;}
      if(!(await areFriends(signal.sender_id)))return;
      const {data:person}=await supabase.from('profiles').select('id,username,display_name,avatar_url').eq('id',signal.sender_id).maybeSingle();
      if(callRef.current)return;
      const st:CallState={callId:signal.call_id,peerId:signal.sender_id,peerName:person?.display_name??person?.username??'Membre SSPACE',peerAvatar:person?.avatar_url??'',mediaType:signal.payload?.mediaType==='video'?'video':'audio',role:'callee',phase:'ringing-in',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
      publishCall(st);callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-in'){void sendCallSignal('reject',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Appel manqué de '+st.peerName+'.');}},RING_TIMEOUT_MS);return;
    }
    if(!belongs)return;
    if(signal.kind==='accept'&&current.role==='caller'&&current.phase==='ringing-out'){
      clearCallTimers();current.phase='connecting';publishCall(current);
      const pc=await makePeer(current);const offer=await pc.createOffer();await pc.setLocalDescription(offer);
      await sendCallSignal('offer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='offer'&&current.role==='callee'){
      const pc=await makePeer(current);await pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});
      for(const candidate of current.pendingIce.splice(0)){try{await pc.addIceCandidate(candidate);}catch{}}
      const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
      await sendCallSignal('answer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='answer'&&current.role==='caller'&&current.pc){await current.pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});for(const candidate of current.pendingIce.splice(0)){try{await current.pc.addIceCandidate(candidate);}catch{}}return;}
    if(signal.kind==='ice'){
      for(const candidate of signal.payload?.candidates??[]){if(current.pc?.remoteDescription){try{await current.pc.addIceCandidate(candidate);}catch{}}else current.pendingIce.push(candidate);}return;
    }
    if(signal.kind==='reject'){endCall(false,signal.payload?.reason==='timeout'?'Pas de réponse.':'Appel refusé.');return;}
    if(signal.kind==='busy'){endCall(false,current.peerName+' est déjà en appel.');return;}
    if(signal.kind==='hangup'){endCall(false,'Appel terminé.');}
  }

  useEffect(()=>{
    if(!session||!supabase)return;
    const channel=supabase.channel('sspace-messenger-calls:'+session.user.id)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'call_signals',filter:'receiver_id=eq.'+session.user.id},payload=>{if(document.visibilityState==='hidden')return;void handleCallSignal(payload.new).catch(err=>{console.error('WebRTC signal handling',err);setNotice('Erreur pendant la négociation de l’appel.');});})
      .subscribe((status,error)=>{if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')console.warn('Canal WebRTC indisponible',error);});
    return ()=>{supabase?.removeChannel(channel);if(callRef.current)endCall(false);};
  },[session?.user.id]);

  useEffect(()=>{
    if(!call)return;
    if(call.localStream&&localVideoRef.current&&call.mediaType==='video'){localVideoRef.current.srcObject=call.localStream;void localVideoRef.current.play().catch(()=>{});}
    if(call.remoteStream){if(call.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=call.remoteStream;void remoteVideoRef.current.play().catch(()=>{});}if(remoteAudioRef.current){remoteAudioRef.current.srcObject=call.remoteStream;void remoteAudioRef.current.play().catch(()=>{});}}
  },[call?.localStream,call?.remoteStream,call?.mediaType]);

  function toggleMute(){const st=callRef.current;if(!st?.localStream)return;st.muted=!st.muted;st.localStream.getAudioTracks().forEach(t=>t.enabled=!st.muted);publishCall(st);}
  function toggleCamera(){const st=callRef.current;if(!st?.localStream)return;st.cameraEnabled=!st.cameraEnabled;st.localStream.getVideoTracks().forEach(t=>t.enabled=st.cameraEnabled);publishCall(st);}
  const callDuration=call?.startedAt?Math.max(0,Math.floor((Date.now()-call.startedAt)/1000)):0;
  const durationLabel=`${String(Math.floor(callDuration/60)).padStart(2,'0')}:${String(callDuration%60).padStart(2,'0')}`;

  if(authLoading) return <div className="loading-screen"><div className="brand-mark">S</div><p>Ouverture de SSpace Messenger…</p></div>;
  if(!isSupabaseConfigured) return <SetupScreen/>;
  if(!session) return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">VOTRE COMPTE SSPACE</div><h1>Bienvenue dans Messenger.</h1><p className="muted">Connectez-vous avec le compte que vous utilisez déjà sur le réseau social SSpace. Aucun deuxième compte Messenger n’est créé.</p><form onSubmit={authenticate} className="auth-form"><label>Adresse courriel<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.com" required autoComplete="username"/></label><label>Mot de passe<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mot de passe SSpace" required autoComplete="current-password"/></label>{authError&&<div className="error">{authError}</div>}<button className="primary full" type="submit">Se connecter à SSpace</button></form><a className="text-button" href="/">Retour au réseau social SSpace <ExternalLink size={14}/></a><div className="auth-foot"><ShieldCheck size={15}/> Même compte SSpace · Conversations partagées</div></div></main>;

  return <div className={`app-shell theme-${theme} ${animations ? 'motion-on' : 'motion-off'}`}><aside className={`sidebar ${showMobileChat?'hide-mobile':''}`}><div className="sidebar-top"><Brand/><button className="icon-btn" aria-label="Personnaliser Messenger" title="Thèmes et animations" onClick={() => setShowAppearance(v => !v)}><Settings size={19}/></button></div><div className="welcome"><div className="eyebrow">MESSAGERIE PRIVÉE</div><h1>Messages<span>.</span></h1><p>Votre monde, vos conversations.</p><div className="inbox-count"><Bell size={14}/> {unreadTotal} message{unreadTotal===1?'':'s'} reçu{unreadTotal===1?'':'s'} non lu{unreadTotal===1?'':'s'}</div></div>{showAppearance&&<section className="appearance-panel"><div className="appearance-title">🎨 Apparence Messenger</div><div className="theme-options">{[{id:'ocean',label:'Océan',swatch:'linear-gradient(135deg,#38bdf8,#2563eb)'},{id:'sunset',label:'Coucher de soleil',swatch:'linear-gradient(135deg,#fb7185,#f97316)'},{id:'violet',label:'Violet',swatch:'linear-gradient(135deg,#c084fc,#7c3aed)'},{id:'emerald',label:'Émeraude',swatch:'linear-gradient(135deg,#34d399,#059669)'},{id:'rose',label:'Bonbon',swatch:'linear-gradient(135deg,#f9a8d4,#ec4899)'}].map(t=><button key={t.id} className={`theme-choice ${theme===t.id?'chosen':''}`} onClick={()=>setTheme(t.id)}><i style={{background:t.swatch}}/><span>{t.label}</span>{theme===t.id&&<b>✓</b>}</button>)}</div><label className="animation-toggle"><input type="checkbox" checked={animations} onChange={e=>setAnimations(e.target.checked)}/><span>✨ Animations continues</span></label><small>Les choix sont sauvegardés sur cet appareil.</small></section>}<div className="search-box"><Search size={17}/><input placeholder="Rechercher" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="section-heading"><span>CONVERSATIONS</span><button className="icon-btn small" onClick={createConversation} title="Nouvelle conversation"><Plus size={18}/></button></div><div className="conversation-list">{filtered.length===0?<div className="empty-list"><MessageCircle size={25}/><p>{search?'Aucun résultat':'Vos conversations SSpace apparaîtront ici.'}</p><button className="text-button" onClick={createConversation}>Démarrer une discussion</button></div>:filtered.map(c=><button key={c.id} className={`conversation-item ${activeId===c.id?'selected':''}`} onClick={()=>{setActiveId(c.id);setShowMobileChat(true);}}><div className="avatar">{c.other?.avatar_url?<img src={c.other.avatar_url} alt=""/>:(c.other?.display_name??c.other?.username??'S').slice(0,1).toUpperCase()}</div><div className="conversation-meta"><strong>{c.other?.display_name??(c.other?.username?'@'+c.other.username:'Membre SSpace')}</strong><span>{c.last_message?.body??'Démarrer la conversation'}</span></div>{(c.unread_count??0)>0&&<span className="unread-pill">{c.unread_count}</span>}<span className="time">{c.last_message?new Date(c.last_message.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'}):''}</span></button>)}</div><div className="sidebar-bottom"><div className="profile-chip"><div className="avatar mini">{profile?.avatar_url?<img src={profile.avatar_url} alt=""/>:(profile?.display_name??session.user.email??'S').slice(0,1).toUpperCase()}</div><div><strong>{profile?.display_name??session.user.email}</strong><span>Compte SSpace connecté</span></div><button className="icon-btn" onClick={signOut} title="Déconnexion"><LogOut size={17}/></button></div></div></aside>
  <main className={`chat-panel ${!showMobileChat?'hide-mobile':''}`}>{activeConversation?<><header className="chat-header"><button className="icon-btn back-btn" onClick={()=>setShowMobileChat(false)}><ArrowLeft/></button><div className="avatar">{activeConversation.other?.avatar_url?<img src={activeConversation.other.avatar_url} alt=""/>:(activeConversation.other?.display_name??'S').slice(0,1).toUpperCase()}</div><div className="chat-person"><strong>{activeConversation.other?.display_name??activeConversation.other?.username??'Membre SSpace'}</strong><span>Conversation SSpace partagée</span></div><div className="header-actions"><button className="icon-btn" title="Appel vocal" aria-label="Appel vocal" onClick={()=>void startCall('audio')}><Phone size={19}/></button><button className="icon-btn" title="Appel vidéo" aria-label="Appel vidéo" onClick={()=>void startCall('video')}><Video size={20}/></button><button className="icon-btn" title="Joindre" onClick={()=>fileRef.current?.click()}><Paperclip size={19}/></button></div></header><div className="messages-area">{messages.length===0?<div className="chat-empty"><div className="empty-icon"><MessageCircle size={28}/></div><h2>La conversation commence ici.</h2><p>Envoyez votre premier message en toute simplicité.</p></div>:messages.map(m=><div key={m.id} className={`message-row ${m.sender_id===session.user.id?'mine':'theirs'}`}><div className="bubble">{m.media_path&&supabase?<Attachment supabase={supabase} path={m.media_path} type={m.message_type??'file'} label={m.body}/>:m.body}<div className="message-time">{new Date(m.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'})}{m.sender_id===session.user.id&&<CheckCheck size={13}/>}</div></div></div>)}</div><form className="composer" onSubmit={sendMessage}><input ref={fileRef} type="file" hidden onChange={e=>{const f=e.target.files?.[0];if(f)void sendFile(f,f.type.startsWith('image/')?'image':'file');e.currentTarget.value='';}}/><button type="button" className="icon-btn attach" onClick={()=>fileRef.current?.click()} disabled={uploading}><Paperclip size={19}/></button><button type="button" className="icon-btn attach" onClick={()=>void recordVoice()} title={recording?'Arrêter':'Message vocal'}>{recording?<MicOff size={19}/>:<Mic size={19}/>}</button><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Écrire un message…"/><span>{recording?'Enregistrement':uploading?'Envoi…':''}</span><button className="send-btn" type="submit" disabled={!draft.trim()} aria-label="Envoyer"><Send size={18}/></button></form></>:<div className="welcome-panel"><div className="welcome-art"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-core"><MessageCircle size={48}/></div></div><div className="eyebrow">SSPACE MESSENGER</div><h2>Les bonnes conversations<br/>font les belles connexions.</h2><p>Vos messages sont les mêmes que sur le réseau social SSpace.</p><button className="primary" onClick={createConversation}><Plus size={17}/> Nouvelle conversation</button><div className="secure-note"><ShieldCheck size={15}/> Vos échanges restent privés.</div></div>}</main>
  {call&&<div className={`call-overlay ${call.minimized?'is-minimized':''}`} role="dialog" aria-modal="true" aria-label={call.mediaType==='video'?'Appel vidéo':'Appel vocal'}>
    {call.phase==='ringing-in'?<div className="incoming-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><div className="eyebrow">APPEL {call.mediaType==='video'?'VIDÉO':'VOCAL'} ENTRANT</div><h2>{call.peerName}</h2><p>Appel entrant sur SSPACE Messenger</p><div className="call-actions"><button className="call-decline" onClick={()=>{void sendCallSignal('reject',{reason:'declined'},call.peerId,call.callId);endCall(false);}}><PhoneOff/> Refuser</button><button className="call-accept" onClick={()=>void acceptCall()}><Phone/> Répondre</button></div></div>:<div className={`call-stage ${call.mediaType==='video'?'video-call':'audio-call'}`}>
      {call.mediaType==='video'?<><video ref={remoteVideoRef} className="remote-video" autoPlay muted playsInline/><video ref={localVideoRef} className="local-video" autoPlay muted playsInline/><div className="video-peer-name">{call.peerName} · {call.phase==='active'?durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</div></>:<div className="audio-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><h2>{call.peerName}</h2><p>{call.phase==='active'?'En ligne · '+durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</p></div>}
      <div className="call-controls"><button title={call.muted?'Activer le micro':'Couper le micro'} onClick={toggleMute}>{call.muted?<MicOff/>:<Mic/>}</button>{call.mediaType==='video'&&<button title={call.cameraEnabled?'Couper la caméra':'Activer la caméra'} onClick={toggleCamera}>{call.cameraEnabled?<Video/>:<VideoOff/>}</button>}<button className="hangup" title="Raccrocher" onClick={()=>endCall(true,'Appel terminé.')}><PhoneOff/></button><button title={call.minimized?'Agrandir':'Réduire'} onClick={()=>{const st=callRef.current;if(st){st.minimized=!st.minimized;publishCall(st);}}}>{call.minimized?<Maximize2/>:<Minimize2/>}</button></div>
    </div>}</div>}
  <audio ref={remoteAudioRef} autoPlay playsInline className="sr-audio"/>
  {notice&&<div className="toast" role="status" onClick={()=>setNotice('')}>{notice}</div>}</div>;
}

function Brand(){return <div className="brand"><div className="brand-mark">S</div><div><strong>SSpace</strong><span>MESSENGER</span></div></div>}
function SetupScreen(){return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">CONFIGURATION REQUISE</div><h1>Préparons votre espace.</h1><p className="muted">Ajoutez l’URL et la clé publique du projet Supabase SIKX utilisé par SSpace. Messenger lira les conversations existantes; aucune nouvelle table de messages n’est créée.</p><div className="setup-code"><code>VITE_SUPABASE_URL=https://sikxoyylihsigzirewmi.supabase.co</code><code>VITE_SUPABASE_ANON_KEY=clé_publishable_SIKX</code></div><p className="small-note">N’utilisez jamais une clé service_role dans l’application.</p><div className="auth-foot"><ExternalLink size={15}/> Même base SSpace · messages reçus non lus uniquement</div></div></main>}

function Attachment({supabase,path,type,label}:{supabase:any,path:string,type:string,label:string}){const [url,setUrl]=useState<string|null>(null);useEffect(()=>{let live=true;supabase.storage.from('chat-attachments').createSignedUrl(path,3600).then(({data,error}:any)=>{if(live&&!error)setUrl(data?.signedUrl??null);});return()=>{live=false;};},[supabase,path]);if(!url)return <span>{label} (chargement)</span>;if(type==='image')return <a href={url} target="_blank" rel="noreferrer"><img src={url} alt="Photo" style={{maxWidth:'240px',maxHeight:'240px',borderRadius:'12px'}}/></a>;if(type==='voice')return <audio controls src={url}/>;return <a href={url} target="_blank" rel="noreferrer">📎 {label}</a>; }
