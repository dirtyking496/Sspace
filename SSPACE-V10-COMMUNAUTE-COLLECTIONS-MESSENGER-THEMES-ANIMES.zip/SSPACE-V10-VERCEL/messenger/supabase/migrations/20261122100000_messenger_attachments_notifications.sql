-- Bucket privé pour les pièces jointes Messenger (photos, documents, messages vocaux).
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-attachments','chat-attachments',false,26214400,null)
on conflict (id) do update set public=false,file_size_limit=26214400;

-- Les utilisateurs ne peuvent gérer que les objets dont le chemin commence par leur UID.
drop policy if exists "SSPACE Messenger upload own files" on storage.objects;
create policy "SSPACE Messenger upload own files" on storage.objects for insert to authenticated
with check (bucket_id='chat-attachments' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "SSPACE Messenger read own files" on storage.objects;
create policy "SSPACE Messenger read own files" on storage.objects for select to authenticated
using (bucket_id='chat-attachments' and exists (select 1 from public.conversations c where c.id::text=(storage.foldername(name))[2] and auth.uid() in (c.user_one,c.user_two)));
drop policy if exists "SSPACE Messenger delete own files" on storage.objects;
create policy "SSPACE Messenger delete own files" on storage.objects for delete to authenticated
using (bucket_id='chat-attachments' and (storage.foldername(name))[1]=auth.uid()::text);
