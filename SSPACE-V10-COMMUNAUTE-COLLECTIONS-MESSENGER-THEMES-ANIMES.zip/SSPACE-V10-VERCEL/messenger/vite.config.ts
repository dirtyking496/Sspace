import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Build Messenger inside the shared Vercel output without deleting the social site.
export default defineConfig({
  root: 'messenger',
  base: '/messenger/',
  plugins: [react()],
  build: {
    outDir: '../dist/messenger',
    emptyOutDir: false,
  },
});
