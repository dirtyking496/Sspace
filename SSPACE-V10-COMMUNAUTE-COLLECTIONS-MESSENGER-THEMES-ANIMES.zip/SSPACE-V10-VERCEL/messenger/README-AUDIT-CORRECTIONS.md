# Correctifs Messenger V10 — notes de déploiement

Cette révision ajoute au client Messenger l'envoi de pièces jointes (limite client 25 Mo), la capture et l'envoi de messages vocaux via MediaRecorder, la prévisualisation des images et la lecture des vocaux/fichiers par URL signée, ainsi qu'une notification navigateur pour message entrant si la permission a déjà été accordée.

## SQL à exécuter sur Supabase SIKX

Exécuter dans Supabase SQL Editor, dans cet ordre :
1. `supabase/migrations/20261120130000_private_video_audio_call_signals.sql`
2. `supabase/migrations/20261122100000_messenger_attachments_notifications.sql`

Le second SQL crée/configure le bucket privé `chat-attachments` et des politiques de stockage. Les accès de lecture sont autorisés aux participants d'une conversation en utilisant le chemin `UID/conversation-UUID/...`; les téléversements et suppressions restent limités au dossier UID de l'utilisateur.

## Variables Vercel

`VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` doivent être définies côté projet Messenger. N'utiliser jamais la clé service_role dans le client.

## Limites de vérification

Le build Vite/TypeScript n'a pas pu être confirmé ici : installation des dépendances npm interrompue par dépassement de délai. Les appels WebRTC sont toujours dépendants de la configuration réseau/STUN/TURN et de l'application effective des migrations Supabase. Les notifications navigateur nécessitent que la permission soit accordée par l'utilisateur et ne remplacent pas les notifications push installées.
