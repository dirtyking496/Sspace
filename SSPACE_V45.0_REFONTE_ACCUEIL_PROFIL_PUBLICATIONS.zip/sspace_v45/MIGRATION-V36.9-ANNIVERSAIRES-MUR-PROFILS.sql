-- SSPACE V36.9 : dates d’anniversaire publiques au choix + messages sur le mur des profils
alter table public.profiles add column if not exists birthday_date date;
alter table public.profiles add column if not exists birthday_public boolean not null default false;

create table if not exists public.profile_wall_messages (
 id uuid primary key default gen_random_uuid(),
 profile_id uuid not null references public.profiles(id) on delete cascade,
 author_id uuid not null references public.profiles(id) on delete cascade,
 content text not null check (char_length(trim(content)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists profile_wall_messages_profile_created_idx on public.profile_wall_messages(profile_id, created_at desc);
alter table public.profile_wall_messages enable row level security;
drop policy if exists "Wall messages visible on public profiles" on public.profile_wall_messages;
create policy "Wall messages visible on public profiles" on public.profile_wall_messages for select to authenticated using (true);
drop policy if exists "Members can write profile wall messages" on public.profile_wall_messages;
create policy "Members can write profile wall messages" on public.profile_wall_messages for insert to authenticated with check (author_id = (select auth.uid()) and profile_id <> (select auth.uid()));
drop policy if exists "Authors can delete own wall messages" on public.profile_wall_messages;
create policy "Authors can delete own wall messages" on public.profile_wall_messages for delete to authenticated using (author_id = (select auth.uid()));
grant select, insert, delete on public.profile_wall_messages to authenticated;
