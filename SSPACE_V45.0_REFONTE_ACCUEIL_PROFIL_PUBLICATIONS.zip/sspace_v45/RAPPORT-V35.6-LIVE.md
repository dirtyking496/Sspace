# SSPACE V35.6 — Salon public

- Rangée des membres connectés navigable par flèches et défilement horizontal.
- Chaque bulle ouvre le profil; ajout d'ami depuis la rangée et le panneau des membres du salon.
- Panneau public des membres en ligne avec avatar, pastille verte, profil et ajout d'ami.
- Actions sur les messages regroupées sous un menu compact (profil, masquer, bloquer, signaler).
- Historique et réception Realtime existants conservés; aucune table ni donnée supprimée.

Validation effectuée : archive ZIP intègre; fichiers site/dist identiques; scripts inline passés au parseur Node. Tests multi-comptes et déploiement non effectués.
