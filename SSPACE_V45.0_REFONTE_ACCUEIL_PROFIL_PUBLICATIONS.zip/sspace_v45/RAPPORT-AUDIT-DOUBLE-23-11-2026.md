# SSPACE — audit double et correction des blocages

## Corrections appliquées
- Le serveur API n'autorise plus `localhost:5173` comme seule origine CORS par défaut : l'origine de production `https://sspaceweb.vercel.app` est maintenant la valeur par défaut. Pour le développement local, définir explicitement `FRONTEND_ORIGINS=http://localhost:5173,https://sspaceweb.vercel.app`.
- Conservation des corrections de chat, déduplication Realtime/polling et redirections OAuth vers le domaine public dans cette version.
- Le manifeste racine garde uniquement les dépendances requises pour compiler le site et Messenger; les dépendances API restent dans `backend/package.json`.

## Vérification 1 — statique
- `node scripts/copy-site.mjs` : réussi.
- 8 blocs JavaScript intégrés à `site/index.html` : syntaxe vérifiée par `node --check`, réussite.
- `node --check backend/server.cjs` : réussite.
- Configuration Vite, TypeScript et Vercel relue.
- Les références `localhost` restantes sont documentaires ou servent à la configuration locale; elles ne sont plus la redirection OAuth de production.

## Vérification 2 — installation et compilation
- `npm install --no-audit --no-fund --prefer-offline` : expiration du délai d'exécution pendant l'accès au registre npm.
- `npm install --offline --no-audit --no-fund` : échec explicite `ENOTCACHED` pour `@supabase/supabase-js`; les paquets requis ne sont pas présents dans le cache local.
- En conséquence, `tsc -b` et `vite build` ne peuvent pas être confirmés dans cet environnement. Aucun faux statut de build réussi n'est déclaré.

## À faire dans l'environnement de déploiement
- Laisser Vercel installer les dépendances depuis le registre npm, puis exécuter `npm run build`.
- Déployer le serveur API séparément avec ses dépendances `backend/package.json` et définir `FRONTEND_ORIGINS=https://sspaceweb.vercel.app`.
- Dans Supabase Auth, confirmer `https://sspaceweb.vercel.app` comme Site URL et les URL de redirection `/` et `/messenger/`. Dans Google Cloud, confirmer l'origine autorisée du site et le callback Supabase `https://sikxoyylihsigzirewmi.supabase.co/auth/v1/callback`.

## Limites
Aucun déploiement, test réel de connexion Google, test navigateur du chat, ni test API avec identifiants de production n'a été effectué. Aucune donnée utilisateur ni migration Supabase n'a été modifiée.
