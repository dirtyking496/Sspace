# Intégration SSPACE V35.2 — récupération de mot de passe
- Archive source V35.2 conservée, modifications ciblées à `site/index.html`.
- Ajout de l'interface « Mot de passe oublié ? », envoi du lien via Supabase Auth et formulaire de nouveau mot de passe avec confirmation.
- Le code détecte les liens/flux de récupération et affiche le formulaire de changement.
- Aucun SQL ou changement aux données de la chasse aux gemmes n'a été effectué.
- Vérification: tous les blocs JavaScript inline du site ont passé `node --check`.
- Non vérifié: courriel réel, configuration Supabase Redirect URLs, test navigateur, build complet et déploiement.
