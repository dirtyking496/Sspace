import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent, TouchEvent, CSSProperties } from 'react';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { PresenceBadge } from './lib/presence';
import EmojiGifPicker from './components/EmojiGifPicker';
import MediaBubble from './components/MediaBubble';
import GameCenter from './components/GameCenter';
import type { GameId } from './components/GameCenter';
import MemoryCenter from './components/MemoryCenter';
import { getIceServers, hasTurn, loadTurnConfig, saveTurnConfig } from './lib/ice';
import type { GifItem } from './lib/gif';
import { MessageCircle, Search, Settings, Phone, Video, Plus, Send, Paperclip, Smile, LogOut, ShieldCheck, ArrowLeft, CheckCheck, ExternalLink, Bell, Mic, MicOff, VideoOff, PhoneOff, Minimize2, Maximize2, Gamepad2, Paintbrush, ImagePlus, Type, Check } from 'lucide-react';

type Profile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null; last_seen_at?: string | null; show_online?: boolean | null };
type Conversation = { id: string; user_one: string; user_two: string; updated_at: string; other?: Profile; last_message?: Message | null; unread_count?: number };
type Message = { id: string; conversation_id: string; sender_id: string; body: string; created_at: string; read_at: string | null; message_type?: string; media_path?: string | null; link_url?: string | null };
type CallKind = 'audio' | 'video';
type CallState = {
  callId: string; peerId: string; peerName: string; peerAvatar: string; mediaType: CallKind;
  role: 'caller' | 'callee'; phase: 'ringing-in' | 'ringing-out' | 'connecting' | 'active';
  pc: RTCPeerConnection | null; localStream: MediaStream | null; remoteStream: MediaStream | null;
  pendingIce: RTCIceCandidateInit[]; startedAt: number | null; muted: boolean; cameraEnabled: boolean; minimized: boolean;
};

const RING_TIMEOUT_MS = 45_000;

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [initialInboxReady, setInitialInboxReady] = useState(false);
  const [pullRefreshing, setPullRefreshing] = useState(false);
  const pullStartRef = useRef<{y:number;x:number}|null>(null);
  const [rocketIntroDone, setRocketIntroDone] = useState(false);
  const [onlineIds, setOnlineIds] = useState<string[]>([]);
  const [presenceReady, setPresenceReady] = useState(false);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState<'login'|'signup'|'reset'|'magic'>('login');
  const [authBusy, setAuthBusy] = useState(false);
  const [authError, setAuthError] = useState(''); const [notice, setNotice] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]); const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]); const [draft, setDraft] = useState(''); const [search, setSearch] = useState('');
  const [profile, setProfile] = useState<Profile | null>(null); const [showMobileChat, setShowMobileChat] = useState(false); const [minimizedChats, setMinimizedChats] = useState<string[]>([]);
  const [showSettings,setShowSettings]=useState(false); const [showMemoryCenter,setShowMemoryCenter]=useState(false); const [showGameCenter,setShowGameCenter]=useState(false); const [gameRoomId,setGameRoomId]=useState<string|null>(null);
  const [showPicker,setShowPicker]=useState(false); const [uploading,setUploading]=useState(false);
  const fileInputRef=useRef<HTMLInputElement|null>(null); const draftRef=useRef<HTMLInputElement|null>(null);
  const [turnCfg,setTurnCfg]=useState(()=>loadTurnConfig());
  const [theme,setTheme]=useState(()=>localStorage.getItem('sspace-messenger-theme')||'ocean');
  const [appearance,setAppearance]=useState(()=>localStorage.getItem('sspace-messenger-appearance')||'dark');
  const [animations,setAnimations]=useState(()=>localStorage.getItem('sspace-messenger-animations')!=='off');
  const [uiZoom,setUiZoom]=useState(()=>Math.min(1.2,Math.max(.8,Number(localStorage.getItem('sspace-messenger-zoom')||1))));
  const [hiddenUntil,setHiddenUntil]=useState<number>(()=>Number(localStorage.getItem('sspace-messenger-hidden-until')||0));
  const [hideDuration,setHideDuration]=useState('60');
  const [conversationThemes,setConversationThemes]=useState<Record<string,string>>(()=>{try{return JSON.parse(localStorage.getItem('sspace-conversation-themes')||'{}')}catch{return {}}});
  type ConversationLook={color:string;font:string;wallpaper:string;photo:string;opacity:number};
  const defaultLook:ConversationLook={color:'#ffffff',font:'sans',wallpaper:'aurora',photo:'',opacity:72};
  const [conversationLooks,setConversationLooks]=useState<Record<string,ConversationLook>>(()=>{try{return JSON.parse(localStorage.getItem('sspace-conversation-looks')||'{}')}catch{return {}}});
  const [showLookPanel,setShowLookPanel]=useState(false);
  const wallpaperInputRef=useRef<HTMLInputElement|null>(null);
  const notificationRouteHandled=useRef(false);
  const activeLook:ConversationLook={...defaultLook,...(activeId?conversationLooks[activeId]:{})};
  const wallpaperBackgrounds:Record<string,string>={aurora:'radial-gradient(circle at 20% 20%,#8b5cf6aa,transparent 36%),linear-gradient(135deg,#101b3b,#142c4c)',galaxy:'radial-gradient(circle at 70% 35%,#a855f7aa,transparent 25%),radial-gradient(circle at 25% 70%,#2563eb99,transparent 28%),#090d25',ocean:'linear-gradient(135deg,#063b59,#117c8c,#12284d)',sunset:'linear-gradient(135deg,#652f66,#c15b75,#25275c)',forest:'radial-gradient(circle at 80% 15%,#54a87999,transparent 35%),linear-gradient(135deg,#102e2a,#1c4a3c)',neon:'linear-gradient(135deg,#15113b,#3c1764,#102d46)'};
  const activeWallpaperBackground=activeLook.photo?`linear-gradient(rgba(7,12,25,${1-activeLook.opacity/100}),rgba(7,12,25,${1-activeLook.opacity/100})),url("${activeLook.photo}")`:`linear-gradient(rgba(7,12,25,${1-activeLook.opacity/100}),rgba(7,12,25,${1-activeLook.opacity/100})),${wallpaperBackgrounds[activeLook.wallpaper]||wallpaperBackgrounds.aurora}`;
  const [unreadTotal, setUnreadTotal] = useState(0); const [call, setCall] = useState<CallState | null>(null);
  const callRef = useRef<CallState | null>(null); const callSeen = useRef(new Set<string>());
  const callTimeoutRef = useRef<number | null>(null); const callClockRef = useRef<number | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null); const remoteVideoRef = useRef<HTMLVideoElement | null>(null); const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const activeConversation = conversations.find(c => c.id === activeId) ?? null;
  const effectiveTheme=activeId&&conversationThemes[activeId]?conversationThemes[activeId]:theme;
  const isHidden=hiddenUntil===-1||hiddenUntil>Date.now();
  useEffect(()=>{localStorage.setItem('sspace-messenger-theme',theme)},[theme]);
  useEffect(()=>{localStorage.setItem('sspace-messenger-appearance',appearance);document.documentElement.dataset.messengerAppearance=appearance;},[appearance]);
  useEffect(()=>{localStorage.setItem('sspace-messenger-animations',animations?'on':'off')},[animations]);
  useEffect(()=>{localStorage.setItem('sspace-messenger-zoom',String(uiZoom))},[uiZoom]);
  useEffect(()=>{localStorage.setItem('sspace-conversation-themes',JSON.stringify(conversationThemes))},[conversationThemes]);
  useEffect(()=>{try{localStorage.setItem('sspace-conversation-looks',JSON.stringify(conversationLooks))}catch{setNotice('Le fond personnalisé est trop volumineux pour être conservé. Choisis une image plus petite.')}},[conversationLooks]);
  function updateConversationLook(patch:Partial<ConversationLook>){if(!activeId)return;setConversationLooks(prev=>({...prev,[activeId]:{...defaultLook,...prev[activeId],...patch}}));}
  async function handleWallpaperFile(file?:File){if(!file||!activeId)return;if(!file.type.startsWith('image/')){setNotice('Choisis une image JPG, PNG ou WebP.');return;}try{const data=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error('Lecture impossible'));reader.onload=()=>{const img=new Image();img.onerror=()=>reject(new Error('Image invalide'));img.onload=()=>{const max=1500,scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement('canvas');canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);const ctx=canvas.getContext('2d');if(!ctx){reject(new Error('Canvas indisponible'));return;}ctx.drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL('image/jpeg',.72));};img.src=String(reader.result);};reader.readAsDataURL(file);});updateConversationLook({photo:data,wallpaper:'custom'});setNotice('Ton fond de conversation est enregistré sur cet appareil.');}catch{setNotice('Impossible de charger cette photo. Essaie une autre image.');}}
  useEffect(()=>{localStorage.setItem('sspace-messenger-hidden-until',String(hiddenUntil));if(!hiddenUntil||hiddenUntil===-1)return;const remaining=hiddenUntil-Date.now();if(remaining<=0){setHiddenUntil(0);return;}const timer=window.setTimeout(()=>{setHiddenUntil(0);void updateOnlineStatus(true)},remaining);return()=>window.clearTimeout(timer)},[hiddenUntil]);
  useEffect(()=>{if(!session||!supabase)return;const refresh=()=>{if(document.visibilityState==='visible'&&hiddenUntil!==-1&&hiddenUntil<=Date.now())void updateOnlineStatus(true);else if(hiddenUntil===-1||hiddenUntil>Date.now())void updateOnlineStatus(false)};refresh();const id=window.setInterval(refresh,60000);document.addEventListener('visibilitychange',refresh);return()=>{window.clearInterval(id);document.removeEventListener('visibilitychange',refresh)}},[session,hiddenUntil]);
  async function updateOnlineStatus(show:boolean){if(!supabase||!session)return;const {error}=await supabase.from('profiles').update({show_online:show,last_seen_at:new Date().toISOString()}).eq('id',session.user.id);if(error)setNotice('Statut non synchronisé : '+error.message);}
  async function hideOnlineForMinutes(minutes:number){const until=minutes===0?0:minutes<0?-1:Date.now()+minutes*60000;setHiddenUntil(until);await updateOnlineStatus(minutes===0);if(minutes!==0)setNotice(minutes<0?'Mode invisible activé jusqu’à réactivation.':'Mode invisible activé. Ton retour en ligne est programmé.');}
  function lastSeenLabel(person?:Profile|null){if(!person)return 'Statut inconnu';if(person.show_online===false)return 'Hors ligne';if(onlineIds.includes(person.id))return '🟢 En ligne maintenant';if(!person.last_seen_at)return 'Statut inconnu';const ms=Date.now()-Date.parse(person.last_seen_at);if(ms<90000)return 'Actif récemment';const mins=Math.floor(ms/60000);if(mins<60)return `Actif il y a ${mins} min`;const hrs=Math.floor(mins/60);if(hrs<24)return `Actif il y a ${hrs} h`;return `Actif il y a ${Math.floor(hrs/24)} j`;}
  const minimizeActiveChat = () => { if(!activeId)return;setMinimizedChats(prev=>prev.includes(activeId)?prev:[...prev,activeId]);setShowMobileChat(false); };
  const restoreChatBubble = (conversationId:string) => { setMinimizedChats(prev=>prev.filter(id=>id!==conversationId));setActiveId(conversationId);setShowMobileChat(true); };
  const filtered = useMemo(() => conversations.filter(c => (c.other?.display_name ?? c.other?.username ?? '').toLowerCase().includes(search.toLowerCase())).sort((a,b) => Number(b.other?.show_online!==false && onlineIds.includes(b.other?.id||''))-Number(a.other?.show_online!==false && onlineIds.includes(a.other?.id||''))), [conversations, search, onlineIds]);

  const publishCall = (next: CallState | null) => { callRef.current = next; setCall(next ? { ...next } : null); };
  const isCurrentCall = (id: string) => callRef.current?.callId === id;

  useEffect(() => {
    if (!supabase || !window.opener) return;
    const q = new URLSearchParams(location.search), nonce=q.get('sspace_link_nonce'), requested=q.get('sspace_social_origin');
    if(!nonce||!requested)return;
    let socialOrigin:string;
    try { const allowed=import.meta.env.VITE_SSPACE_SOCIAL_URL?new URL(import.meta.env.VITE_SSPACE_SOCIAL_URL).origin:location.origin; if(new URL(requested).origin!==allowed){setAuthError('Origine SSPACE non autorisée.');return;} socialOrigin=allowed; }
    catch {setAuthError('Adresse SSPACE autorisée invalide.');return;}
    let accepted=false;
    const receiveSession=async(event:MessageEvent)=>{if(accepted||event.origin!==socialOrigin||event.source!==window.opener||event.data?.type!=='SSPACE_SESSION'||event.data?.nonce!==nonce)return;const v=event.data.session;if(typeof v?.access_token!=='string'||typeof v?.refresh_token!=='string')return;accepted=true;const {error}=await supabase!.auth.setSession({access_token:v.access_token,refresh_token:v.refresh_token});if(error)setAuthError('La liaison automatique a échoué : '+error.message);else{history.replaceState({},document.title,location.pathname);setNotice('Compte SSpace connecté automatiquement.');}removeEventListener('message',receiveSession);};
    addEventListener('message',receiveSession);window.opener.postMessage({type:'SSPACE_MESSENGER_READY',nonce},socialOrigin);return()=>removeEventListener('message',receiveSession);
  }, []);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    supabase.auth.getSession().then(({data,error}) => { if(error) setAuthError(authMessage(error.message)); setSession(data.session); setAuthLoading(false); }).catch(() => { setAuthError('Impossible de vérifier la session. Vérifiez votre connexion Internet.'); setAuthLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadConversations() {
    if (!supabase || !session) return;
    const me = session.user.id;
    const { data: rows, error } = await supabase.from('conversations').select('id,user_one,user_two,updated_at').or(`user_one.eq.${me},user_two.eq.${me}`).order('updated_at', {ascending:false});
    if (error) { setNotice('Chargement des conversations impossible : ' + error.message); return; }
    const convs = rows ?? [];
    if (!convs.length) { setConversations([]); setUnreadTotal(0); return; }
    const otherIds = [...new Set(convs.map((c:any) => c.user_one === me ? c.user_two : c.user_one))];
    const ids = convs.map((c:any) => c.id);
    const [{data: people}, {data: recent}, {data: unread}] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').in('id', otherIds),
      supabase.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').in('conversation_id', ids).order('created_at',{ascending:false}).limit(Math.min(500, Math.max(100, ids.length * 10))),
      supabase.from('messages').select('id,conversation_id').in('conversation_id', ids).neq('sender_id', me).is('read_at', null)
    ]);
    const personMap = new Map((people ?? []).map((p:any) => [p.id, p]));
    const latest = new Map<string, Message>();
    (recent ?? []).forEach((m:any) => { if (!latest.has(m.conversation_id)) latest.set(m.conversation_id, m); });
    const unreadMap = new Map<string, number>();
    (unread ?? []).forEach((m:any) => unreadMap.set(m.conversation_id, (unreadMap.get(m.conversation_id) ?? 0) + 1));
    const enriched: Conversation[] = convs.map((c:any) => ({...c, other:personMap.get(c.user_one === me ? c.user_two : c.user_one), last_message:latest.get(c.id) ?? null, unread_count:unreadMap.get(c.id) ?? 0}));
    enriched.sort((a,b) => Date.parse(b.last_message?.created_at ?? b.updated_at) - Date.parse(a.last_message?.created_at ?? a.updated_at));
    setConversations(enriched); setUnreadTotal(enriched.reduce((n,c) => n + (c.unread_count ?? 0), 0));
  }

  async function refreshMessenger() {
    if (!session || !supabase || pullRefreshing) return;
    setPullRefreshing(true);
    try {
      await loadConversations();
      if (activeId) {
        const { data, error } = await supabase.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').eq('conversation_id',activeId).order('created_at',{ascending:true}).limit(300);
        if (error) throw error;
        setMessages((data ?? []) as Message[]);
        await markConversationRead(activeId);
      }
      setNotice('Messenger actualisé.');
    } catch (error:any) { setNotice('Actualisation impossible : '+(error?.message||'réessaie')); }
    finally { setPullRefreshing(false); }
  }
  function handlePullStart(e: TouchEvent<HTMLDivElement>) {
    if (e.touches.length !== 1) return;
    const pane = (e.target as HTMLElement).closest('.conversation-list,.messages-area') as HTMLElement|null;
    if (!pane || pane.scrollTop > 1) { pullStartRef.current = null; return; }
    pullStartRef.current = { y:e.touches[0].clientY, x:e.touches[0].clientX };
  }
  function handlePullEnd(e: TouchEvent<HTMLDivElement>) {
    const start = pullStartRef.current; pullStartRef.current = null;
    if (!start || !e.changedTouches.length) return;
    const dy = e.changedTouches[0].clientY-start.y, dx=e.changedTouches[0].clientX-start.x;
    if (dy > 75 && Math.abs(dy) > Math.abs(dx)*1.25) void refreshMessenger();
  }

  useEffect(() => {
    if (!session || !supabase) { setProfile(null); setConversations([]); setUnreadTotal(0); return; }
    const client = supabase; // Capture le client validé pour les callbacks asynchrones.
    let alive = true;
    setInitialInboxReady(false);
    const initialLoad = async () => {
      const [{data: meProfile},] = await Promise.all([
        client.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').eq('id', session.user.id).maybeSingle(),
        loadConversations()
      ]);
      if (alive) { if (meProfile) setProfile(meProfile as Profile); setInitialInboxReady(true); }
    };
    void initialLoad();
    const channel = client.channel('sspace-messenger-inbox').on('postgres_changes',{event:'*',schema:'public',table:'messages'},()=>{ if(alive) void loadConversations(); }).subscribe();
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') void loadConversations(); }, 15000);
    return () => { alive=false; window.clearInterval(timer); void client.removeChannel(channel); };
  }, [session]);

  // Deep-link depuis les notifications SSPACE : ouvrir la conversation et, si possible, le message exact.
  useEffect(() => {
    if (!session || !initialInboxReady || notificationRouteHandled.current) return;
    const params=new URLSearchParams(location.search);
    const requestedConversation=params.get('conversation');
    const requestedMessage=params.get('message');
    if(!requestedConversation&&!requestedMessage){notificationRouteHandled.current=true;return;}
    const openTarget=async()=>{
      let conversationId=requestedConversation;
      if(requestedMessage&&supabase){
        const {data}=await supabase.from('messages').select('conversation_id').eq('id',requestedMessage).maybeSingle();
        if(data?.conversation_id)conversationId=data.conversation_id;
      }
      if(conversationId&&conversations.some(c=>c.id===conversationId)){
        notificationRouteHandled.current=true;
        setActiveId(conversationId);setShowMobileChat(true);
        if(requestedMessage){
          const row=document.querySelector(`[data-message-id="${CSS.escape(requestedMessage)}"]`);
          if(row){row.scrollIntoView({behavior:'smooth',block:'center'});row.classList.add('notification-message-focus');}
        }
      }else {notificationRouteHandled.current=true;setNotice('Cette conversation ou ce message n’est pas disponible dans ton compte.');}
    };
    void openTarget();
  },[session?.user.id,initialInboxReady,conversations]);

  useEffect(() => {
    const requestedMessage=new URLSearchParams(location.search).get('message');
    if(!requestedMessage||!activeId||!messages.length)return;
    const row=document.querySelector(`[data-message-id="${CSS.escape(requestedMessage)}"]`);
    if(row){row.scrollIntoView({behavior:'smooth',block:'center'});row.classList.add('notification-message-focus');}
  },[activeId,messages]);

  // Même canal de présence que le réseau social SSPACE : les points verts reflètent les sessions réellement connectées.
  useEffect(() => {
    if (!session || !supabase) { setOnlineIds([]); setPresenceReady(false); return; }
    const client = supabase;
    setPresenceReady(false);
    const fallback = window.setTimeout(() => setPresenceReady(true), 2200);
    const channel = client.channel('sspace-global-online', { config: { presence: { key: session.user.id } } });
    channel.on('presence', { event: 'sync' }, () => {
      const ids = Object.values(channel.presenceState()).flat().map((entry:any) => entry?.userId).filter((id:any): id is string => typeof id === 'string');
      const next = [...new Set(ids)]; setOnlineIds(next); setPresenceReady(true); void loadConversations();
    });
    channel.subscribe(async status => {
      if (status === 'SUBSCRIBED') {
        try { await channel.track({ userId: session.user.id, joinedAt: new Date().toISOString(), app: 'messenger' }); } catch (error) { console.warn('Présence Messenger non publiée', error); }
        setPresenceReady(true);
      }
    });
    return () => { window.clearTimeout(fallback); setOnlineIds([]); setPresenceReady(false); void client.removeChannel(channel); };
  }, [session?.user.id]);

  useEffect(() => {
    if (!session || !initialInboxReady || !presenceReady) return;
    const timer = window.setTimeout(() => setRocketIntroDone(true), 3900);
    return () => window.clearTimeout(timer);
  }, [session?.user.id, initialInboxReady, presenceReady]);

  async function markConversationRead(id: string) {
    if (!supabase || !session) return;
    const { error } = await supabase.from('messages').update({read_at:new Date().toISOString()}).eq('conversation_id',id).neq('sender_id',session.user.id).is('read_at',null);
    if (error) setNotice('Les messages sont ouverts, mais leur état de lecture n’a pas pu être synchronisé : ' + error.message);
    await loadConversations();
  }

  useEffect(() => {
    if (!activeId || !supabase || !session) { setMessages([]); return; }
    let alive=true;
    const load = async () => {
      const {data,error}=await supabase!.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').eq('conversation_id',activeId).order('created_at',{ascending:true}).limit(300);
      if (!error && alive) { setMessages((data??[]) as Message[]); await markConversationRead(activeId); }
      else if(error && alive) setNotice('Messages indisponibles : '+error.message);
    };
    load();
    const channel=supabase.channel(`sspace-messenger-chat-${activeId}`).on('postgres_changes',{event:'*',schema:'public',table:'messages',filter:`conversation_id=eq.${activeId}`},()=>load()).subscribe();
    return ()=>{alive=false;supabase?.removeChannel(channel);};
  },[activeId,session]);

  function authMessage(raw:string) { const m=raw.toLowerCase(); if(m.includes('invalid login credentials')||m.includes('invalid credentials')) return 'Courriel ou mot de passe incorrect. Essayez le lien de connexion par courriel ou réinitialisez votre mot de passe.'; if(m.includes('email not confirmed')) return 'Confirmez votre adresse courriel en ouvrant le message reçu après votre inscription.'; if(m.includes('user already registered')) return 'Cette adresse est déjà inscrite. Revenez à Connexion.'; if(m.includes('provider is not enabled')||m.includes('unsupported provider')) return 'La connexion Google n’est pas activée dans Supabase pour le moment. Utilisez le courriel ou le lien magique.'; if(m.includes('network')||m.includes('fetch')) return 'Connexion au serveur impossible. Vérifiez Internet puis réessayez.'; if(m.includes('rate limit')) return 'Trop de tentatives. Attendez quelques minutes avant de réessayer.'; return raw; }
  async function authenticate(e:FormEvent) { e.preventDefault(); setAuthError(''); setNotice(''); if(!supabase)return; setAuthBusy(true); try { if(authMode==='signup') { const {error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:window.location.origin+window.location.pathname}}); if(error) throw error; setNotice('Inscription envoyée. Vérifiez votre boîte courriel et confirmez votre adresse avant de vous connecter.'); setAuthMode('login'); } else { const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) throw error; } } catch(err:any) { setAuthError(authMessage(err?.message??'Une erreur est survenue.')); } finally { setAuthBusy(false); } }
  async function sendMagicLink(e:FormEvent) { e.preventDefault(); if(!supabase)return; setAuthBusy(true);setAuthError('');setNotice('');try { const {error}=await supabase.auth.signInWithOtp({email,options:{emailRedirectTo:window.location.origin+window.location.pathname}});if(error)throw error;setNotice('Lien de connexion envoyé. Ouvrez le courriel sur cet appareil pour vous connecter.'); } catch(err:any){setAuthError(authMessage(err?.message??'Impossible d’envoyer le lien.'));}finally{setAuthBusy(false);} }
  async function resetPassword(e:FormEvent) { e.preventDefault(); if(!supabase)return;setAuthBusy(true);setAuthError('');setNotice('');try {const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:window.location.origin+window.location.pathname});if(error)throw error;setNotice('Instructions de réinitialisation envoyées si cette adresse est associée à un compte. Vérifiez votre boîte courriel.');}catch(err:any){setAuthError(authMessage(err?.message??'Impossible d’envoyer le courriel.'));}finally{setAuthBusy(false);} }
  async function googleLogin() {if(!supabase)return;setAuthBusy(true);setAuthError('');try{const {error}=await supabase.auth.signInWithOAuth({provider:'google',options:{redirectTo:window.location.origin+window.location.pathname}});if(error)throw error;}catch(err:any){setAuthError(authMessage(err?.message??'Connexion Google indisponible.'));setAuthBusy(false);}}
  async function sendMessage(e:FormEvent) { e.preventDefault(); const body=draft.trim(); const conversationId=activeId; if(!body)return; if(!conversationId||!session||!supabase){setNotice('Choisis une conversation et connecte-toi avant d’envoyer.');return;} try { const {error}=await supabase.from('messages').insert({conversation_id:conversationId,sender_id:session.user.id,body,message_type:'text'}); if(error)throw error; if(activeId===conversationId)setDraft(''); setNotice(''); } catch(err:any) { console.error('Messenger send failed',err); setNotice('Message non envoyé : '+(err?.message??'connexion impossible. Ton texte est conservé.')); } }
  async function sendGameInvite(roomId:string,game:GameId){if(!activeId||!session||!supabase)return;const label=game==='bowling'?'Bowling 3D Multiplayer':game==='kart-racing'?'Kart Racing':'Street Racing Multiplayer';const {error}=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body:`🎮 Invitation à jouer : ${label}`,message_type:'game_invite',link_url:`sspace-game:${roomId}`});if(error)setNotice('Salle créée, mais invitation non envoyée : '+error.message);else setNotice('Invitation envoyée dans la conversation !');}
  function insertEmoji(emoji:string){const el=draftRef.current;if(!el){setDraft(d=>d+emoji);return;}const a=el.selectionStart??draft.length,b=el.selectionEnd??draft.length;const next=draft.slice(0,a)+emoji+draft.slice(b);setDraft(next);requestAnimationFrame(()=>{el.focus();const pos=a+emoji.length;el.setSelectionRange(pos,pos);});}
  async function sendGif(gif:GifItem){if(!activeId||!session||!supabase)return;setShowPicker(false);const {error}=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body:'GIF',message_type:'gif',link_url:gif.url});if(error)setNotice('GIF non envoyé : '+error.message);}
  async function sendFiles(files:FileList|null){
    if(!files||!files.length||!activeId||!session||!supabase)return;
    const MAX=50*1024*1024; setUploading(true);
    try{
      for(const file of Array.from(files)){
        const isImage=file.type.startsWith('image/'),isVideo=file.type.startsWith('video/');
        if(!isImage&&!isVideo){setNotice('Format non pris en charge : '+file.name+' (photos et vidéos seulement).');continue;}
        if(file.size>MAX){setNotice(file.name+' dépasse 50 Mo.');continue;}
        const ext=(file.name.split('.').pop()||(isVideo?'mp4':'jpg')).toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,5)||'bin';
        const path=`${activeId}/${session.user.id}/${Date.now()}-${Math.random().toString(36).slice(2,8)}.${ext}`;
        const up=await supabase.storage.from('chat-attachments').upload(path,file,{contentType:file.type,cacheControl:'3600',upsert:false});
        if(up.error){setNotice('Envoi impossible : '+up.error.message);continue;}
        const type=file.type==='image/gif'?'gif':(isVideo?'video':'image');
        const ins=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body:isVideo?'🎬 Vidéo':'📷 Photo',message_type:type==='gif'?'image':type,media_path:path});
        if(ins.error){setNotice('Message non envoyé : '+ins.error.message);await supabase.storage.from('chat-attachments').remove([path]);}
      }
    } finally {setUploading(false);if(fileInputRef.current)fileInputRef.current.value='';}
  }
  async function signOut(){ if(callRef.current) endCall(false); await supabase?.auth.signOut();setActiveId(null);setShowMobileChat(false); }
  async function createConversation(){
    if(!supabase||!session)return;
    const username=window.prompt('Nom d’utilisateur SSpace de la personne à contacter'); if(!username)return;
    const normalized=username.trim().replace(/^@/, '').toLowerCase(); if(!normalized)return;
    const {data:target,error:lookupError}=await supabase.from('profiles').select('id').ilike('username',normalized).maybeSingle();
    if(lookupError||!target){setNotice(lookupError?.message??'Utilisateur introuvable.');return;}
    const {data:friendship,error:friendError}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${session.user.id},receiver_id.eq.${target.id}),and(sender_id.eq.${target.id},receiver_id.eq.${session.user.id})`).maybeSingle();
    if(friendError||!friendship){setNotice('Vous devez être amis sur SSpace pour démarrer une conversation.');return;}
    const pair=[session.user.id,target.id].sort();
    let {data:existing,error}=await supabase.from('conversations').select('id,user_one,user_two').eq('user_one',pair[0]).eq('user_two',pair[1]).maybeSingle();
    if(error){setNotice('Recherche de conversation impossible : '+error.message);return;}
    if(!existing){const created=await supabase.from('conversations').insert({user_one:pair[0],user_two:pair[1]}).select('id,user_one,user_two').single(); existing=created.data; error=created.error;}
    if(error||!existing){setNotice('Création impossible : '+(error?.message??'erreur inconnue'));return;}
    await loadConversations(); setActiveId(existing.id); setShowMobileChat(true);
  }

  function callSupported() { return typeof navigator.mediaDevices?.getUserMedia === 'function' && typeof window.RTCPeerConnection === 'function'; }
  async function areFriends(peerId: string) {
    if (!supabase || !session) return false;
    const me=session.user.id;
    const {data,error}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${me},receiver_id.eq.${peerId}),and(sender_id.eq.${peerId},receiver_id.eq.${me})`).maybeSingle();
    return !error && Boolean(data);
  }
  async function sendCallSignal(kind: string, payload: Record<string,unknown>, to: string, callId: string) {
    if (!supabase || !session || !to || !callId) return false;
    const {error}=await supabase.from('call_signals').insert({call_id:callId,sender_id:session.user.id,receiver_id:to,kind,payload});
    if(error){console.error('WebRTC signal error',kind,error);setNotice(/call_signals|relation|schema cache/i.test(error.message)?'Les appels ne sont pas activés dans Supabase : applique la migration SQL call_signals.':'Signal d’appel impossible : '+error.message);return false;}
    return true;
  }
  function clearCallTimers(){ if(callTimeoutRef.current!==null)window.clearTimeout(callTimeoutRef.current); if(callClockRef.current!==null)window.clearInterval(callClockRef.current); callTimeoutRef.current=null;callClockRef.current=null; }
  function endCall(notifyPeer: boolean, message?: string) {
    const st=callRef.current; if(!st)return;
    clearCallTimers();
    if(notifyPeer) void sendCallSignal('hangup',{},st.peerId,st.callId);
    try{st.pc?.close();}catch{}
    st.localStream?.getTracks().forEach(track=>track.stop());
    if(localVideoRef.current)localVideoRef.current.srcObject=null;
    if(remoteVideoRef.current)remoteVideoRef.current.srcObject=null;
    if(remoteAudioRef.current)remoteAudioRef.current.srcObject=null;
    publishCall(null);
    if(message)setNotice(message);
  }
  async function makePeer(st: CallState) {
    if(st.pc)return st.pc;
    const iceServers=await getIceServers(); if(st.pc)return st.pc; const pc=new RTCPeerConnection({iceServers}); st.pc=pc;
    st.localStream?.getTracks().forEach(track=>pc.addTrack(track,st.localStream!));
    pc.onicecandidate=e=>{if(e.candidate)void sendCallSignal('ice',{candidates:[e.candidate.toJSON()]},st.peerId,st.callId);};
    pc.ontrack=e=>{
      const stream=e.streams?.[0]??new MediaStream([e.track]); st.remoteStream=stream; publishCall(st);
      if(st.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=stream;void remoteVideoRef.current.play().catch(()=>{});}
      if(remoteAudioRef.current){remoteAudioRef.current.srcObject=stream;void remoteAudioRef.current.play().catch(()=>{});}
    };
    pc.onconnectionstatechange=()=>{
      if(callRef.current?.callId!==st.callId)return;
      if(pc.connectionState==='connected'){
        st.phase='active';st.startedAt=Date.now();publishCall(st);clearCallTimers();
        callClockRef.current=window.setInterval(()=>{const latest=callRef.current;if(latest?.callId===st.callId)publishCall({...latest});},1000);
      } else if(pc.connectionState==='failed') endCall(true,'Connexion WebRTC échouée. Un serveur TURN peut être nécessaire sur ce réseau.');
      else if(pc.connectionState==='disconnected') { window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&pc.connectionState!=='connected')endCall(true,'Connexion interrompue.');},9000); }
    };
    publishCall(st); return pc;
  }
  async function startCall(mediaType: CallKind) {
    if(!session||!activeConversation?.other||!supabase)return;
    if(!callSupported()){setNotice('Ce navigateur ne prend pas en charge les appels WebRTC. Utilise HTTPS et autorise le micro/la caméra.');return;}
    if(callRef.current){setNotice('Un appel est déjà en cours.');return;}
    const peer=activeConversation.other;
    if(!(await areFriends(peer.id))){setNotice('Les appels sont réservés aux amis SSPACE acceptés.');return;}
    const st:CallState={callId:crypto.randomUUID(),peerId:peer.id,peerName:peer.display_name??peer.username??'Membre SSPACE',peerAvatar:peer.avatar_url??'',mediaType,role:'caller',phase:'ringing-out',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
    publishCall(st);
    try{st.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:mediaType==='video'?{facingMode:'user',width:{ideal:1280},height:{ideal:720}}:false});}
    catch(err){publishCall(null);setNotice(err instanceof Error?`Accès au ${mediaType==='video'?'micro et à la caméra':'micro'} refusé : ${err.message}`:'Impossible d’accéder au micro ou à la caméra.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    const ok=await sendCallSignal('invite',{mediaType},st.peerId,st.callId);
    if(!ok){endCall(false);return;}
    callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-out'){void sendCallSignal('hangup',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Pas de réponse.');}},RING_TIMEOUT_MS);
  }
  async function acceptCall() {
    const st=callRef.current;if(!st||st.phase!=='ringing-in')return;
    clearCallTimers();st.phase='connecting';publishCall(st);
    try{st.localStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:st.mediaType==='video'?{facingMode:'user',width:{ideal:1280},height:{ideal:720}}:false});}
    catch(err){await sendCallSignal('reject',{reason:'media-permission'},st.peerId,st.callId);endCall(false,err instanceof Error?`Permission micro/caméra refusée : ${err.message}`:'Permission micro/caméra refusée.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(st.mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    await makePeer(st);await sendCallSignal('accept',{},st.peerId,st.callId);
  }
  async function handleCallSignal(signal:any) {
    if(!signal?.id||callSeen.current.has(signal.id))return;
    callSeen.current.add(signal.id);if(callSeen.current.size>500)callSeen.current.delete(callSeen.current.values().next().value as string);
    const current=callRef.current;
    const belongs=current&&current.callId===signal.call_id&&current.peerId===signal.sender_id;
    if(signal.kind==='invite'){
      if(!session||!supabase)return;
      if(current){await sendCallSignal('busy',{},signal.sender_id,signal.call_id);return;}
      if(!(await areFriends(signal.sender_id)))return;
      const {data:person}=await supabase.from('profiles').select('id,username,display_name,avatar_url').eq('id',signal.sender_id).maybeSingle();
      if(callRef.current)return;
      const st:CallState={callId:signal.call_id,peerId:signal.sender_id,peerName:person?.display_name??person?.username??'Membre SSPACE',peerAvatar:person?.avatar_url??'',mediaType:signal.payload?.mediaType==='video'?'video':'audio',role:'callee',phase:'ringing-in',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
      publishCall(st);callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-in'){void sendCallSignal('reject',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Appel manqué de '+st.peerName+'.');}},RING_TIMEOUT_MS);return;
    }
    if(!belongs)return;
    if(signal.kind==='accept'&&current.role==='caller'&&current.phase==='ringing-out'){
      clearCallTimers();current.phase='connecting';publishCall(current);
      const pc=await makePeer(current);const offer=await pc.createOffer();await pc.setLocalDescription(offer);
      await sendCallSignal('offer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='offer'&&current.role==='callee'){
      const pc=await makePeer(current);await pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});
      for(const candidate of current.pendingIce.splice(0)){try{await pc.addIceCandidate(candidate);}catch{}}
      const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
      await sendCallSignal('answer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='answer'&&current.role==='caller'&&current.pc){await current.pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});for(const candidate of current.pendingIce.splice(0)){try{await current.pc.addIceCandidate(candidate);}catch{}}return;}
    if(signal.kind==='ice'){
      for(const candidate of signal.payload?.candidates??[]){if(current.pc?.remoteDescription){try{await current.pc.addIceCandidate(candidate);}catch{}}else current.pendingIce.push(candidate);}return;
    }
    if(signal.kind==='reject'){endCall(false,signal.payload?.reason==='timeout'?'Pas de réponse.':'Appel refusé.');return;}
    if(signal.kind==='busy'){endCall(false,current.peerName+' est déjà en appel.');return;}
    if(signal.kind==='hangup'){endCall(false,'Appel terminé.');}
  }

  useEffect(()=>{
    if(!session||!supabase)return;
    const channel=supabase.channel('sspace-messenger-calls:'+session.user.id)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'call_signals',filter:'receiver_id=eq.'+session.user.id},payload=>{if(document.visibilityState==='hidden')return;void handleCallSignal(payload.new).catch(err=>{console.error('WebRTC signal handling',err);setNotice('Erreur pendant la négociation de l’appel.');});})
      .subscribe((status,error)=>{if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')console.warn('Canal WebRTC indisponible',error);});
    return ()=>{supabase?.removeChannel(channel);if(callRef.current)endCall(false);};
  },[session?.user.id]);

  useEffect(()=>{
    if(!call)return;
    if(call.localStream&&localVideoRef.current&&call.mediaType==='video'){localVideoRef.current.srcObject=call.localStream;void localVideoRef.current.play().catch(()=>{});}
    if(call.remoteStream){if(call.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=call.remoteStream;void remoteVideoRef.current.play().catch(()=>{});}if(remoteAudioRef.current){remoteAudioRef.current.srcObject=call.remoteStream;void remoteAudioRef.current.play().catch(()=>{});}}
  },[call?.localStream,call?.remoteStream,call?.mediaType]);

  function toggleMute(){const st=callRef.current;if(!st?.localStream)return;st.muted=!st.muted;st.localStream.getAudioTracks().forEach(t=>t.enabled=!st.muted);publishCall(st);}
  function toggleCamera(){const st=callRef.current;if(!st?.localStream)return;st.cameraEnabled=!st.cameraEnabled;st.localStream.getVideoTracks().forEach(t=>t.enabled=st.cameraEnabled);publishCall(st);}
  const callDuration=call?.startedAt?Math.max(0,Math.floor((Date.now()-call.startedAt)/1000)):0;
  const durationLabel=`${String(Math.floor(callDuration/60)).padStart(2,'0')}:${String(callDuration%60).padStart(2,'0')}`;

  if(authLoading) return <div className="loading-screen"><div className="brand-mark">S</div><p>Ouverture de SSpace Messenger…</p></div>;
  if(session && !rocketIntroDone) return <RocketIntro ready={initialInboxReady}/>;
  if(!isSupabaseConfigured) return <SetupScreen/>;
  if(!session) return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">VOTRE COMPTE SSPACE</div><h1>{authMode==='signup'?'Créer votre compte':authMode==='reset'?'Mot de passe oublié ?':authMode==='magic'?'Connexion sans mot de passe':'Bienvenue dans Messenger.'}</h1><p className="muted">Utilisez le compte SSpace existant pour retrouver vos conversations. Si le mot de passe bloque, choisissez une connexion par courriel.</p>{authMode==='login'&&<button type="button" className="google-button" onClick={()=>void googleLogin()} disabled={authBusy}><span className="google-g">G</span> Continuer avec Google</button>}<div className="auth-divider"><span>ou par courriel</span></div>{authMode==='reset'?<form onSubmit={resetPassword} className="auth-form"><label>Adresse courriel<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.com" required autoComplete="email"/></label>{authError&&<div className="error">{authError}</div>}<button className="primary full" type="submit" disabled={authBusy}>{authBusy?'Envoi…':'Envoyer les instructions'}</button></form>:authMode==='magic'?<form onSubmit={sendMagicLink} className="auth-form"><label>Adresse courriel<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.com" required autoComplete="email"/></label>{authError&&<div className="error">{authError}</div>}<button className="primary full" type="submit" disabled={authBusy}>{authBusy?'Envoi…':'Recevoir un lien de connexion'}</button></form>:<form onSubmit={authenticate} className="auth-form"><label>Adresse courriel<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.com" required autoComplete="email"/></label><label>Mot de passe<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder={authMode==='signup'?'Créer un mot de passe':'Mot de passe SSpace'} required minLength={6} autoComplete={authMode==='signup'?'new-password':'current-password'}/></label>{authError&&<div className="error">{authError}</div>}<button className="primary full" type="submit" disabled={authBusy}>{authBusy?'Veuillez patienter…':authMode==='signup'?'Créer mon compte':'Se connecter'}</button></form>}{notice&&<div className="notice">{notice}</div>}<div className="auth-links">{authMode==='login'?<><button onClick={()=>{setAuthMode('magic');setAuthError('');setNotice('');}}>Connexion par lien courriel</button><button onClick={()=>{setAuthMode('reset');setAuthError('');setNotice('');}}>Mot de passe oublié ?</button><button onClick={()=>{setAuthMode('signup');setAuthError('');setNotice('');}}>Créer un compte</button></>:<button onClick={()=>{setAuthMode('login');setAuthError('');setNotice('');}}>Retour à la connexion</button>}</div><a className="text-button" href="/">Retour au réseau social SSpace <ExternalLink size={14}/></a><div className="auth-foot"><ShieldCheck size={15}/> Même compte SSpace · Conversations partagées</div></div></main>;

  return <div className={`app-shell theme-${effectiveTheme} ${animations?'motion-on':'motion-off'}`} style={{zoom:uiZoom}} data-appearance={appearance} onTouchStart={handlePullStart} onTouchEnd={handlePullEnd}>{pullRefreshing&&<div className="messenger-pull-refresh" role="status">↻ Actualisation de Messenger…</div>}<aside className={`sidebar ${showMobileChat?'hide-mobile':''}`}><div className="sidebar-top"><div className="sidebar-brand-area"><button type="button" className="social-back-link" onClick={()=>{window.location.assign("/")}} aria-label="Retour à SSPACE Social"><ArrowLeft size={17}/><span>SSPACE Social</span></button><Brand/></div><span className="messenger-top-chip" aria-label="SSPACE Messenger">💬 Messenger</span><button className="icon-btn" aria-label="Paramètres Messenger" title="Paramètres Messenger" onClick={()=>setShowSettings(v=>!v)}><Settings size={19}/></button></div><div className="welcome"><div className="eyebrow">MESSAGERIE PRIVÉE</div><h1>Messages<span>.</span></h1><p>Votre monde, vos conversations.</p><div className="inbox-count"><Bell size={14}/> {unreadTotal} message{unreadTotal===1?'':'s'} reçu{unreadTotal===1?'':'s'} non lu{unreadTotal===1?'':'s'}</div></div>{showSettings&&<section className="appearance-panel messenger-settings"><div className="appearance-title">⚙️ Paramètres Messenger</div><label className="setting-label">Apparence<select className="field" value={appearance} onChange={e=>setAppearance(e.target.value)}><option value="dark">Sombre</option><option value="light">Clair</option><option value="auto">Automatique (appareil)</option></select></label><label className="setting-label">Thème / couleur<select className="field" value={theme} onChange={e=>setTheme(e.target.value)}><option value="ocean">Océan</option><option value="sunset">Coucher de soleil</option><option value="violet">Violet</option><option value="emerald">Émeraude</option><option value="rose">Bonbon</option></select></label><label className="setting-label">Zoom de l’interface <strong>{Math.round(uiZoom*100)}%</strong><input type="range" min="0.8" max="1.2" step="0.05" value={uiZoom} onChange={e=>setUiZoom(Number(e.target.value))}/></label><label className="animation-toggle"><input type="checkbox" checked={animations} onChange={e=>setAnimations(e.target.checked)}/><span>Animations de conversation</span></label><button type="button" className="text-button" onClick={()=>setShowMemoryCenter(true)}>🧠 Mémoire privée et souvenirs</button><label className="setting-label">Apparaître hors ligne<select className="field" value={isHidden?(hiddenUntil===-1?'-1':String(Math.max(1,Math.ceil((hiddenUntil-Date.now())/60000)))):'0'} onChange={e=>void hideOnlineForMinutes(Number(e.target.value))}><option value="0">En ligne (visible)</option><option value="15">Invisible 15 minutes</option><option value="60">Invisible 1 heure</option><option value="480">Invisible 8 heures</option><option value="1440">Invisible 24 heures</option><option value="-1">Invisible jusqu’à réactivation</option></select></label><small>{isHidden?(hiddenUntil===-1?'Invisible jusqu’à réactivation.':'Retour en ligne prévu '+new Date(hiddenUntil).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'})):'Ton statut est visible par les membres.'}</small><details className="turn-settings"><summary>📡 Appels & LIVE : serveur TURN {hasTurn()?'✅ actif':'⚠️ non configuré'}</summary><p className="small-note">Pour que les appels et LIVE fonctionnent sur les réseaux mobiles/Wi‑Fi restrictifs. Mêmes réglages que SSPACE LIVE (partagés dans ce navigateur).</p><input className="field" placeholder="turn:serveur:3478, turns:serveur:5349" value={turnCfg.urls} onChange={e=>setTurnCfg(v=>({...v,urls:e.target.value}))}/><input className="field" placeholder="Utilisateur TURN" value={turnCfg.username} onChange={e=>setTurnCfg(v=>({...v,username:e.target.value}))}/><input className="field" type="password" placeholder="Mot de passe TURN" value={turnCfg.credential} onChange={e=>setTurnCfg(v=>({...v,credential:e.target.value}))}/><button type="button" className="primary full" onClick={()=>{saveTurnConfig({urls:turnCfg.urls.trim(),username:turnCfg.username.trim(),credential:turnCfg.credential});setNotice('TURN enregistré. Il sera utilisé au prochain appel.')}}>Enregistrer TURN</button></details></section>}<div className="search-box"><Search size={17}/><input placeholder="Rechercher" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="section-heading"><span>CONVERSATIONS</span><button className="icon-btn small" onClick={createConversation} title="Nouvelle conversation"><Plus size={18}/></button></div><div className="conversation-list">{filtered.length===0?<div className="empty-list"><MessageCircle size={25}/><p>{search?'Aucun résultat':'Vos conversations SSpace apparaîtront ici.'}</p><button className="text-button" onClick={createConversation}>Démarrer une discussion</button></div>:filtered.map(c=><button key={c.id} className={`conversation-item ${activeId===c.id?'selected':''}`} onClick={()=>{setActiveId(c.id);setShowMobileChat(true);}}><div className="avatar">{c.other?.avatar_url?<img src={c.other.avatar_url} alt=""/>:(c.other?.display_name??c.other?.username??'S').slice(0,1).toUpperCase()}<PresenceBadge person={c.other} online={onlineIds.includes(c.other?.id||'')}/></div><div className="conversation-meta"><strong>{c.other?.display_name??(c.other?.username?'@'+c.other.username:'Membre SSpace')}</strong><span>{c.last_message?.body??'Démarrer la conversation'}</span></div>{(c.unread_count??0)>0&&<span className="unread-pill">{c.unread_count}</span>}<span className="time">{c.last_message?new Date(c.last_message.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'}):''}</span></button>)}</div><div className="sidebar-bottom"><div className="profile-chip"><div className="avatar mini">{profile?.avatar_url?<img src={profile.avatar_url} alt=""/>:(profile?.display_name??session.user.email??'S').slice(0,1).toUpperCase()}</div><div><strong>{profile?.display_name??session.user.email}</strong><span>Compte SSpace connecté</span></div><button className="icon-btn" onClick={signOut} title="Déconnexion"><LogOut size={17}/></button></div></div></aside>
  <main className={`chat-panel ${(!showMobileChat||!!activeId&&minimizedChats.includes(activeId))?'hide-mobile':''}`}>{activeConversation&&!minimizedChats.includes(activeId||'')?<><header className="chat-header"><button className="icon-btn back-btn" onClick={()=>setShowMobileChat(false)}><ArrowLeft/></button><div className="avatar">{activeConversation.other?.avatar_url?<img src={activeConversation.other.avatar_url} alt=""/>:(activeConversation.other?.display_name??'S').slice(0,1).toUpperCase()}<PresenceBadge person={activeConversation.other} online={onlineIds.includes(activeConversation.other?.id||'')}/></div><div className="chat-person"><strong>{activeConversation.other?.display_name??activeConversation.other?.username??'Membre SSpace'}</strong><span>{lastSeenLabel(activeConversation.other)}</span></div><div className="header-actions"><button className="icon-btn" title="Réduire en bulle flottante" aria-label="Réduire la conversation en bulle" onClick={minimizeActiveChat}><Minimize2 size={18}/></button><select className="chat-theme-select" title="Thème de cette conversation" value={conversationThemes[activeId||'']||theme} onChange={e=>setConversationThemes(v=>({...v,[activeId||'']:e.target.value}))}><option value="ocean">Océan</option><option value="sunset">Soleil</option><option value="violet">Violet</option><option value="emerald">Émeraude</option><option value="rose">Rose</option></select><button className="icon-btn" title="Jouer à deux" aria-label="Jeux multijoueurs" onClick={()=>{setGameRoomId(null);setShowGameCenter(true);}}><Gamepad2 size={19}/></button><button className="icon-btn" title="Appel vocal" aria-label="Appel vocal" onClick={()=>void startCall('audio')}><Phone size={19}/></button><button className="icon-btn" title="Appel vidéo" aria-label="Appel vidéo" onClick={()=>void startCall('video')}><Video size={20}/></button><button className={`icon-btn look-toggle ${showLookPanel?'active':''}`} title="Personnaliser cette conversation" aria-label="Personnaliser cette conversation" onClick={()=>setShowLookPanel(v=>!v)}><Paintbrush size={19}/></button></div></header>{showLookPanel&&<section className="conversation-look-panel" aria-label="Personnalisation de la conversation"><div className="look-panel-heading"><div><strong><Paintbrush size={15}/> Ambiance de conversation</strong><small>Ces réglages sont conservés sur cet appareil.</small></div><button type="button" className="look-close" onClick={()=>setShowLookPanel(false)}>✕</button></div><div className="look-control-group"><label><Type size={14}/> Style d’écriture</label><div className="look-style-options">{[{id:'sans',label:'Moderne',sample:'Aa'},{id:'serif',label:'Élégant',sample:'Aa'},{id:'rounded',label:'Arrondi',sample:'Aa'},{id:'typewriter',label:'Machine',sample:'Aa'},{id:'mono',label:'Futuriste',sample:'Aa'}].map(opt=><button type="button" key={opt.id} className={`look-style ${activeLook.font===opt.id?'selected':''}`} onClick={()=>updateConversationLook({font:opt.id})}><b className={`look-font-${opt.id}`}>{opt.sample}</b><small>{opt.label}</small>{activeLook.font===opt.id&&<Check size={12}/>}</button>)}</div></div><div className="look-control-group"><label>Couleur de mes messages</label><div className="look-colors">{['#ffffff','#ffe08a','#ff9dbd','#c4a5ff','#80e8ff','#8cf0bd','#ffad75','#d5e0f5'].map(color=><button type="button" key={color} className={`look-color ${activeLook.color===color?'selected':''}`} style={{'--look-swatch':color} as CSSProperties} aria-label={`Couleur ${color}`} onClick={()=>updateConversationLook({color})}/>)}</div></div><div className="look-control-group"><label><ImagePlus size={14}/> Fond d’écran SSPACE</label><div className="look-wallpapers">{[{id:'aurora',label:'Aurore',bg:'radial-gradient(circle at 20% 20%,#8b5cf6aa,transparent 36%),linear-gradient(135deg,#101b3b,#142c4c)'},{id:'galaxy',label:'Galaxie',bg:'radial-gradient(circle at 70% 35%,#a855f7aa,transparent 25%),radial-gradient(circle at 25% 70%,#2563eb99,transparent 28%),#090d25'},{id:'ocean',label:'Océan',bg:'linear-gradient(135deg,#063b59,#117c8c,#12284d)'},{id:'sunset',label:'Crépuscule',bg:'linear-gradient(135deg,#652f66,#c15b75,#25275c)'},{id:'forest',label:'Forêt',bg:'radial-gradient(circle at 80% 15%,#54a87999,transparent 35%),linear-gradient(135deg,#102e2a,#1c4a3c)'},{id:'neon',label:'Néon',bg:'linear-gradient(135deg,#15113b,#3c1764,#102d46)'}].map(w=><button type="button" key={w.id} className={`look-wallpaper ${activeLook.wallpaper===w.id&&!activeLook.photo?'selected':''}`} style={{background:w.bg}} onClick={()=>updateConversationLook({wallpaper:w.id,photo:''})}><span>{w.label}</span></button>)}</div><button type="button" className="look-upload" onClick={()=>wallpaperInputRef.current?.click()}><ImagePlus size={15}/> Ajouter une photo de ma galerie</button><input ref={wallpaperInputRef} hidden type="file" accept="image/*" onChange={e=>{void handleWallpaperFile(e.target.files?.[0]);e.currentTarget.value='';}}/>{activeLook.photo&&<button type="button" className="look-remove-photo" onClick={()=>updateConversationLook({photo:'',wallpaper:'aurora'})}>Retirer ma photo</button>}</div><div className="look-control-group look-opacity"><label>Transparence du fond <b>{activeLook.opacity}%</b></label><input type="range" min="35" max="92" step="1" value={activeLook.opacity} onChange={e=>updateConversationLook({opacity:Number(e.target.value)})}/><small>Le voile sombre protège la lisibilité des messages.</small></div></section>}<div className="messages-area" style={{backgroundImage:activeWallpaperBackground,backgroundSize:'cover',backgroundPosition:'center',backgroundAttachment:'local'}}>
{messages.length===0?<div className="chat-empty"><div className="empty-icon"><MessageCircle size={28}/></div><h2>La conversation commence ici.</h2><p>Envoyez votre premier message en toute simplicité.</p></div>:messages.map((m,i)=>{const mine=m.sender_id===session.user.id;const lastOfRun=!messages[i+1]||messages[i+1].sender_id!==m.sender_id;const who=mine?profile:activeConversation.other;const label=(who?.display_name??who?.username??'S');const av=<span className={`msg-avatar ${lastOfRun?'':'ghost'}`} aria-hidden="true">{who?.avatar_url?<img src={who.avatar_url} alt=""/>:label.slice(0,1).toUpperCase()}{!mine&&lastOfRun&&<PresenceBadge person={who} online={onlineIds.includes(who?.id||'')}/>}</span>;return <div key={m.id} data-message-id={m.id} className={`message-row ${mine?'mine':'theirs'}`}>{!mine&&av}<div className={`bubble ${m.message_type&&m.message_type!=='text'?'has-media':''}`}>{(m.message_type==='image'||m.message_type==='video'||m.message_type==='audio'||m.message_type==='gif')?<MediaBubble type={m.message_type} path={m.media_path} linkUrl={m.link_url}/>:m.message_type==='game_invite'?<button className="game-invite-message" onClick={()=>{const id=m.link_url?.startsWith('sspace-game:')?m.link_url.slice(12):null;if(id){setGameRoomId(id);setShowGameCenter(true);}}}>🎮 {m.body} · Rejoindre la partie</button>:<span className={`chat-message-body look-font-${activeLook.font}`} style={mine?{color:activeLook.color}:undefined}>{m.body}</span>}<div className="message-time">{new Date(m.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'})}{mine&&<CheckCheck size={13}/>}</div></div>{mine&&av}</div>})}</div><form className="composer" onSubmit={sendMessage}>{showPicker&&<EmojiGifPicker onEmoji={insertEmoji} onGif={g=>void sendGif(g)} onClose={()=>setShowPicker(false)}/>}<input ref={fileInputRef} type="file" accept="image/*,video/*" multiple hidden onChange={e=>void sendFiles(e.target.files)}/><button type="button" className="icon-btn attach" title="Envoyer une photo ou une vidéo" aria-label="Joindre une photo ou une vidéo" disabled={uploading} onClick={()=>fileInputRef.current?.click()}><Paperclip size={19}/></button><input ref={draftRef} value={draft} onChange={e=>setDraft(e.target.value)} onFocus={()=>setShowPicker(false)} placeholder={uploading?'Envoi du média…':'Écrire un message…'} enterKeyHint="send"/><button type="button" className={`icon-btn attach ${showPicker?'active':''}`} title="Émojis et GIF" aria-label="Émojis et GIF" onClick={()=>setShowPicker(v=>!v)}><Smile size={19}/></button><button className="send-btn" type="submit" disabled={!draft.trim()} aria-label="Envoyer"><Send size={18}/></button></form></>:<div className="welcome-panel"><div className="welcome-art"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-core"><MessageCircle size={48}/></div></div><div className="eyebrow">SSPACE MESSENGER</div><h2>Les bonnes conversations<br/>font les belles connexions.</h2><p>Vos messages sont les mêmes que sur le réseau social SSpace.</p><button className="primary" onClick={createConversation}><Plus size={17}/> Nouvelle conversation</button><div className="secure-note"><ShieldCheck size={15}/> Vos échanges restent privés.</div></div>}</main>
  {minimizedChats.length>0&&<div className="chat-bubble-dock" aria-label="Conversations réduites">{minimizedChats.map(id=>{const c=conversations.find(x=>x.id===id);if(!c)return null;const label=c.other?.display_name??c.other?.username??'Membre';return <button key={id} className="chat-floating-bubble" onClick={()=>restoreChatBubble(id)} title={`Rouvrir ${label}`} aria-label={`Rouvrir la conversation avec ${label}`}><span className="bubble-avatar">{c.other?.avatar_url?<img src={c.other.avatar_url} alt=""/>:(label.slice(0,1).toUpperCase())}</span>{(c.unread_count??0)>0&&<span className="bubble-unread">{c.unread_count}</span>}</button>})}</div>}
  {call&&<div className={`call-overlay ${call.minimized?'is-minimized':''}`} role="dialog" aria-modal="true" aria-label={call.mediaType==='video'?'Appel vidéo':'Appel vocal'}>
    {call.phase==='ringing-in'?<div className="incoming-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><div className="eyebrow">APPEL {call.mediaType==='video'?'VIDÉO':'VOCAL'} ENTRANT</div><h2>{call.peerName}</h2><p>Appel entrant sur SSPACE Messenger</p><div className="call-actions"><button className="call-decline" onClick={()=>{void sendCallSignal('reject',{reason:'declined'},call.peerId,call.callId);endCall(false);}}><PhoneOff/> Refuser</button><button className="call-accept" onClick={()=>void acceptCall()}><Phone/> Répondre</button></div></div>:<div className={`call-stage ${call.mediaType==='video'?'video-call':'audio-call'}`}>
      {call.mediaType==='video'?<><video ref={remoteVideoRef} className="remote-video" autoPlay muted playsInline/><video ref={localVideoRef} className="local-video" autoPlay muted playsInline/><div className="video-peer-name">{call.peerName} · {call.phase==='active'?durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</div></>:<div className="audio-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><h2>{call.peerName}</h2><p>{call.phase==='active'?'En ligne · '+durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</p></div>}
      <div className="call-controls"><button title={call.muted?'Activer le micro':'Couper le micro'} onClick={toggleMute}>{call.muted?<MicOff/>:<Mic/>}</button>{call.mediaType==='video'&&<button title={call.cameraEnabled?'Couper la caméra':'Activer la caméra'} onClick={toggleCamera}>{call.cameraEnabled?<Video/>:<VideoOff/>}</button>}<button className="hangup" title="Raccrocher" onClick={()=>endCall(true,'Appel terminé.')}><PhoneOff/></button><button title={call.minimized?'Agrandir':'Réduire'} onClick={()=>{const st=callRef.current;if(st){st.minimized=!st.minimized;publishCall(st);}}}>{call.minimized?<Maximize2/>:<Minimize2/>}</button></div>
    </div>}</div>}
  {showMemoryCenter&&supabase&&<MemoryCenter supabase={supabase} userId={session.user.id} onClose={()=>setShowMemoryCenter(false)}/>}
  {showGameCenter&&activeConversation?.other&&activeId&&<GameCenter supabase={supabase!} userId={session.user.id} conversationId={activeId} peerId={activeConversation.other.id} peerName={activeConversation.other.display_name??activeConversation.other.username??'ton ami'} roomId={gameRoomId} onInvite={(id,g)=>void sendGameInvite(id,g)} onClose={()=>{setShowGameCenter(false);setGameRoomId(null);}}/>}
  <audio ref={remoteAudioRef} autoPlay playsInline className="sr-audio"/>
  {notice&&<div className="toast" role="status" onClick={()=>setNotice('')}>{notice}</div>}</div>;
}

function RocketIntro({ready}:{ready:boolean}) {
  return <main className={`rocket-intro ${ready?'is-ready':''}`} aria-label="Ouverture de SSPACE Messenger">
    <div className="rocket-stars" aria-hidden="true"/>
    <div className="rocket-smoke-cloud smoke-one"/><div className="rocket-smoke-cloud smoke-two"/><div className="rocket-smoke-cloud smoke-three"/>
    <div className="rocket-brand-reveal"><div className="rocket-brand-mark">SS</div><div className="rocket-wordmark">SSPACE</div><div className="rocket-tagline">CONNECTE. PARTAGE. VIBRE.</div></div>
    <div className="rocket-flight" aria-hidden="true"><div className="rocket-flame flame-core"/><div className="rocket-flame flame-outer"/><div className="rocket-spark spark-a"/><div className="rocket-spark spark-b"/><div className="rocket-spark spark-c"/>
      <svg className="rocket-svg" viewBox="0 0 120 190" role="img" aria-label="Fusée SSPACE"><defs><linearGradient id="rocketBody" x1="0" x2="1"><stop offset="0" stopColor="#dbeafe"/><stop offset=".5" stopColor="#fff"/><stop offset="1" stopColor="#7dd3fc"/></linearGradient><linearGradient id="rocketFin" x1="0" x2="1"><stop stopColor="#2563eb"/><stop offset="1" stopColor="#22d3ee"/></linearGradient></defs><path d="M60 5 C35 27 30 67 33 118 L87 118 C90 67 85 27 60 5Z" fill="url(#rocketBody)" stroke="#7dd3fc" strokeWidth="3"/><path d="M60 5 C51 19 46 30 43 45 L77 45 C74 30 69 19 60 5Z" fill="#38bdf8"/><circle cx="60" cy="68" r="13" fill="#0b1730" stroke="#38bdf8" strokeWidth="5"/><path d="M34 92 L8 127 L34 119Z" fill="url(#rocketFin)"/><path d="M86 92 L112 127 L86 119Z" fill="url(#rocketFin)"/><path d="M45 117 L45 133 L75 133 L75 117Z" fill="#2563eb"/><path d="M48 132 L60 182 L72 132Z" fill="#fb923c"/><path d="M54 132 L60 166 L66 132Z" fill="#fde68a"/></svg>
    </div>
    <div className="rocket-loading">{ready?'MESSENGER PRÊT':'SYNCHRONISATION DES CONNEXIONS…'}<span><i/></span></div>
  </main>;
}

function Brand(){return <div className="brand"><div className="brand-mark">S</div><div><strong>SSpace</strong><span>MESSENGER</span></div></div>}
function SetupScreen(){return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">CONFIGURATION REQUISE</div><h1>Préparons votre espace.</h1><p className="muted">Ajoutez l’URL et la clé publique du projet Supabase SIKX utilisé par SSpace. Messenger lira les conversations existantes; aucune nouvelle table de messages n’est créée.</p><div className="setup-code"><code>VITE_SUPABASE_URL=https://sikxoyylihsigzirewmi.supabase.co</code><code>VITE_SUPABASE_ANON_KEY=clé_publishable_SIKX</code></div><p className="small-note">N’utilisez jamais une clé service_role dans l’application.</p><div className="auth-foot"><ExternalLink size={15}/> Même base SSpace · messages reçus non lus uniquement</div></div></main>}
