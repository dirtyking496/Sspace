# SSPACE V37.0 — Bubble Arena et commandes mobiles

- Ajout de Bubble Arena 3D : bulles brillantes avec rendu sphérique, visée tactile, rebonds, groupes de 3+, bulles détachées, score, record local, niveaux facile/normal/difficile, bombe, échange de bulle et pause.
- Ajout du jeu au hub Arcade.
- Agrandissement et espacement des commandes tactiles dans Street Racing, Survie Sauvage, Space Defender, Astéroïdes et Alunissage pour limiter les appuis accidentels. Bowling conservé inchangé.
- Migration SQL préparatoire pour stocker les scores Bubble Arena avec RLS. Elle n'a pas été appliquée à Supabase dans cette livraison.
- Le multijoueur en temps réel et le classement en ligne ne sont pas encore connectés; aucun faux mode en ligne n'est présenté.
