-- SSPACE Bubble Arena: leaderboard + challenge result storage (online multiplayer wiring is a separate client integration step)
create table if not exists public.sspace_bubble_scores (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 score integer not null check (score >= 0 and score <= 10000000),
 difficulty text not null check (difficulty in ('easy','normal','hard')),
 cleared boolean not null default false,
 created_at timestamptz not null default now()
);
create index if not exists sspace_bubble_scores_rank_idx on public.sspace_bubble_scores(score desc, created_at asc);
alter table public.sspace_bubble_scores enable row level security;
drop policy if exists "Bubble scores are readable by members" on public.sspace_bubble_scores;
create policy "Bubble scores are readable by members" on public.sspace_bubble_scores for select to authenticated using (true);
drop policy if exists "Members insert their own bubble scores" on public.sspace_bubble_scores;
create policy "Members insert their own bubble scores" on public.sspace_bubble_scores for insert to authenticated with check (user_id = (select auth.uid()));
grant select, insert on public.sspace_bubble_scores to authenticated;
