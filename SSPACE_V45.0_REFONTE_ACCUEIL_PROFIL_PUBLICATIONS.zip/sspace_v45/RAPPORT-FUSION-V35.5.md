# SSPACE V35.5 — Fusion conservatrice des modules

- Base: SSPACE V35.4 corrigée.
- Sources intégrées sans écraser les fichiers plus récents: SSPACE V34_NEON_MESSENGER_CHAT_REPARE.zip et SSPACE_V27_1_INTEGRE.zip.
- Les éléments absents ont été réintégrés (documentation, assets, API/backend et fichiers de support).
- Les répertoires dist/ historiques et fichiers .env ne sont pas copiés: le build doit être régénéré et aucun secret de configuration ne doit être embarqué.
- Les fichiers communs aux sources et à la base étaient identiques; aucun module courant n'a été remplacé par une version plus ancienne.
- Les fichiers du site et Messenger, y compris Bibliothèque émeraude, présence en ligne, Messenger et chat, ont été conservés depuis la base V35.4.

## Vérifications
- Intégrité ZIP: validée.
- Égalité site/index.html et dist/index.html: vérifiée.
- Syntaxe JavaScript inline du site: vérifiée par Node.
- Build complet Vite/TypeScript et tests navigateur multi-comptes: non certifiés dans cette archive.
