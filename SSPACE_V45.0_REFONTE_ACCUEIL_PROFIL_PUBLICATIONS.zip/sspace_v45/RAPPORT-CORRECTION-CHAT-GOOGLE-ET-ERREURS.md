# SSPACE V35.2 — Correction du chat public et des redirections Google

## Changements apportés au code
- SSPACE LIVE : ajout d'une synchronisation de secours toutes les 12 secondes pour récupérer les nouveaux messages si Realtime se déconnecte.
- Déduplication des messages reçus par Realtime et par le mécanisme de secours.
- Ouverture/fermeture du salon plus robuste, nettoyage des canaux et des minuteries.
- Affichage d'un état compréhensible lors des pertes de connexion au lieu de laisser croire que le salon est connecté.
- Envoi de messages protégé contre les doubles clics, avec gestion d'erreur lisible et limite de 500 caractères.
- Présence du salon public basée sur son propre canal Presence, et non sur le canal global des membres.
- Modération : messages d'erreur plus lisibles; détail technique conservé dans la console.
- Authentification : Google, inscription, liens magiques et récupération du mot de passe utilisent désormais l'origine publique `https://sspaceweb.vercel.app` dans le site principal et dans Messenger. Un lancement depuis localhost ne renvoie donc plus les utilisateurs vers localhost.

## Vérifications effectuées
- Les 7 blocs JavaScript intégrés à la page principale passent `node --check`.
- Supabase : la table `sspace_live_chat_messages` existe avec les colonnes attendues.
- La table est déjà incluse dans la publication `supabase_realtime`.
- Les règles RLS consultées autorisent les membres authentifiés à lire les messages et à envoyer leurs propres messages, avec limite de longueur et contrôle du type GIF.
- Aucune conversation, aucun compte et aucune donnée de profil n'ont été modifiés.

## Limites non certifiées
- `npm run build` ne peut pas être validé dans cet environnement : les dépendances npm (React, Supabase JS, Vite, etc.) ne sont pas installées. Le script de copie a démarré, mais TypeScript s'arrête sur les modules manquants. Ce n'est pas un résultat de build réussi.
- Aucun test de connexion Google réel ni d'envoi de courriel n'a été réalisé.
- Aucun déploiement Vercel n'a été lancé.

## Configuration externe Google / Supabase à confirmer dans le tableau de bord
Dans Supabase > Authentication > URL Configuration :
- Site URL : `https://sspaceweb.vercel.app`
- Redirect URLs : `https://sspaceweb.vercel.app/**` et `https://sspaceweb.vercel.app/messenger/**`
- Retirer les anciennes URL localhost de la liste de production si elles ne servent plus au développement.

Dans Google Cloud Console > Credentials > OAuth 2.0 Client :
- Authorized JavaScript origin : `https://sspaceweb.vercel.app`
- Authorized redirect URI : `https://sikxoyylihsigzirewmi.supabase.co/auth/v1/callback`

Le code ne peut pas modifier ces paramètres de fournisseur Google/Supabase. Ils doivent correspondre exactement au domaine public et au callback Supabase ci-dessus. Si Google est désactivé dans Supabase ou si le Client ID/Secret Google est invalide, l'écran Google continuera d'échouer malgré la correction du code.
