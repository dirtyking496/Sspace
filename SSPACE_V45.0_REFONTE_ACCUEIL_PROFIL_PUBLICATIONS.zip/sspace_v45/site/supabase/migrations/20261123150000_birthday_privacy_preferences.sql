-- SSPACE : stockage privé de la date de naissance et visibilité granulaire.
-- La date complète est déplacée hors de profiles pour éviter qu'un SELECT *
-- sur le profil public ne révèle accidentellement la date de naissance.

alter table public.profiles
  add column if not exists birthday_date date,
  add column if not exists birthday_public boolean not null default false,
  add column if not exists birthday_visibility text not null default 'private';

alter table public.profiles
  drop constraint if exists profiles_birthday_visibility_check;
alter table public.profiles
  add constraint profiles_birthday_visibility_check
  check (birthday_visibility in ('private','year_only','month_day','full_date'));

create table if not exists public.profile_birthdays (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  birth_date date not null,
  visibility text not null default 'private'
    check (visibility in ('private','year_only','month_day','full_date')),
  show_in_birthday_list boolean not null default false,
  updated_at timestamptz not null default now()
);

insert into public.profile_birthdays(user_id,birth_date,visibility,show_in_birthday_list,updated_at)
select id,birthday_date,
  case when birthday_visibility in ('year_only','month_day','full_date') then birthday_visibility
       when birthday_public then 'month_day' else 'private' end,
  coalesce(birthday_public,false),now()
from public.profiles
where birthday_date is not null
on conflict (user_id) do nothing;

alter table public.profile_birthdays enable row level security;
drop policy if exists "Members can read own birthday settings" on public.profile_birthdays;
create policy "Members can read own birthday settings" on public.profile_birthdays
  for select to authenticated using (user_id = auth.uid());
drop policy if exists "Members can insert own birthday settings" on public.profile_birthdays;
create policy "Members can insert own birthday settings" on public.profile_birthdays
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Members can update own birthday settings" on public.profile_birthdays;
create policy "Members can update own birthday settings" on public.profile_birthdays
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke all on public.profile_birthdays from anon;
grant select, insert, update on public.profile_birthdays to authenticated;

-- Les anciennes colonnes ne restent pas dans le profil consultable.
alter table public.profiles drop constraint if exists profiles_birthday_visibility_check;
alter table public.profiles drop column if exists birthday_date;
alter table public.profiles drop column if exists birthday_public;
alter table public.profiles drop column if exists birthday_visibility;

create or replace function public.sspace_get_public_birthday(p_profile_id uuid)
returns table(birth_year integer,birth_month integer,birth_day integer,visibility text)
language sql stable security definer set search_path = public as $$
  select
    case when b.visibility in ('year_only','full_date') then extract(year from b.birth_date)::integer else null end,
    case when b.visibility in ('month_day','full_date') then extract(month from b.birth_date)::integer else null end,
    case when b.visibility in ('month_day','full_date') then extract(day from b.birth_date)::integer else null end,
    b.visibility
  from public.profile_birthdays b
  where b.user_id = p_profile_id and b.visibility <> 'private'
  limit 1;
$$;
revoke all on function public.sspace_get_public_birthday(uuid) from public, anon;
grant execute on function public.sspace_get_public_birthday(uuid) to authenticated;

create or replace function public.sspace_get_friend_birthdays()
returns table(id uuid,username text,display_name text,avatar_url text,birth_year integer,birth_month integer,birth_day integer,visibility text)
language sql stable security definer set search_path = public as $$
  select p.id,p.username,p.display_name,p.avatar_url,
    case when b.visibility = 'full_date' then extract(year from b.birth_date)::integer else null end,
    extract(month from b.birth_date)::integer,
    extract(day from b.birth_date)::integer,
    b.visibility
  from public.profile_birthdays b
  join public.profiles p on p.id=b.user_id
  where b.show_in_birthday_list = true
    and b.visibility in ('month_day','full_date')
    and exists (
      select 1 from public.friend_requests f
      where f.status='accepted'
        and ((f.sender_id=auth.uid() and f.receiver_id=p.id)
          or (f.receiver_id=auth.uid() and f.sender_id=p.id))
    )
  order by extract(month from b.birth_date),extract(day from b.birth_date)
  limit 100;
$$;
revoke all on function public.sspace_get_friend_birthdays() from public, anon;
grant execute on function public.sspace_get_friend_birthdays() to authenticated;

comment on table public.profile_birthdays is
  'Renseignements de naissance privés; seule la portion autorisée est retournée par les fonctions SSPACE.';
