-- V42 SSPACE: permettre d'identifier tout membre SSPACE dans une publication.
-- L'identification reste réservée à l'auteur de la publication et exclut l'auto-identification.
drop policy if exists "Authors tag accepted friends on own posts" on public.post_mentions;
drop policy if exists "Authors tag members on own posts" on public.post_mentions;
create policy "Authors tag members on own posts" on public.post_mentions
for insert to authenticated with check (
  tagged_by=(select auth.uid())
  and mentioned_user_id<>(select auth.uid())
  and exists(select 1 from public.profiles pr where pr.id=mentioned_user_id)
  and exists(select 1 from public.posts p where p.id=post_id and p.user_id=(select auth.uid()))
);

create or replace function public.create_post_bundle(
  p_title text,
  p_content text,
  p_image_url text,
  p_media_url text,
  p_media_type text,
  p_poll_question text,
  p_poll_options text[],
  p_mentioned_user_ids uuid[]
) returns uuid
language plpgsql
security invoker
set search_path=''
as $function$
declare
  v_user uuid := auth.uid();
  v_post uuid;
  v_count integer;
begin
  if v_user is null then raise exception 'Connexion requise.'; end if;
  if coalesce(length(p_title),0)>160 then raise exception 'Titre trop long.'; end if;
  if coalesce(length(p_content),0)>20000 then raise exception 'Publication trop longue.'; end if;
  if p_media_type is not null and p_media_type not in ('audio','video') then raise exception 'Type de média invalide.'; end if;
  if p_media_url is not null and (length(p_media_url)>2048 or p_media_url !~ '^https?://') then raise exception 'Adresse média invalide.'; end if;
  if p_image_url is not null and (length(p_image_url)>2048 or p_image_url !~ '^https?://') then raise exception 'Adresse image invalide.'; end if;
  if (p_media_url is null) <> (p_media_type is null) then raise exception 'Fichier média incomplet.'; end if;

  if p_poll_question is not null then
    if length(trim(p_poll_question)) not between 1 and 180 then raise exception 'Question de sondage invalide.'; end if;
    if coalesce(cardinality(p_poll_options),0) not between 2 and 6 then raise exception 'Un sondage doit contenir de 2 à 6 choix.'; end if;
    if exists(select 1 from unnest(p_poll_options) x where length(trim(x)) not between 1 and 100) then raise exception 'Un choix de sondage est vide ou trop long.'; end if;
    if (select count(distinct lower(trim(x))) from unnest(p_poll_options) x) <> cardinality(p_poll_options) then raise exception 'Les choix du sondage doivent être différents.'; end if;
  elsif p_poll_options is not null and cardinality(p_poll_options)>0 then
    raise exception 'Une question est requise pour le sondage.';
  end if;

  if coalesce(cardinality(p_mentioned_user_ids),0)>0 then
    select count(distinct x) into v_count from unnest(p_mentioned_user_ids) x;
    if v_count <> cardinality(p_mentioned_user_ids) then raise exception 'Une personne est sélectionnée plusieurs fois.'; end if;
    if exists (
      select 1 from unnest(p_mentioned_user_ids) x
      where x=v_user or not exists (select 1 from public.profiles pr where pr.id=x)
    ) then raise exception 'Sélection de membre invalide.'; end if;
  end if;

  insert into public.posts(user_id,title,content,image_url,media_url,media_type,poll_question)
  values(v_user,coalesce(nullif(trim(p_title),''),'Publication'),coalesce(nullif(p_content,''),' '),p_image_url,p_media_url,p_media_type,nullif(trim(p_poll_question),''))
  returning id into v_post;

  if p_poll_question is not null then
    insert into public.post_poll_options(post_id,option_text)
    select v_post,trim(x) from unnest(p_poll_options) x;
  end if;

  if coalesce(cardinality(p_mentioned_user_ids),0)>0 then
    insert into public.post_mentions(post_id,mentioned_user_id,tagged_by)
    select v_post,x,v_user from unnest(p_mentioned_user_ids) x;
  end if;
  return v_post;
end;
$function$;


revoke all on function public.create_post_bundle(text,text,text,text,text,text,text[],uuid[]) from public;
revoke all on function public.create_post_bundle(text,text,text,text,text,text,text[],uuid[]) from anon;
grant execute on function public.create_post_bundle(text,text,text,text,text,text,text[],uuid[]) to authenticated;
