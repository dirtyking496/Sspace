# SSPACE V35.9 — interface plus légère

## Modifications
- Réduction des espacements et des avatars dans le Salon des connectés pour afficher davantage de membres dans une zone compacte.
- SSPACE LIVE devient un bouton circulaire plus visible, avec adaptation mobile.
- Arrondis plus doux et contrôles plus compacts pour réduire l'aspect carré et surchargé.
- L'action d'autorisation des notifications est déplacée du Centre de notifications vers Paramètres > Paramètres de l’application.
- Après autorisation accordée, le bouton disparaît et un statut indique que l'autorisation est déjà active. Si le navigateur a refusé l'autorisation, l'interface indique de passer par les réglages du navigateur.

## Vérifications
- Archive ZIP vérifiée après création.
- `site/index.html` et `dist/index.html` synchronisés.
- 8 blocs JavaScript intégrés analysés : aucune erreur de syntaxe.
- Le build complet `npm run build` n'a pas pu être validé : les dépendances npm ne sont pas installées dans cet environnement (React, Supabase JS, Vite et types associés introuvables). Aucune affirmation de déploiement ou de test visuel réel.
