# SSPACE V35.2 — audit et préparation de déploiement

Date: 2026-11-23

## Correctif appliqué
- Le gestionnaire global `db.auth.onAuthStateChange` reconnaît maintenant explicitement `PASSWORD_RECOVERY`.
- À la réception de cet événement, le formulaire de nouveau mot de passe est affiché et le champ est mis au focus.
- Le flux existant `resetPasswordForEmail` et `updateUser({ password })` est conservé.
- Aucun secret ni clé privée n'a été ajouté au client.

## Vérifications exécutées
- Archive extraite et recréée sans erreur.
- 7 scripts JavaScript inline extraits et passés avec `node --check`: succès.
- Projet Supabase `sikxoyylihsigzirewmi`: `ACTIVE_HEALTHY`.
- Données de chasse: `treasure_events` = 1 ligne; `treasure_gems` = 4 lignes. Aucune écriture effectuée sur ces tables.
- Audit Supabase: alertes RLS sans politiques, fonctions SECURITY DEFINER exécutables et protection des mots de passe compromis désactivée.
- Fonction `sspace-ai-community`: journaux montrent des POST en HTTP 500 récurrents. Les journaux disponibles exposent les requêtes et démarrages/arrêts, mais pas la trace applicative qui permettrait d'isoler la cause exacte. Fonction non modifiée.

## Limites / non certifié
- `npm install --no-audit --no-fund` a expiré après 120 secondes; le build TypeScript/Vite n'a donc pas pu être exécuté.
- Aucun test navigateur automatisé ou manuel n'a été réalisé.
- L'envoi d'un courriel réel et le lien de redirection Supabase restent à tester avec un compte de test.
- Aucune configuration Auth, aucune politique RLS, aucune fonction distante et aucun déploiement n'ont été modifiés.
- Déploiement non effectué.

## Étape nécessaire avant production
1. Installer les dépendances dans un environnement réseau fonctionnel puis lancer `npm run build`.
2. Confirmer le domaine public SSPACE à ajouter aux Redirect URLs Supabase.
3. Tester un vrai courriel de récupération avec un compte de test.
4. Diagnostiquer séparément la fonction `sspace-ai-community` avec une invocation contrôlée et les journaux applicatifs.
5. Traiter les alertes RLS / SECURITY DEFINER fonction par fonction après validation du modèle d'accès.
