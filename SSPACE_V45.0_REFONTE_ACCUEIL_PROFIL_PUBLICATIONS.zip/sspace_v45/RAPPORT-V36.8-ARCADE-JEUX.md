# SSPACE V36.8 — Arcade : difficulté et records locaux

## Jeux concernés (Bowling conservé sans modification)
- Street Racing 3D : rivalité IA modulée par la difficulté; temps de course enregistré à l'arrivée.
- Survie Sauvage 3D : faim, soif et perte de vie accélérées selon la difficulté; score de progression local.
- Space Defender : fréquence et vitesse des ennemis modulées; score enregistré à la fin de partie.
- Astéroïdes : fréquence et vitesse des météorites modulées; durée de survie enregistrée.
- Alunissage : gravité et consommation de carburant modulées; réussite/échec enregistré.
- Kart Racing reste le mode multijoueur de Messenger et n'a pas été modifié dans cette livraison.

## Fonctions communes
- Sélecteur Facile / Normal / Difficile présent dans les cinq jeux autonomes.
- Panneau de meilleurs résultats et record personnel.
- Conservation des résultats dans le stockage local du navigateur, séparément par jeu.
- Les fichiers jeux-espace sont synchronisés dans les dossiers racine, site, dist et work_sspace.

## Limites et validation
- Les records sont locaux à l'appareil/navigateur : ils ne sont pas encore synchronisés entre comptes et ne constituent pas un classement mondial Supabase.
- Les jeux Three.js (Street Racing et Survie Sauvage) nécessitent une connexion pour charger Three.js depuis le CDN déjà utilisé.
- Vérification statique de la syntaxe JavaScript et de l'intégrité ZIP effectuée; aucun test tactile sur appareil Android, test multi-comptes ou déploiement n'est revendiqué.
