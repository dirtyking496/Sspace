# SSPACE V36.9 — Anniversaires, mur public et notifications

- Ajout du panneau Anniversaires dans la colonne droite; il liste les amis dont la date est partagée et ouvre leur profil pour souhaiter bonne fête.
- Ajout du réglage de date d’anniversaire et du consentement « Afficher à mes amis » dans Paramètres.
- Ajout d’un mur public sur le profil d’un autre membre avec publication de messages et affichage des 30 derniers messages.
- Ajout du geste glisser vers la droite pour marquer une notification comme lue; la couleur verte confirme le geste.
- Les clics de notifications de type message, demande d’ami, visite de profil et interaction publication sont routés vers leur espace.

## Dépendance base de données
La migration `MIGRATION-V36.9-ANNIVERSAIRES-MUR-PROFILS.sql` ajoute les colonnes et la table avec RLS. Elle doit être appliquée avant d’utiliser les nouveaux champs et le mur.

## Limites
Les dates d’anniversaire sont volontairement opt-in. La section n’affiche que les amis acceptés qui ont choisi de partager leur date. Les notifications qui ne contiennent pas d’identifiant de publication exploitable ne peuvent pas pointer vers une publication précise.
