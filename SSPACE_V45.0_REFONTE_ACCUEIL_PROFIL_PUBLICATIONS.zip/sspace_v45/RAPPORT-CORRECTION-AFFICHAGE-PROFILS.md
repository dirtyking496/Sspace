# SSPACE — Correction de l’affichage des profils

## Corrections apportées au code
- Centralisation de la résolution du nom : nom affiché valide, sinon `@pseudo`, puis identifiant court plutôt qu’un libellé générique partagé.
- Application de cette résolution aux membres en ligne, au chat public, aux commentaires d’albums, aux blogs, aux groupes, aux recherches et aux profils.
- Ajout d’un repli visuel lorsqu’une image de profil échoue à charger : les initiales restent visibles au lieu d’un emplacement d’image brisé.
- Conservation des URL et des fichiers de profil existants. Aucune donnée utilisateur ni migration Supabase n’a été modifiée.

## Vérifications
- 7 blocs JavaScript intégrés contrôlés avec `node --check` : réussite.
- Supabase : 16 profils; 16 ont un pseudo; 0 nom affiché reconnu comme valeur générique (`Membre`, `Nouveau membre`, `membre_xxx`); 15 ont une URL de photo, 1 n’en a pas.
- Buckets `post-images` et `profile-albums` : publics; types d’images JPG, PNG, WebP et GIF autorisés.

## Limites
- Le test de syntaxe ne remplace pas un test navigateur connecté avec plusieurs comptes.
- Le build complet n’a pas été certifié : l’installation des dépendances a expiré précédemment.
- Cette archive contient les corrections locales. Elles ne sont pas encore publiées sur le domaine de production `sspaceweb.vercel.app`.
