# SSPACE — intégration complète du profil (base V38 + sources V43)

## Base et fusion
- Base complète : archive SSPACE V38.0 (structure complète, ressources, jeux, backend, configuration de déploiement).
- Éditeur de profil : styles et organisation hiérarchique issus de la source V43 intégrés dans `site/index.html`, avec six panneaux repliables et la première catégorie ouverte par défaut.
- Le même fichier source a été synchronisé dans `work_sspace/site/index.html`.
- Notifications : routage ciblé vers la publication; commentaires/mentions localisés et surlignés; messages privés dirigés vers `/messenger/` avec identifiants de conversation/message quand disponibles.
- Sources Messenger mises à jour depuis V43 dans `messenger/src/` et miroir `work_sspace/messenger/src/`.
- Migrations SQL de confidentialité anniversaire et d'identification hors liste d'amis copiées dans `site/supabase/migrations/` et le miroir `work_sspace/`.
- Les anciens fichiers, ressources, dossiers de jeux, backend et configuration du projet complet ont été conservés.

## Vérifications
- Les 8 blocs JavaScript du site principal passent `node --check`.
- Vérification structurelle : les six catégories de l'éditeur sont générées à partir des champs déjà présents; les identifiants des champs et le gestionnaire de sauvegarde du profil sont conservés.
- `npm run build` a été tenté, mais n'a pas pu aboutir : les dépendances npm (React, Supabase, Vite et types associés) ne sont pas installées et `npm install` a dépassé le délai disponible. Les erreurs TypeScript observées sont principalement des modules/types manquants; aucune compilation complète n'est revendiquée.
- Le dossier `dist/` précompilé de la V38 a été conservé tel quel après l'échec du build. Il ne contient donc pas encore le bundle Messenger recompilé avec les sources V43.
- Aucun déploiement ni migration Supabase n'a été exécuté.

## Déploiement
Installer les dépendances à la racine (`npm install`), lancer `npm run build`, tester en Preview, puis appliquer les migrations SQL requises dans Supabase avant la production.
