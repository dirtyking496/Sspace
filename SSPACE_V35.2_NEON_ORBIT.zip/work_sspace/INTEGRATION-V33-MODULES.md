# Intégration V33 — SSPACE

Le prototype reconstruit V33 est ajouté à `site/SSPACE-V33-MODULES.html`, sans remplacer le site SSPACE existant.
Un accès flottant « Modules V33 » est ajouté à la page principale pour ouvrir ce module.

Cette page V33 fonctionne comme prototype autonome : interactions locales et données de démonstration; elle ne prétend pas être synchronisée avec Supabase. Les fonctionnalités existantes du projet sont préservées.

Le script de build existant copie le dossier `site` vers `dist`, donc le fichier V33 est inclus dans la sortie du site.
