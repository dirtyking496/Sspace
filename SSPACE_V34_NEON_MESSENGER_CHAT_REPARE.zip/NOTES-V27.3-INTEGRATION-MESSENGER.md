# SSPACE V27.3 — Messenger intégré au projet

La livraison principale contient maintenant explicitement les deux applications :

- `site/` : App 1, SSPACE Social.
- `messenger/` : App 2, SSPACE Messenger, code React/TypeScript distinct et installable comme PWA à `/messenger/`.

Le build racine appelle `scripts/copy-site.mjs`, puis `tsc -b messenger/tsconfig.json` et `vite build --config messenger/vite.config.ts`. Le `vite.config.ts` de Messenger utilise `base: '/messenger/'` et produit `dist/messenger/` avec `emptyOutDir: false`, afin de préserver `dist/index.html` du réseau social.

Le bouton Messenger dans SSPACE ouvre l'application sur la même origine. La liaison de session vérifie l'origine, la fenêtre source et un nonce temporaire avant de transmettre les jetons de session Supabase. Messenger réutilise le même projet Supabase et le même compte; aucune seconde authentification métier n'est créée.

Le dossier Messenger reste autonome dans le dépôt et peut aussi être livré dans une archive indépendante. L'archive principale l'inclut pour qu'un seul ZIP contienne l'ensemble du projet SSPACE.

## Validation

Contrôles statiques : présence des fichiers d'entrée, de la configuration Vite, du manifeste PWA, du service worker, du client Supabase et des deux côtés du handshake SSO. Le build complet TypeScript/Vite et les tests en direct ne sont pas déclarés réussis tant qu'ils n'ont pas été exécutés avec les dépendances et le projet Supabase de déploiement.
