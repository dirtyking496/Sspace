# SSPACE — Corrections de l'espace de jeux

## Bowling
- Piste redimensionnée en format paysage 16:9, au lieu du cadrage portrait trop haut sur mobile.
- Hauteur limitée selon la hauteur d'écran pour garder les commandes accessibles.
- Manche, score et tableau des dix manches déplacés au-dessus de la piste pour rester visibles.
- Redimensionnement du canvas protégé lorsque son conteneur n'a pas encore de dimensions.

## Space Defender
- Ajout de commandes tactiles Gauche / Droite / Tirer / Rejouer.
- Ajout d'un score et d'un état de partie visibles au-dessus du canvas.
- Les commandes clavier restent disponibles.

## Astéroïdes
- Déplacement au doigt avec Pointer Events et conversion correcte des coordonnées lorsque le canvas est réduit.
- Ajout d'un pavé directionnel tactile et d'un bouton Rejouer.
- Temps de survie et état affichés au-dessus du jeu.

## Alunissage
- Ajout de boutons tactiles Gauche / Droite / Propulseur / Rejouer.
- Affichage du carburant et de l'état de vol au-dessus du canvas.
- Les commandes clavier restent disponibles.

## Navigation des jeux
- Grille de jeux responsive : deux colonnes sur grand écran et une colonne sur téléphone.
- Les pages source `jeux-espace/` et les copies de déploiement `dist/jeux-espace/` sont synchronisées.

## Contrôles effectués
- Vérification `node --check` des scripts JavaScript intégrés aux quatre jeux : réussie.
- Vérification des identifiants HTML en double sur les cinq pages de jeux : aucun détecté.
- Les tentatives de lancement Chromium headless dans cet environnement ont expiré; aucun test visuel navigateur/appareil réel n'est donc revendiqué.
- Aucun build global Vite/TypeScript n'a été exécuté dans cette passe : les changements portent sur les pages HTML autonomes de l'espace de jeux.
