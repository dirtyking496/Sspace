# SSPACE V32 — Marché d'émeraudes, blogs et chasse aux trésors

## Intégrations
- Marché d'émeraudes avec offres, acceptation, annulation/remboursement et historique.
- Fonctions transactionnelles Supabase `gem_trade_create`, `gem_trade_accept`, `gem_trade_cancel`.
- Page Blogs SSPACE : publication, liste, détail, compteur de vues et commentaires.
- Tables `blogs`, `blog_comments`, `group_messages`, `treasure_events`, `treasure_gems`, `treasure_hint_unlocks`. Le chat des groupes est ajouté à la vue Groupes et les messages sont réservés aux membres acceptés.
- Indices progressifs déclenchés quotidiennement par `pg_cron` à 08:00 UTC; les cibles hebdomadaires sont initialisées depuis les articles, profils et messages de groupes existants.
- Suggestions hebdomadaires croisées avec les articles `blogs`, l'archive `memory_blog_articles`, les groupes publics et les événements.
- RLS : propriétaires pour les modifications d'articles, membres acceptés pour lire/écrire les messages de groupe, participants uniquement pour l'historique des échanges.

## Adaptation nécessaire au schéma réel
Le projet n'utilise pas `users(id)` integer ni un stock quantitatif `user_gems`. Il utilise Supabase Auth UUID (`auth.users` / `profiles`), `emerald_catalog` et `emerald_collection`, dont la clé primaire `(user_id, emerald_id)` signifie qu'une émeraude est unique par collection. Le marché autorise donc une unité par offre (`quantity = 1`), mise en réserve en la retirant de la collection; l'annulation la restitue. Les échanges sont atomiques dans une fonction SQL et les appels concurrents sont sérialisés par verrouillage de l'offre.

Les familles sont dérivées des cinq pages existantes du catalogue : Classiques, Précieuses, Prismatiques, Cosmiques et Légendaires.

## Limites / vérifications
- La base a reçu les tables, politiques et fonctions; le cron `sspace-treasure-hints-daily` est actif.
- Au moment de l'intégration, il n'y avait encore aucune offre, aucun article de blog ni commentaire. La chasse a une semaine active et ses cibles de profils sont initialisées; les indices se débloquent à partir du mercredi selon le calendrier.
- Aucun test transactionnel multi-compte n'a été possible sans deux comptes de test. Le build Vite complet reste à effectuer si les dépendances ne sont pas disponibles.
- Les pages Blog et Marché sont intégrées dans l'application SSPACE principale. Messenger reste un client indépendant et n'est pas fusionné dans le frontend social.

## Contrôles exécutés
- Les blocs JavaScript intégrés à `site/index.html` passent `node --check`.
- Les fichiers backend `.cjs` passent le contrôle syntaxique Node.
- Les tables, fonctions RPC, permissions RLS et deux tâches `pg_cron` ont été relues dans Supabase.
- Le job de suggestions mémoire reste actif chaque lundi à 03:00 UTC; le job des indices est actif chaque jour à 08:00 UTC.
- Le script `scripts/copy-site.mjs` a copié avec succès le site dans `dist/`.
- `npm run build` ne peut pas finir ici : les dépendances `react`, `@supabase/supabase-js`, `vite` et leurs types ne sont pas installés. Les erreurs TypeScript JSX qui en découlent ne constituent donc pas un build vérifié.
- Aucun échange entre deux comptes réels ni publication/commentaire via deux sessions distinctes n'a été simulé. La validation transactionnelle multi-utilisateur reste à faire après installation des dépendances et avec des comptes de test.
