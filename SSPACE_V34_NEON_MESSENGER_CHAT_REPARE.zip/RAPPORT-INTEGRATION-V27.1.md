# SSPACE V27.1 — rapport d’intégration

## Changements

1. Ajout d’un accès compact SSPACE LIVE à côté du bandeau des membres sur l’accueil; ouverture d’un salon public plein écran.
2. Salon public connecté à Supabase Realtime et à une table persistante : messages, 100 derniers messages chargés, présence, émojis, GIF, profils cliquables, sourdine personnelle, blocage et signalements.
3. Ajout d’un panneau de signalements LIVE au Centre MODO, contrôlé par la permission `reports`.
4. Amélioration de la section de vote des profils existante : boutons verts/rouges lumineux et affichage des pourcentages positifs et négatifs. Le RPC `profile_vote_cast` et sa contrainte un vote par profil sont conservés.
5. Dans la visionneuse d’album, ajout des noms cliquables des membres ayant aimé la photo, en plus du nombre de J’aime.
6. Badge vérifié transformé en mini-crochet arc-en-ciel animé avec rotation et flash blanc; aucun texte ajouté au nom. La protection SQL et le processus de demande/approbation MODO sont conservés; une notification est envoyée à l’issue de la décision.
7. Invalidation du cache PWA principal.

## À faire dans Supabase

Appliquer `site/supabase/migrations/20261123001000_sspace_live_chat_and_verification_notifications.sql` une seule fois. Vérifier que les migrations album, réputation et vérification précédentes sont déjà appliquées.

## Vérifications effectuées ici

- Archive source initiale : intégrité ZIP valide.
- Syntaxe des 6 blocs JavaScript inline : `node --check` réussi, aucune erreur.
- Identifiants HTML statiques : 557 analysés, aucun identifiant dupliqué.
- `dist/index.html` synchronisé avec `site/index.html`; migration V27.1 présente dans `dist/supabase/migrations`.
- Le téléchargement de dépendances npm a expiré dans cet environnement; le build complet TypeScript/Vite ne peut donc pas être certifié ici.
- Pas de connexion administrative à Supabase ni de deux comptes de test disponibles dans cet environnement : Realtime, RLS et flux de vérification doivent être testés après application de la migration, sur une Preview HTTPS.


## Compléments de durcissement de l'API Express

- Vérification de chaque access token directement auprès de Supabase Auth, sans cache local de session.
- Répertoire d'upload résolu relativement à `backend/`, hors du dossier statique public.
- Limite d'upload appliquée avant réception complète du fichier, avec réponse HTTP 413 en cas de dépassement.
- Validation du format UUID des identifiants de profil et de média avant requête SQL.
- Limites applicatives alignées sur la contrainte de taille maximale de 50 Mo de la migration.

## État final de cette préparation

- Les quatre fichiers JavaScript du backend passent `node --check`.
- La migration SQL, les routes et le client TypeScript sont présents dans l'archive.
- Le build complet du frontend n'a pas pu être validé : les dépendances `react`, `vite` et `@supabase/supabase-js` ne sont pas installées dans l'environnement, et la tentative d'installation npm a expiré. Il faut exécuter `npm install` dans un environnement avec accès au registre npm puis `npm run build`.
- L'API n'est pas déployée et la migration n'est pas appliquée au projet distant. Le téléversement d'album Social actuel reste inchangé pour préserver les fonctions existantes; les nouveaux endpoints sont complémentaires.
