# SSPACE V17.2 — Navigation, emblèmes GIF et publication

## Changements
- Le logo SSPACE dans l’en-tête ramène à l’accueil depuis toutes les sections et ferme les fenêtres/tiroirs ouverts.
- La sélection de l’emblème du nom est accessible en touchant le nom du profil ou via le bouton de galerie dans l’éditeur.
- La galerie complète propose les emojis et emblèmes, avec un accès au sélecteur GIF existant pour choisir un emblème animé GIPHY/Tenor.
- Le champ `profiles.name_icon` accepte maintenant les URL GIF de confiance (jusqu’à 600 caractères). La migration SQL correspondante est incluse et a été appliquée au projet Supabase `sikxoyylihsigzirewmi`.
- Alex (🎧) est placé dans l’en-tête près de Messenger.
- Le menu principal commence par un gros bouton rouge PUBLIER, suivi des notifications/demandes d’amis. Le bouton de déconnexion du menu est compact.
- Le formulaire de publication s’affiche en panneau superposé défilant pour ne plus être caché par les éléments du fil d’accueil; les actions restent accessibles en bas du panneau.
- Le cache du service worker est renouvelé pour forcer le chargement des nouveaux fichiers.

## Vérifications
- Les scripts JavaScript intégrés de `site/index.html` et `dist/index.html` passent `node --check`.
- Les deux versions HTML ont été synchronisées.
- La migration Supabase `name_icon_support_gif_emblems` a été appliquée.
- Publication Vercel non effectuée depuis cet environnement.
