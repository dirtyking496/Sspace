# SSPACE V33 — archive unifiée Social + Messenger

- Social : dossier `site/`, publié à `/`.
- Messenger intégré : dossier `messenger/`, publié à `/messenger/` par le build racine.
- Messenger autonome : archive séparée `SSPACE_MESSENGER_V33_AUTONOME.zip`.
- Jeux : `jeux-espace/`.
- Gemmes / marché / blogs / chasse : migrations Supabase sous `site/supabase/migrations/`, notamment `20261123012000_gem_market_blogs_treasure.sql`.
- Backend Express : `backend/`.
- Build Vercel configuré par `package.json`, `scripts/copy-site.mjs`, `messenger/vite.config.ts` et `vercel.json`.

## Contrôles effectués sur cette archive

- Archive ZIP lisible et intégrité CRC vérifiée.
- Présence des fichiers principaux Social, Messenger, jeux, backend et migrations gemmes vérifiée.
- Les configurations JSON ont été analysées.
- La compilation complète et les tests réels entre deux appareils ne sont pas certifiés dans cette livraison.
- Aucune migration n'est exécutée sur le projet Supabase distant par la création de cette archive.
