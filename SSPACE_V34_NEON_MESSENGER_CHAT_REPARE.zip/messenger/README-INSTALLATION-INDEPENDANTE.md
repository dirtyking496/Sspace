# SSPACE Messenger — application indépendante

Cette archive est le paquet séparé de l’application Messenger (App 2). Elle n’embarque pas SSPACE Social et ne crée pas de deuxième identité : elle utilise le même projet Supabase et les mêmes comptes SSPACE.

## Développement et build

1. Installer Node.js 20 ou plus récent.
2. Copier `.env.example` vers `.env.local` et renseigner `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` du même projet Supabase que SSPACE Social. La clé publique `anon`/`publishable` peut être utilisée côté navigateur; ne jamais mettre la clé `service_role`.
3. `npm install`
4. `npm run build`
5. Publier le contenu de `dist/` comme un site indépendant (Vercel ou Netlify).

## Connexion à SSPACE

Les deux applications doivent pointer vers le même projet Supabase. Les membres utilisent leur compte SSPACE habituel dans Messenger. Si les apps sont sur deux domaines différents, la session du navigateur n’est pas partagée automatiquement : l’utilisateur se connecte une fois dans Messenger avec le même compte.

Dans Supabase > Authentication > URL Configuration, ajouter les URL de production et de prévisualisation de Messenger aux URL autorisées.

## Capacités / limites

- Application PWA installable depuis le navigateur; ce ZIP source ne constitue pas un APK Android natif.
- Conversations et présence utilisent les tables/canaux Supabase déjà configurés dans le projet.
- Les appels audio/vidéo nécessitent HTTPS, permissions micro/caméra et peuvent nécessiter un serveur TURN pour certains réseaux.
- Ne publie jamais de clé `service_role` ni de secret TURN permanent dans les variables `VITE_*`.

### Mise à jour V31 — souvenirs et suggestions
Appliquer aussi `supabase-migration-memory-blog-clan.sql` sur le même projet Supabase SSPACE avant de tester les suggestions blog/clan. Le centre de mémoire sélectionne maintenant les photos de l'album et les médias des publications du compte connecté.
