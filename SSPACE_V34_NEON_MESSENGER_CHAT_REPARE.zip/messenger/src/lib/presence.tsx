type P = { last_seen_at?: string | null; show_online?: boolean | null } | null | undefined;

export function awayShort(value?: string | null): string {
  if (!value) return '';
  const t = Date.parse(value);
  if (Number.isNaN(t)) return '';
  const min = Math.max(0, Math.floor((Date.now() - t) / 60000));
  if (min < 1) return '1 min';
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} h`;
  const d = Math.floor(h / 24);
  return d < 7 ? `${d} j` : '7 j+';
}

export function isOnlineNow(p: P): boolean {
  if (!p || p.show_online === false) return false;
  if (!p.last_seen_at) return true;
  return Date.now() - Date.parse(p.last_seen_at) < 90_000;
}

// Point vert si en ligne, sinon mini bulle avec le temps écoulé depuis la déconnexion.
export function PresenceBadge({ person, online }: { person: P; online?: boolean }) {
  if (!person || person.show_online === false) return null;
  if (online || isOnlineNow(person)) return <i className="pres-dot" title="En ligne" aria-label="En ligne" />;
  const t = awayShort(person.last_seen_at);
  return t ? <i className="pres-bubble" title={`Hors ligne depuis ${t}`} aria-label={`Hors ligne depuis ${t}`}>{t}</i> : null;
}
