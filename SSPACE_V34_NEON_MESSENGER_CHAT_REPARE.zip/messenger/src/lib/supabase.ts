import { createClient } from '@supabase/supabase-js';

// Projet Supabase SIKX partagé avec SSPACE Social (même URL et même clé publique que site/index.html).
// La clé « publishable » est publique par conception : la sécurité repose sur les politiques RLS.
// Les variables VITE_* restent prioritaires ; les valeurs ci-dessous évitent l'écran « Configuration requise »
// si le fichier .env.production est absent au moment du build.
const FALLBACK_URL = 'https://sikxoyylihsigzirewmi.supabase.co';
const FALLBACK_KEY = 'sb_publishable_JAMkNnPlM4_Evk1wKrSgmg_--wnErZj';

const envUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim();
const envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim();
const url = envUrl && !envUrl.includes('PASTE') ? envUrl : FALLBACK_URL;
const anonKey = envKey && !envKey.includes('PASTE') ? envKey : FALLBACK_KEY;

export const isSupabaseConfigured = Boolean(url && anonKey);
export const supabase = isSupabaseConfigured ? createClient(url, anonKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
  realtime: { params: { eventsPerSecond: 10 } }
}) : null;
