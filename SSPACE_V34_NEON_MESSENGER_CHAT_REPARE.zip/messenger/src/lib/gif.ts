// Recherche de GIF via GIPHY. Clé gratuite : https://developers.giphy.com (Create an App → API)
// À définir dans Vercel : VITE_GIPHY_API_KEY
export type GifItem = { id: string; title: string; preview: string; url: string };
export const gifEnabled = Boolean(import.meta.env.VITE_GIPHY_API_KEY);

export async function fetchGifs(query: string, signal?: AbortSignal): Promise<GifItem[]> {
  const key = import.meta.env.VITE_GIPHY_API_KEY as string | undefined;
  if (!key) throw new Error('Clé GIPHY manquante (VITE_GIPHY_API_KEY).');
  const q = query.trim();
  const endpoint = q ? 'search' : 'trending';
  const params = new URLSearchParams({ api_key: key, limit: '30', rating: 'pg-13', lang: 'fr' });
  if (q) params.set('q', q);
  const res = await fetch(`https://api.giphy.com/v1/gifs/${endpoint}?${params}`, { signal });
  if (!res.ok) throw new Error('GIPHY a répondu ' + res.status);
  const json = await res.json();
  return (json.data ?? []).map((g: any) => ({
    id: g.id,
    title: g.title || 'GIF',
    preview: g.images?.fixed_width_small?.url || g.images?.fixed_width?.url,
    url: g.images?.fixed_height?.url || g.images?.original?.url,
  })).filter((g: GifItem) => g.preview && g.url);
}
