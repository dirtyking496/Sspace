import { supabase } from './supabase';

const API_URL = (import.meta.env.VITE_PROFILE_API_URL as string | undefined)?.trim().replace(/\/$/, '');

export type SspaceProfile = {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  status_text: string | null;
};

export type ProfileMedia = {
  id: string;
  media_type: 'photo' | 'video';
  mime_type: string;
  size_bytes: number;
  created_at: string;
  content_url: string;
};

async function request<T>(route: string, init: RequestInit = {}): Promise<T> {
  if (!supabase) throw new Error('La session Supabase SSPACE n’est pas configurée.');
  if (!API_URL) throw new Error('VITE_PROFILE_API_URL n’est pas configurée.');
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error('Connecte-toi à SSPACE pour continuer.');
  const headers = new Headers(init.headers);
  headers.set('Authorization', `Bearer ${data.session.access_token}`);
  if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json');
  const response = await fetch(`${API_URL}${route}`, { ...init, headers, credentials: 'omit' });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Erreur API (${response.status}).`);
  return payload as T;
}

export async function getMyProfile() {
  return request<{ profile: SspaceProfile }>('/api/profil/me');
}

export async function getProfile(userId: string) {
  return request<{ profile: SspaceProfile }>(`/api/profil/${encodeURIComponent(userId)}`);
}

export async function getProfileMedia(userId: string) {
  return request<{ media: ProfileMedia[] }>(`/api/profil/${encodeURIComponent(userId)}/media`);
}

export async function uploadProfileMedia(file: File, type: 'photo' | 'video') {
  const form = new FormData();
  form.append('file', file);
  return request<{ media: ProfileMedia }>(`/api/profil/me/${type}`, { method: 'POST', body: form });
}

export async function deleteProfileMedia(mediaId: string) {
  return request<{ ok: true }>(`/api/profil/media/${encodeURIComponent(mediaId)}`, { method: 'DELETE' });
}

export async function loadProfileMediaObjectUrl(media: ProfileMedia): Promise<string> {
  if (!supabase || !API_URL) throw new Error('API profil ou session Supabase non configurée.');
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.access_token) throw new Error('Connecte-toi à SSPACE pour afficher ce média.');
  const response = await fetch(`${API_URL}${media.content_url}`, {
    headers: { Authorization: `Bearer ${data.session.access_token}` },
    credentials: 'omit'
  });
  if (!response.ok) throw new Error('Impossible de charger ce média.');
  return URL.createObjectURL(await response.blob());
}
