// Configuration ICE (STUN + TURN) pour les appels et LIVE de Messenger.
// Sources TURN, par ordre de priorité :
//  1. VITE_TURN_API_URL : URL JSON renvoyant un tableau iceServers (identifiants temporaires,
//     ex. Metered / Cloudflare / Twilio via une fonction serveur)
//  2. Réglages enregistrés dans ce navigateur (même clé que SSPACE LIVE : 'sspace-live-turn-v1')
//  3. Variables VITE_TURN_URLS / VITE_TURN_USERNAME / VITE_TURN_CREDENTIAL
export type TurnConfig = { urls: string; username: string; credential: string };
export const TURN_STORAGE_KEY = 'sspace-live-turn-v1';

const STUN: RTCIceServer = { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] };

export function loadTurnConfig(): TurnConfig {
  const env = import.meta.env;
  const base: TurnConfig = {
    urls: (env.VITE_TURN_URLS as string | undefined) ?? '',
    username: (env.VITE_TURN_USERNAME as string | undefined) ?? '',
    credential: (env.VITE_TURN_CREDENTIAL as string | undefined) ?? '',
  };
  try {
    const saved = JSON.parse(localStorage.getItem(TURN_STORAGE_KEY) || '{}');
    if (saved && typeof saved.urls === 'string' && saved.urls.trim()) {
      return { urls: saved.urls, username: saved.username ?? '', credential: saved.credential ?? '' };
    }
  } catch { /* ignore */ }
  return base;
}

export function saveTurnConfig(cfg: TurnConfig) {
  localStorage.setItem(TURN_STORAGE_KEY, JSON.stringify(cfg));
}

function validUrls(raw: string): string[] {
  return raw.split(',').map(v => v.trim()).filter(v => /^turns?:/i.test(v));
}

export async function getIceServers(): Promise<RTCIceServer[]> {
  const servers: RTCIceServer[] = [STUN];
  const apiUrl = import.meta.env.VITE_TURN_API_URL as string | undefined;
  if (apiUrl) {
    try {
      const ctrl = new AbortController();
      const timer = window.setTimeout(() => ctrl.abort(), 4000);
      const res = await fetch(apiUrl, { signal: ctrl.signal, cache: 'no-store' });
      window.clearTimeout(timer);
      if (res.ok) {
        const data = await res.json();
        const list = Array.isArray(data) ? data : data?.iceServers;
        if (Array.isArray(list) && list.length) return [STUN, ...list];
      }
    } catch (err) { console.warn('TURN API indisponible, repli sur la config locale', err); }
  }
  const cfg = loadTurnConfig();
  const urls = validUrls(cfg.urls);
  if (urls.length) servers.push({ urls, username: cfg.username || undefined, credential: cfg.credential || undefined });
  return servers;
}

export function hasTurn(): boolean {
  return !!(import.meta.env.VITE_TURN_API_URL as string | undefined) || validUrls(loadTurnConfig().urls).length > 0;
}
