import { useEffect, useState } from 'react';
import { EMOJI_CATEGORIES } from '../lib/emoji';
import { fetchGifs, gifEnabled } from '../lib/gif';
import type { GifItem } from '../lib/gif';

type Props = { onEmoji: (emoji: string) => void; onGif: (gif: GifItem) => void; onClose: () => void };

export default function EmojiGifPicker({ onEmoji, onGif, onClose }: Props) {
  const [tab, setTab] = useState<'emoji' | 'gif'>('emoji');
  const [cat, setCat] = useState(EMOJI_CATEGORIES[0].id);
  const [query, setQuery] = useState('');
  const [gifs, setGifs] = useState<GifItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (tab !== 'gif' || !gifEnabled) return;
    const ctrl = new AbortController();
    const timer = window.setTimeout(async () => {
      setLoading(true); setError('');
      try { setGifs(await fetchGifs(query, ctrl.signal)); }
      catch (e: any) { if (e?.name !== 'AbortError') setError(e?.message ?? 'GIF indisponibles.'); }
      finally { setLoading(false); }
    }, query ? 350 : 0);
    return () => { window.clearTimeout(timer); ctrl.abort(); };
  }, [tab, query]);

  const current = EMOJI_CATEGORIES.find(c => c.id === cat) ?? EMOJI_CATEGORIES[0];
  return (
    <div className="picker-panel" role="dialog" aria-label="Émojis et GIF">
      <div className="picker-tabs">
        <button type="button" className={tab === 'emoji' ? 'active' : ''} onClick={() => setTab('emoji')}>😊 Émojis</button>
        <button type="button" className={tab === 'gif' ? 'active' : ''} onClick={() => setTab('gif')}>GIF</button>
        <button type="button" className="picker-close" aria-label="Fermer" onClick={onClose}>✕</button>
      </div>
      {tab === 'emoji' ? <>
        <div className="emoji-cats">{EMOJI_CATEGORIES.map(c => <button type="button" key={c.id} title={c.label} className={c.id === cat ? 'active' : ''} onClick={() => setCat(c.id)}>{c.icon}</button>)}</div>
        <div className="emoji-grid">{current.items.map((e, i) => <button type="button" key={e + i} onClick={() => onEmoji(e)}>{e}</button>)}</div>
      </> : <>
        {!gifEnabled ? <p className="picker-msg">Les GIF nécessitent une clé GIPHY gratuite : ajoute <code>VITE_GIPHY_API_KEY</code> dans les variables d’environnement Vercel puis redéploie.</p> : <>
          <input className="gif-search" placeholder="Rechercher un GIF (ex. bravo, rire, amour)…" value={query} onChange={e => setQuery(e.target.value)} />
          {error && <p className="picker-msg">{error}</p>}
          {loading && <p className="picker-msg">Chargement…</p>}
          <div className="gif-grid">{gifs.map(g => <button type="button" key={g.id} title={g.title} onClick={() => onGif(g)}><img src={g.preview} alt={g.title} loading="lazy" /></button>)}</div>
          <small className="giphy-credit">Propulsé par GIPHY</small>
        </>}
      </>}
    </div>
  );
}
