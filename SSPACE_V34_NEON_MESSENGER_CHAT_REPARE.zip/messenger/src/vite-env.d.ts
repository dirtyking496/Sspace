/// <reference types="vite/client" />
interface ImportMetaEnv { readonly VITE_SSPACE_SOCIAL_URL?: string }
interface ImportMeta { readonly env: ImportMetaEnv }
