-- SSPACE Messenger: private two-player game rooms and Realtime Broadcast authorization.
create table if not exists public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  game text not null check (game in ('street-racing','bowling','kart-racing')),
  player_one uuid not null references auth.users(id) on delete cascade,
  player_two uuid not null references auth.users(id) on delete cascade,
  status text not null default 'waiting' check (status in ('waiting','active','finished','cancelled')),
  state jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint game_rooms_two_distinct_players check (player_one <> player_two)
);
create index if not exists game_rooms_conversation_recent_idx on public.game_rooms(conversation_id, created_at desc);
create index if not exists game_rooms_players_idx on public.game_rooms(player_one, player_two, created_at desc);

alter table public.game_rooms enable row level security;
revoke all on public.game_rooms from anon;
grant select, insert on public.game_rooms to authenticated;
grant update (status, state) on public.game_rooms to authenticated;

drop policy if exists game_rooms_read_participants on public.game_rooms;
create policy game_rooms_read_participants on public.game_rooms
for select to authenticated
using ((select auth.uid()) in (player_one, player_two));

drop policy if exists game_rooms_create_conversation_pair on public.game_rooms;
create policy game_rooms_create_conversation_pair on public.game_rooms
for insert to authenticated
with check (
  player_one = (select auth.uid())
  and exists (
    select 1 from public.conversations c
    where c.id = conversation_id
      and ((c.user_one = (select auth.uid()) and c.user_two = player_two)
        or (c.user_two = (select auth.uid()) and c.user_one = player_two))
  )
);

drop policy if exists game_rooms_update_participants on public.game_rooms;
drop policy if exists game_rooms_update_host on public.game_rooms;
create policy game_rooms_update_host on public.game_rooms
for update to authenticated
using ((select auth.uid()) = player_one)
with check ((select auth.uid()) = player_one);

-- Private Realtime topics are named game-room:<room UUID>.
-- Only the two participants may subscribe and broadcast to that topic.
drop policy if exists messenger_game_room_broadcast_read on realtime.messages;
create policy messenger_game_room_broadcast_read on realtime.messages
for select to authenticated
using (
  extension = 'broadcast'
  and exists (
    select 1 from public.game_rooms r
    where realtime.topic() = 'game-room:' || r.id::text
      and (select auth.uid()) in (r.player_one, r.player_two)
  )
);

drop policy if exists messenger_game_room_broadcast_write on realtime.messages;
create policy messenger_game_room_broadcast_write on realtime.messages
for insert to authenticated
with check (
  extension = 'broadcast'
  and exists (
    select 1 from public.game_rooms r
    where realtime.topic() = 'game-room:' || r.id::text
      and (select auth.uid()) in (r.player_one, r.player_two)
  )
);

create or replace function public.sspace_game_room_touch_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
drop trigger if exists game_rooms_touch_updated_at on public.game_rooms;
create trigger game_rooms_touch_updated_at before update on public.game_rooms
for each row execute function public.sspace_game_room_touch_updated_at();
