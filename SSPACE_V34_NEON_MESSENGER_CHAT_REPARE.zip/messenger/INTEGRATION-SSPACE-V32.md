# Messenger indépendant — SSPACE V32

Messenger demeure une application Vite/React autonome et téléchargeable séparément. Il se connecte au même projet Supabase et à la même identité Auth que SSPACE; il n'embarque pas le frontend social dans son application.

Le marché d'émeraudes, les blogs, les messages de groupes et la chasse aux indices sont des modules du site social SSPACE. Leur migration SQL est fournie ici pour garder les instructions d'intégration à portée de main; leur interface est dans `site/index.html` du ZIP complet, pas dans Messenger.

Pour installer Messenger seul : `npm install`, puis `npm run build`. Le build n'a pas pu être exécuté dans l'environnement de préparation parce que les dépendances npm n'étaient pas présentes.
