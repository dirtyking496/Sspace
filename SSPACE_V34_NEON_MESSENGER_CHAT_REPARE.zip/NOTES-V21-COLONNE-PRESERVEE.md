# SSPACE V21 — Colonne de navigation préservée

Cette version repart de l'archive SSPACE V20 fournie dans la conversation.

## Garantie de conservation
- Le bloc HTML `#mainMenu` (colonne/tiroir de navigation) est identique octet pour octet à celui de l'archive originale `SSPACE_JEUX_HD_REALISTES_CORRIGE_VERCEL_GEMMES_COULEUR.zip`.
- Aucun élément, libellé, ordre de rubrique, raccourci, bouton ou lien de cette colonne n'a été supprimé ou renommé.
- Les ajouts V20 (centre médias et hub découverte) sont conservés séparément; ils ne remplacent pas le contenu de la colonne.

## Limites de vérification
La comparaison confirme la conservation du HTML de la colonne. Cela ne constitue pas une validation de bout en bout de tous les boutons, services distants, droits Supabase ou du déploiement en production.
