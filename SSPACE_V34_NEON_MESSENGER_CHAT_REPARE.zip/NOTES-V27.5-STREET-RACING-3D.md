# V27.5 — Street Racing 3D

Ajout de `jeux-espace/street-racing-3d.html` et de sa carte dans le hub `jeux-espace/index.html`.

Fonctionnalités :
- Circuit ovale 3D avec asphalte, bordures, ligne de départ/arrivée, gantry, végétation, éclairage, ciel et brouillard.
- Voiture joueur construite en meshes 3D (carrosserie, vitrage, roues, jantes, phares et feux).
- Quatre voitures rivales animées sur le circuit.
- Accélération, freinage, direction, inertie, perte d'adhérence hors piste et caméra de poursuite.
- Compteur km/h, chronomètre, tours et écran de fin/rejouer.
- Commandes tactiles avec Pointer Events et commandes clavier.
- Mise à l'échelle responsive pour mobile et bureau.

Validation effectuée : `node --check` sur le module JavaScript inline. Vérification de la présence du lien dans le hub et de l'archive ZIP.

Limites connues : Three.js est chargé depuis jsDelivr (connexion Internet requise). Le rendu WebGL et les commandes n'ont pas encore été testés sur un appareil Android physique ni dans un navigateur automatisé. Le jeu est une course solo contre des voitures rivales pilotées sur une trajectoire prédéfinie, pas un multijoueur en ligne.
