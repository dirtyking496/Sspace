-- SSPACE v6 — DÉJÀ APPLIQUÉE au projet Supabase « Sspace » le 16 nov. 2026. Ne pas rejouer (copie de référence).
-- Gardée ici comme trace. Additive et idempotente : ne rien rejouer.

alter table public.posts add column if not exists edited_at timestamptz;
alter table public.posts add column if not exists text_effect text not null default 'none';
alter table public.posts drop constraint if exists posts_text_effect_check;
alter table public.posts add constraint posts_text_effect_check
  check (text_effect in ('none','marquee','roll','typewriter','neon','rainbow','shimmer','wave','bounce','float'));

alter table public.profiles add column if not exists cover_url text;
alter table public.profiles drop constraint if exists profiles_cover_url_check;
alter table public.profiles add constraint profiles_cover_url_check
  check (cover_url is null or (length(cover_url) <= 1000 and cover_url ~ '^https://'));

-- Droits de mise à jour limités colonne par colonne dans cette base : on autorise seulement les nouvelles colonnes.
grant update (edited_at, text_effect) on public.posts to authenticated;
grant update (cover_url) on public.profiles to authenticated;
