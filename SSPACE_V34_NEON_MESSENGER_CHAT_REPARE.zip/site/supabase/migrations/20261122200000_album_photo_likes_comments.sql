-- SSPACE : j'aime + commentaires sur les photos d'album de profil.
-- Idempotent. A executer dans Supabase SQL Editor.

create or replace function public.album_users_blocked(a uuid, b uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.user_blocks x
    where (x.blocker_id = a and x.blocked_id = b) or (x.blocker_id = b and x.blocked_id = a)
  );
$$;
revoke all on function public.album_users_blocked(uuid, uuid) from public, anon;
grant execute on function public.album_users_blocked(uuid, uuid) to authenticated;

create table if not exists public.album_photo_likes (
  photo_id uuid not null references public.profile_album_photos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (photo_id, user_id)
);
create index if not exists album_photo_likes_user_idx on public.album_photo_likes(user_id);

create table if not exists public.album_photo_comments (
  id uuid primary key default gen_random_uuid(),
  photo_id uuid not null references public.profile_album_photos(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(btrim(content)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists album_photo_comments_photo_idx on public.album_photo_comments(photo_id, created_at);
create index if not exists album_photo_comments_user_idx on public.album_photo_comments(user_id);

alter table public.album_photo_likes enable row level security;
alter table public.album_photo_comments enable row level security;
revoke all on public.album_photo_likes, public.album_photo_comments from anon;
grant select, insert, delete on public.album_photo_likes to authenticated;
grant select, insert, delete on public.album_photo_comments to authenticated;

drop policy if exists "Album likes readable by members" on public.album_photo_likes;
create policy "Album likes readable by members" on public.album_photo_likes for select to authenticated using (true);
drop policy if exists "Members like album photos" on public.album_photo_likes;
create policy "Members like album photos" on public.album_photo_likes for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and not public.album_users_blocked((select auth.uid()), (select p.user_id from public.profile_album_photos p where p.id = photo_id))
  );
drop policy if exists "Members remove own album likes" on public.album_photo_likes;
create policy "Members remove own album likes" on public.album_photo_likes for delete to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Album comments readable by members" on public.album_photo_comments;
create policy "Album comments readable by members" on public.album_photo_comments for select to authenticated using (true);
drop policy if exists "Members comment album photos" on public.album_photo_comments;
create policy "Members comment album photos" on public.album_photo_comments for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and not public.album_users_blocked((select auth.uid()), (select p.user_id from public.profile_album_photos p where p.id = photo_id))
  );
drop policy if exists "Authors or album owners delete album comments" on public.album_photo_comments;
create policy "Authors or album owners delete album comments" on public.album_photo_comments for delete to authenticated
  using (
    (select auth.uid()) = user_id
    or (select auth.uid()) = (select p.user_id from public.profile_album_photos p where p.id = photo_id)
  );
