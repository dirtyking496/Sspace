-- SSPACE community groups: creation, discovery, membership requests and approval.
-- Already applied to the connected Supabase project for this delivery.
create table if not exists public.groups (
 id uuid primary key default gen_random_uuid(),
 name text not null check (char_length(btrim(name)) between 3 and 60),
 description text not null default '' check (char_length(description) <= 1000),
 visibility text not null default 'public' check (visibility in ('public','private')),
 created_by uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.group_members (
 id uuid primary key default gen_random_uuid(),
 group_id uuid not null references public.groups(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 role text not null default 'member' check (role in ('owner','admin','member')),
 status text not null default 'pending' check (status in ('pending','accepted')),
 created_at timestamptz not null default now(),
 unique(group_id,user_id)
);
create index if not exists groups_visibility_created_idx on public.groups(visibility,created_at desc);
create index if not exists group_members_user_status_idx on public.group_members(user_id,status);
create index if not exists group_members_group_status_idx on public.group_members(group_id,status);
alter table public.groups enable row level security;
alter table public.group_members enable row level security;
revoke all on table public.groups,public.group_members from anon;
grant select,insert,update,delete on public.groups to authenticated;
grant select,insert,delete on public.group_members to authenticated;
revoke update on public.group_members from authenticated;
grant update(status) on public.group_members to authenticated;

drop policy if exists "groups visible to members" on public.groups;
drop policy if exists "authenticated members can discover groups" on public.groups;
create policy "authenticated members can discover groups" on public.groups for select to authenticated using (true);
drop policy if exists "members create groups" on public.groups;
create policy "members create groups" on public.groups for insert to authenticated with check (created_by=(select auth.uid()));
drop policy if exists "owners update groups" on public.groups;
create policy "owners update groups" on public.groups for update to authenticated using (created_by=(select auth.uid())) with check (created_by=(select auth.uid()));
drop policy if exists "owners delete groups" on public.groups;
create policy "owners delete groups" on public.groups for delete to authenticated using (created_by=(select auth.uid()));

create or replace function private.add_group_creator_as_owner()
returns trigger language plpgsql security definer set search_path=''
as $$ begin
 insert into public.group_members(group_id,user_id,role,status)
 values(new.id,new.created_by,'owner','accepted') on conflict(group_id,user_id) do nothing;
 return new;
end $$;
revoke all on function private.add_group_creator_as_owner() from public,anon,authenticated;
drop trigger if exists groups_add_creator_owner on public.groups;
create trigger groups_add_creator_owner after insert on public.groups for each row execute function private.add_group_creator_as_owner();

create or replace function private.can_view_group_members(p_group_id uuid,p_user_id uuid)
returns boolean language sql stable security definer set search_path=''
as $$ select p_user_id=(select auth.uid()) and (
 exists(select 1 from public.groups g where g.id=p_group_id and g.created_by=p_user_id)
 or exists(select 1 from public.group_members gm where gm.group_id=p_group_id and gm.user_id=p_user_id and gm.status='accepted')
) $$;
revoke all on function private.can_view_group_members(uuid,uuid) from public,anon;
grant usage on schema private to authenticated;
grant execute on function private.can_view_group_members(uuid,uuid) to authenticated;

drop policy if exists "group members can view roster" on public.group_members;
create policy "group members can view roster" on public.group_members for select to authenticated
using (user_id=(select auth.uid()) or private.can_view_group_members(group_id,(select auth.uid())));
drop policy if exists "members can request group access" on public.group_members;
create policy "members can request group access" on public.group_members for insert to authenticated
with check (user_id=(select auth.uid()) and role='member' and status='pending');
drop policy if exists "group owners approve requests" on public.group_members;
create policy "group owners approve requests" on public.group_members for update to authenticated
using (exists(select 1 from public.groups g where g.id=group_members.group_id and g.created_by=(select auth.uid())) and role='member' and status='pending')
with check (role='member' and status='accepted' and exists(select 1 from public.groups g where g.id=group_members.group_id and g.created_by=(select auth.uid())));
drop policy if exists "members cancel or owners remove" on public.group_members;
create policy "members cancel or owners remove" on public.group_members for delete to authenticated
using (user_id=(select auth.uid()) or exists(select 1 from public.groups g where g.id=group_members.group_id and g.created_by=(select auth.uid())));

do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then
  begin alter publication supabase_realtime add table public.groups; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.group_members; exception when duplicate_object then null; end;
 end if;
end $$;
