-- Mood Feed : préférences temporaires liées au compte Supabase existant.
-- Aucun compte séparé : user_id référence auth.users(id).
create table if not exists public.mood_feeds (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  intention text not null check (char_length(intention) between 4 and 240),
  filters jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  active boolean not null default true,
  constraint mood_feeds_expiry_after_creation check (expires_at > created_at)
);

create index if not exists idx_mood_feeds_user_active_expiry
  on public.mood_feeds(user_id, active, expires_at desc);

alter table public.mood_feeds enable row level security;
revoke all on public.mood_feeds from anon;
grant select, insert, update, delete on public.mood_feeds to authenticated;

drop policy if exists "mood_feeds_select_own" on public.mood_feeds;
create policy "mood_feeds_select_own" on public.mood_feeds
  for select to authenticated using (auth.uid() = user_id);

drop policy if exists "mood_feeds_insert_own" on public.mood_feeds;
create policy "mood_feeds_insert_own" on public.mood_feeds
  for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "mood_feeds_update_own" on public.mood_feeds;
create policy "mood_feeds_update_own" on public.mood_feeds
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "mood_feeds_delete_own" on public.mood_feeds;
create policy "mood_feeds_delete_own" on public.mood_feeds
  for delete to authenticated using (auth.uid() = user_id);
