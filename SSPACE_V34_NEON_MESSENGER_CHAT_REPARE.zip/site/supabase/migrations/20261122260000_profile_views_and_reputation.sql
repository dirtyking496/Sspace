-- SSPACE : vues de profil + votes communautaires (un vote par membre/profil).
-- Les écritures sensibles passent par des RPC authentifiées.

alter table public.user_notifications drop constraint if exists user_notifications_notif_type_check;
alter table public.user_notifications
  add constraint user_notifications_notif_type_check
  check (notif_type in ('message','friend_request','friend_accept','mention','comment','like','friend_activity','gem_gift','gem_request','emerald_gift','emerald_request','profile_view'));

create table if not exists public.profile_visits (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  visitor_id uuid not null references public.profiles(id) on delete cascade,
  first_visited_at timestamptz not null default now(),
  last_visited_at timestamptz not null default now(),
  last_notified_at timestamptz,
  visit_count integer not null default 1 check (visit_count > 0),
  primary key (profile_id, visitor_id),
  check (profile_id <> visitor_id)
);
create index if not exists profile_visits_profile_idx on public.profile_visits(profile_id, last_visited_at desc);
alter table public.profile_visits enable row level security;
revoke all on public.profile_visits from anon, authenticated;

create table if not exists public.profile_reputation_votes (
  profile_id uuid not null references public.profiles(id) on delete cascade,
  voter_id uuid not null references public.profiles(id) on delete cascade,
  vote smallint not null check (vote in (-1, 1)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (profile_id, voter_id),
  check (profile_id <> voter_id)
);
create index if not exists profile_reputation_votes_profile_idx on public.profile_reputation_votes(profile_id, vote);
alter table public.profile_reputation_votes enable row level security;
revoke all on public.profile_reputation_votes from anon, authenticated;

create or replace function public.profile_public_stats(p_profile_id uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare
  views_count integer;
  up_count integer;
  down_count integer;
begin
  if (select auth.uid()) is null then raise exception 'Connexion requise'; end if;
  if not exists (select 1 from public.profiles where id = p_profile_id) then raise exception 'Profil introuvable'; end if;
  select count(*)::int into views_count from public.profile_visits where profile_id = p_profile_id;
  select count(*) filter (where vote = 1)::int, count(*) filter (where vote = -1)::int
    into up_count, down_count from public.profile_reputation_votes where profile_id = p_profile_id;
  return jsonb_build_object(
    'profile_id', p_profile_id,
    'visitors', coalesce(views_count,0),
    'thumbs_up', coalesce(up_count,0),
    'thumbs_down', coalesce(down_count,0),
    'total_votes', coalesce(up_count,0)+coalesce(down_count,0),
    'positive_percent', case when coalesce(up_count,0)+coalesce(down_count,0)=0 then 0 else round(100.0*up_count/(up_count+down_count))::int end,
    'my_vote', (select vote from public.profile_reputation_votes where profile_id=p_profile_id and voter_id=(select auth.uid()))
  );
end;
$$;

create or replace function public.profile_visit_record(p_profile_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  should_notify boolean := false;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  if p_profile_id is null or p_profile_id = me then
    return public.profile_public_stats(coalesce(p_profile_id, me));
  end if;
  if not exists (select 1 from public.profiles where id=p_profile_id) then raise exception 'Profil introuvable'; end if;
  insert into public.profile_visits(profile_id, visitor_id)
    values (p_profile_id, me)
  on conflict (profile_id, visitor_id) do update
    set last_visited_at=now(), visit_count=public.profile_visits.visit_count+1
  returning (last_notified_at is null or last_notified_at < now()-interval '24 hours') into should_notify;
  if should_notify then
    update public.profile_visits set last_notified_at=now() where profile_id=p_profile_id and visitor_id=me;
    insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
      values (p_profile_id, me, 'profile_view', me, 'a vu ton profil.');
  end if;
  return public.profile_public_stats(p_profile_id);
end;
$$;

create or replace function public.profile_vote_cast(p_profile_id uuid, p_vote smallint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
begin
  if me is null then raise exception 'Connexion requise'; end if;
  if p_profile_id is null or p_profile_id=me then raise exception 'Tu ne peux pas voter pour ton propre profil'; end if;
  if p_vote is null or p_vote not in (-1,1) then raise exception 'Vote invalide'; end if;
  if not exists (select 1 from public.profiles where id=p_profile_id) then raise exception 'Profil introuvable'; end if;
  insert into public.profile_reputation_votes(profile_id,voter_id,vote)
    values(p_profile_id,me,p_vote)
  on conflict(profile_id,voter_id) do update set vote=excluded.vote, updated_at=now();
  return public.profile_public_stats(p_profile_id);
end;
$$;

revoke all on function public.profile_public_stats(uuid) from public, anon;
revoke all on function public.profile_visit_record(uuid) from public, anon;
revoke all on function public.profile_vote_cast(uuid,smallint) from public, anon;
grant execute on function public.profile_public_stats(uuid) to authenticated;
grant execute on function public.profile_visit_record(uuid) to authenticated;
grant execute on function public.profile_vote_cast(uuid,smallint) to authenticated;

-- Le centre de notifications existant est déjà abonné à user_notifications via Realtime.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='user_notifications') then
    alter publication supabase_realtime add table public.user_notifications;
  end if;
end $$;
