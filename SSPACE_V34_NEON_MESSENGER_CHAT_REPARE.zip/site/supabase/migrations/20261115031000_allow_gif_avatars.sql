-- Autorise les GIF animés comme photo de profil (bucket public post-images).
-- N'agit que si le bucket restreint les types MIME ; sinon rien à faire.
update storage.buckets
set allowed_mime_types = (
  select array_agg(distinct t) from unnest(allowed_mime_types || array['image/gif']) as t
)
where id = 'post-images'
  and allowed_mime_types is not null
  and not ('image/gif' = any (allowed_mime_types));
