-- Cover image URL used by the SSPACE built-in gallery and personal album picker.
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cover_url text;
