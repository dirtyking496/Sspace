-- OPTIONNEL — à exécuter dans le SQL Editor de Supabase seulement si le diagnostic ci-dessous
-- montre plusieurs clés étrangères posts -> profiles. Le frontend fonctionne déjà sans cette migration
-- (jointure explicite profiles!user_id + repli automatique).

-- Diagnostic (lecture seule) : liste les FK de public.posts vers public.profiles
-- select conname, pg_get_constraintdef(oid) from pg_constraint
-- where conrelid = 'public.posts'::regclass and confrelid = 'public.profiles'::regclass and contype = 'f';

-- Nettoyage : ne garde qu'une seule FK posts.user_id -> profiles(id) (la plus ancienne), supprime les doublons.
do $$
declare
  keep_oid oid;
  r record;
begin
  select c.oid into keep_oid
  from pg_constraint c
  where c.conrelid = 'public.posts'::regclass
    and c.confrelid = 'public.profiles'::regclass
    and c.contype = 'f'
  order by c.oid
  limit 1;

  if keep_oid is null then
    return; -- aucune FK vers profiles : rien à nettoyer
  end if;

  for r in
    select c.conname
    from pg_constraint c
    where c.conrelid = 'public.posts'::regclass
      and c.confrelid = 'public.profiles'::regclass
      and c.contype = 'f'
      and c.oid <> keep_oid
  loop
    execute format('alter table public.posts drop constraint %I', r.conname);
  end loop;
end $$;

-- Recharge le cache de schéma PostgREST
notify pgrst, 'reload schema';
