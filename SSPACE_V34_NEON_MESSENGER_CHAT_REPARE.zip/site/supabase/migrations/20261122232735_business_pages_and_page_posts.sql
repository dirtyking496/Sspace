-- SSPACE pages: entreprises, marques et créateurs. Publications isolées du fil général.
create table if not exists public.business_pages (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 90),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  category text not null default 'Entreprise locale',
  tagline text not null default '',
  description text not null default '',
  logo_url text,
  cover_url text,
  website_url text,
  contact text,
  theme text not null default 'blue' check (theme in ('blue','violet','green','dark','orange')),
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists business_pages_owner_updated_idx on public.business_pages(owner_id, updated_at desc);
create table if not exists public.business_page_posts (
  id uuid primary key default gen_random_uuid(),
  page_id uuid not null references public.business_pages(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  content text not null default '', image_url text,
  created_at timestamptz not null default now(),
  constraint business_page_posts_content_or_image check (char_length(trim(content)) > 0 or image_url is not null)
);
create index if not exists business_page_posts_page_created_idx on public.business_page_posts(page_id, created_at desc);
alter table public.business_pages enable row level security;
alter table public.business_page_posts enable row level security;
grant select on public.business_pages to anon, authenticated;
grant insert, update, delete on public.business_pages to authenticated;
grant select on public.business_page_posts to anon, authenticated;
grant insert, update, delete on public.business_page_posts to authenticated;
drop policy if exists "Published business pages are readable" on public.business_pages;
create policy "Published business pages are readable" on public.business_pages for select to anon, authenticated using (is_published or (select auth.uid()) = owner_id);
drop policy if exists "Members create their own business pages" on public.business_pages;
create policy "Members create their own business pages" on public.business_pages for insert to authenticated with check ((select auth.uid()) = owner_id);
drop policy if exists "Members update their own business pages" on public.business_pages;
create policy "Members update their own business pages" on public.business_pages for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
drop policy if exists "Members delete their own business pages" on public.business_pages;
create policy "Members delete their own business pages" on public.business_pages for delete to authenticated using ((select auth.uid()) = owner_id);
drop policy if exists "Published page posts are readable" on public.business_page_posts;
create policy "Published page posts are readable" on public.business_page_posts for select to anon, authenticated using (exists (select 1 from public.business_pages p where p.id = page_id and (p.is_published or p.owner_id = (select auth.uid()))));
drop policy if exists "Page owners publish to their own page" on public.business_page_posts;
create policy "Page owners publish to their own page" on public.business_page_posts for insert to authenticated with check (author_id = (select auth.uid()) and exists (select 1 from public.business_pages p where p.id = page_id and p.owner_id = (select auth.uid())));
drop policy if exists "Page owners edit their own page posts" on public.business_page_posts;
create policy "Page owners edit their own page posts" on public.business_page_posts for update to authenticated using (exists (select 1 from public.business_pages p where p.id = page_id and p.owner_id = (select auth.uid()))) with check (author_id = (select auth.uid()) and exists (select 1 from public.business_pages p where p.id = page_id and p.owner_id = (select auth.uid())));
drop policy if exists "Page owners delete their own page posts" on public.business_page_posts;
create policy "Page owners delete their own page posts" on public.business_page_posts for delete to authenticated using (exists (select 1 from public.business_pages p where p.id = page_id and p.owner_id = (select auth.uid())));
