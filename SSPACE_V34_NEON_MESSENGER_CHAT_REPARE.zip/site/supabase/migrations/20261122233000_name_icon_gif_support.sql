-- V17.2 : autoriser les URL GIF GIPHY/ Tenor comme emblèmes animés du nom.
alter table public.profiles add column if not exists name_icon text;
alter table public.profiles drop constraint if exists profiles_name_icon_check;
alter table public.profiles add constraint profiles_name_icon_check
  check (name_icon is null or char_length(name_icon) between 1 and 600);
grant update (name_icon) on public.profiles to authenticated;
