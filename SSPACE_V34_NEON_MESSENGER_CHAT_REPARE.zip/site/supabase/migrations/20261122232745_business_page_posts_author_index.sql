-- Index covering the page post author foreign key.
create index if not exists business_page_posts_author_idx on public.business_page_posts(author_id);
