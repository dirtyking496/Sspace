-- SSPACE Profile API : stockage de métadonnées des médias sans créer de nouveaux comptes.
-- Les propriétaires sont les UUID existants de public.profiles / auth.users.
create table if not exists public.profile_media (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  media_type text not null check (media_type in ('photo', 'video')),
  storage_key text not null unique,
  mime_type text not null check (mime_type in ('image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm')),
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 52428800),
  created_at timestamptz not null default now()
);
create index if not exists profile_media_owner_created_idx
  on public.profile_media(owner_id, created_at desc);

alter table public.profile_media enable row level security;
revoke all on table public.profile_media from anon, authenticated;
comment on table public.profile_media is
  'Métadonnées médias gérées par le backend Express authentifié via la session Supabase; aucun compte utilisateur parallèle.';
