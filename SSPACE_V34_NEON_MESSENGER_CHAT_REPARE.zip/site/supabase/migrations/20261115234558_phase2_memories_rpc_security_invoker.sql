-- Run the memories RPC with caller privileges so posts/profile RLS remains effective.
CREATE OR REPLACE FUNCTION public.get_sspace_memories()
RETURNS SETOF public.posts LANGUAGE sql STABLE SECURITY INVOKER SET search_path = '' AS $$
  SELECT p.* FROM public.posts p JOIN public.profiles pr ON pr.id = p.user_id
  WHERE p.user_id = (SELECT auth.uid()) AND pr.memories_enabled = true
    AND EXTRACT(MONTH FROM p.created_at) = EXTRACT(MONTH FROM now())
    AND EXTRACT(DAY FROM p.created_at) = EXTRACT(DAY FROM now())
    AND EXTRACT(YEAR FROM p.created_at) < EXTRACT(YEAR FROM now())
  ORDER BY p.created_at DESC;
$$;
REVOKE ALL ON FUNCTION public.get_sspace_memories() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_sspace_memories() TO authenticated;
