ALTER TABLE public.profiles
  DROP CONSTRAINT IF EXISTS profiles_profile_theme_check;
ALTER TABLE public.profiles
  ADD CONSTRAINT profiles_profile_theme_check
  CHECK (profile_theme = ANY (ARRAY[
    'theme-aurora','theme-ocean','theme-violet','theme-forest','theme-sunset',
    'theme-ice','theme-rose','theme-neon','theme-midnight','theme-gold',
    'premium-flame','premium-cosmic','premium-rain','premium-prism','premium-royal',
    'theme-aurora-glow','theme-oasis','theme-lavender','theme-emerald','theme-starlight'
  ]));

-- A block ends the friendship relationship too; a new request can be sent only
-- after the blocker is allowed to remove the block (12-hour RLS cooldown).
CREATE OR REPLACE FUNCTION private.cleanup_friendship_on_block()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  DELETE FROM public.friend_requests fr
  WHERE (fr.sender_id = NEW.blocker_id AND fr.receiver_id = NEW.blocked_id)
     OR (fr.sender_id = NEW.blocked_id AND fr.receiver_id = NEW.blocker_id);
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION private.cleanup_friendship_on_block() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS cleanup_friendship_on_block ON public.user_blocks;
CREATE TRIGGER cleanup_friendship_on_block
AFTER INSERT ON public.user_blocks
FOR EACH ROW EXECUTE FUNCTION private.cleanup_friendship_on_block();

-- All catalogue entries are now available without a paid entitlement.
UPDATE public.store_catalog SET is_premium = false;
INSERT INTO public.store_catalog (id, category, title, description, is_premium, preview_css)
VALUES
 ('aurora-glow','chat_theme','Aurore scintillante','Une aurore cyan et violette animée.',false,'linear-gradient(145deg,#0c1d3b,#31204f)'),
 ('crystal-cave','chat_theme','Grotte de cristal','Reflets de cristal bleu et violet.',false,'linear-gradient(135deg,#173c63,#5c4b91,#1a2746)'),
 ('ocean-depths','chat_theme','Profondeurs océanes','Ambiance sous-marine profonde.',false,'linear-gradient(145deg,#062b43,#0e1b37)'),
 ('lavender-dream','chat_theme','Rêve lavande','Nuances lavande et mauve.',false,'linear-gradient(145deg,#39214d,#1c2347)'),
 ('solar-flare','chat_theme','Éruption solaire','Lueurs chaudes et dorées.',false,'linear-gradient(145deg,#562b28,#1b1835)'),
 ('emerald-wave','chat_theme','Vague émeraude','Vagues vertes et turquoise.',false,'linear-gradient(145deg,#0b3c39,#122b3b)')
ON CONFLICT (id) DO UPDATE SET is_premium=false, active=true;
