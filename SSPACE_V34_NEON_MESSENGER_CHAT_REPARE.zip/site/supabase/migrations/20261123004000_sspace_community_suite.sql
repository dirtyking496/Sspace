-- SSPACE V27.3 : Blog, musique, Clans, chat temps réel, réactions enrichies,
-- défis/streaks et boîte à souvenirs. Identité unique : auth.users UUID (Supabase).
create extension if not exists pgcrypto;

create table if not exists public.sspace_clans (
 id uuid primary key default gen_random_uuid(), name varchar(60) not null unique,
 description text not null default '', theme varchar(30) not null default 'general',
 owner_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.sspace_clan_members (
 clan_id uuid not null references public.sspace_clans(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'membre' check(role in ('owner','modo','membre')),
 joined_at timestamptz not null default now(), primary key(clan_id,user_id)
);
create table if not exists public.sspace_clan_messages (
 id uuid primary key default gen_random_uuid(), clan_id uuid not null references public.sspace_clans(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 content varchar(1000) not null check(char_length(trim(content)) between 1 and 1000),
 created_at timestamptz not null default now()
);
create index if not exists sspace_clan_messages_recent on public.sspace_clan_messages(clan_id,created_at desc);
create or replace function public.sspace_add_clan_owner() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.sspace_clan_members(clan_id,user_id,role) values(new.id,new.owner_id,'owner') on conflict do nothing; return new; end $$;
drop trigger if exists sspace_clan_owner_member on public.sspace_clans;
create trigger sspace_clan_owner_member after insert on public.sspace_clans for each row execute function public.sspace_add_clan_owner();

create table if not exists public.sspace_blog_articles (
 id uuid primary key default gen_random_uuid(), author_id uuid not null references auth.users(id) on delete cascade,
 title varchar(180) not null check(char_length(trim(title)) between 3 and 180),
 body text not null check(char_length(trim(body)) between 1 and 30000),
 category varchar(40) not null default 'general', published boolean not null default true,
 views_count bigint not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index if not exists sspace_blog_public_rank on public.sspace_blog_articles(published,views_count desc,created_at desc);
create index if not exists sspace_blog_author on public.sspace_blog_articles(author_id,created_at desc);
create table if not exists public.sspace_blog_comments (
 id uuid primary key default gen_random_uuid(), article_id uuid not null references public.sspace_blog_articles(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 content text not null default '' check(char_length(content)<=4000),
 reaction_type text not null default 'text' check(reaction_type in ('text','audio','photo','poll')),
 media_path text, poll_question varchar(240), poll_options jsonb,
 created_at timestamptz not null default now(),
 check((reaction_type='text' and char_length(trim(content))>0) or reaction_type<>'text')
);
create index if not exists sspace_blog_comments_article on public.sspace_blog_comments(article_id,created_at);
create table if not exists public.sspace_blog_comment_votes (
 comment_id uuid not null references public.sspace_blog_comments(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade, option_index int not null check(option_index between 0 and 9),
 created_at timestamptz not null default now(), primary key(comment_id,user_id)
);
create or replace view public.sspace_blog_top100 with (security_invoker=true) as
 select a.id,a.author_id,a.title,a.category,a.views_count,a.created_at,
 (select count(*) from public.sspace_blog_comments c where c.article_id=a.id) as comments_count
 from public.sspace_blog_articles a where a.published=true order by a.views_count desc,comments_count desc,a.created_at desc limit 100;
create or replace function public.sspace_blog_increment_view(p_article_id uuid) returns void language sql security definer set search_path=public as $$
 update public.sspace_blog_articles set views_count=views_count+1 where id=p_article_id and published=true;
$$;
revoke all on function public.sspace_blog_increment_view(uuid) from public;

create table if not exists public.sspace_music_tracks (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 title varchar(160) not null check(char_length(trim(title)) between 1 and 160), artist varchar(120) not null default '',
 storage_path text not null, allow_download boolean not null default false,
 created_at timestamptz not null default now()
);
create index if not exists sspace_music_recent on public.sspace_music_tracks(created_at desc);

create table if not exists public.sspace_challenges (
 id uuid primary key default gen_random_uuid(), code varchar(50) unique not null, title varchar(140) not null,
 description text not null, target_count int not null default 1 check(target_count between 1 and 100),
 period text not null default 'weekly' check(period in ('daily','weekly','monthly')), active boolean not null default true
);
create table if not exists public.sspace_challenge_progress (
 challenge_id uuid not null references public.sspace_challenges(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 period_start date not null, progress_count int not null default 0 check(progress_count>=0),
 completed_at timestamptz, updated_at timestamptz not null default now(),
 primary key(challenge_id,user_id,period_start)
);
create table if not exists public.sspace_daily_activity (
 user_id uuid not null references auth.users(id) on delete cascade, activity_date date not null default current_date,
 activity_count int not null default 1 check(activity_count>0), primary key(user_id,activity_date)
);
create table if not exists public.sspace_memory_items (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 item_type text not null check(item_type in ('blog','music','photo','moment')),
 title varchar(180) not null, description text not null default '', source_id uuid,
 happened_at timestamptz not null default now(), created_at timestamptz not null default now()
);
create index if not exists sspace_memory_user_date on public.sspace_memory_items(user_id,happened_at desc);

-- Défis de départ, idempotents.
insert into public.sspace_challenges(code,title,description,target_count,period) values
 ('publish_blog_week','Publier un article cette semaine','Écris et publie un article de blogue.',1,'weekly'),
 ('listen_music_week','Découvrir trois morceaux','Écoute trois morceaux du Blog Musical.',3,'weekly'),
 ('comment_week','Participer à la communauté','Laisse trois commentaires constructifs.',3,'weekly')
on conflict(code) do nothing;

-- Storage privé partagé pour MP3, notes vocales et photos de réactions.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('sspace-community-media','sspace-community-media',false,52428800,
 array['audio/mpeg','audio/mp3','audio/mp4','audio/webm','audio/ogg','audio/wav','image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=52428800,allowed_mime_types=excluded.allowed_mime_types;

-- RLS
alter table public.sspace_clans enable row level security;
alter table public.sspace_clan_members enable row level security;
alter table public.sspace_clan_messages enable row level security;
alter table public.sspace_blog_articles enable row level security;
alter table public.sspace_blog_comments enable row level security;
alter table public.sspace_blog_comment_votes enable row level security;
alter table public.sspace_music_tracks enable row level security;
alter table public.sspace_challenges enable row level security;
alter table public.sspace_challenge_progress enable row level security;
alter table public.sspace_daily_activity enable row level security;
alter table public.sspace_memory_items enable row level security;

grant select,insert,update,delete on public.sspace_clans,public.sspace_clan_members,public.sspace_clan_messages,
 public.sspace_blog_articles,public.sspace_blog_comments,public.sspace_blog_comment_votes,public.sspace_music_tracks,
 public.sspace_challenge_progress,public.sspace_daily_activity,public.sspace_memory_items to authenticated;
grant select on public.sspace_challenges,public.sspace_blog_top100 to authenticated;
grant execute on function public.sspace_blog_increment_view(uuid) to authenticated;

drop policy if exists clan_read on public.sspace_clans;
create policy clan_read on public.sspace_clans for select to authenticated using(true);
drop policy if exists clan_create on public.sspace_clans;
create policy clan_create on public.sspace_clans for insert to authenticated with check(owner_id=auth.uid());
drop policy if exists clan_owner_update on public.sspace_clans;
create policy clan_owner_update on public.sspace_clans for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
drop policy if exists clan_owner_delete on public.sspace_clans;
create policy clan_owner_delete on public.sspace_clans for delete to authenticated using(owner_id=auth.uid());
create or replace function public.sspace_is_clan_member(p_clan_id uuid,p_user_id uuid) returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.sspace_clan_members where clan_id=p_clan_id and user_id=p_user_id);
$$;
revoke all on function public.sspace_is_clan_member(uuid,uuid) from public;
grant execute on function public.sspace_is_clan_member(uuid,uuid) to authenticated;
drop policy if exists clan_member_read on public.sspace_clan_members;
create policy clan_member_read on public.sspace_clan_members for select to authenticated using(public.sspace_is_clan_member(clan_id,auth.uid()));
drop policy if exists clan_member_join on public.sspace_clan_members;
create policy clan_member_join on public.sspace_clan_members for insert to authenticated with check(user_id=auth.uid() and role='membre' and exists(select 1 from public.sspace_clans c where c.id=clan_id));
drop policy if exists clan_member_leave on public.sspace_clan_members;
create policy clan_member_leave on public.sspace_clan_members for delete to authenticated using(user_id=auth.uid() and role<>'owner');
drop policy if exists clan_message_read on public.sspace_clan_messages;
create policy clan_message_read on public.sspace_clan_messages for select to authenticated using(public.sspace_is_clan_member(clan_id,auth.uid()));
drop policy if exists clan_message_send on public.sspace_clan_messages;
create policy clan_message_send on public.sspace_clan_messages for insert to authenticated with check(user_id=auth.uid() and public.sspace_is_clan_member(clan_id,auth.uid()));

drop policy if exists blog_read_published on public.sspace_blog_articles;
create policy blog_read_published on public.sspace_blog_articles for select to authenticated using(published or author_id=auth.uid());
drop policy if exists blog_insert_own on public.sspace_blog_articles;
create policy blog_insert_own on public.sspace_blog_articles for insert to authenticated with check(author_id=auth.uid());
drop policy if exists blog_update_own on public.sspace_blog_articles;
create policy blog_update_own on public.sspace_blog_articles for update to authenticated using(author_id=auth.uid()) with check(author_id=auth.uid());
drop policy if exists blog_delete_own on public.sspace_blog_articles;
create policy blog_delete_own on public.sspace_blog_articles for delete to authenticated using(author_id=auth.uid());
drop policy if exists blog_comments_read on public.sspace_blog_comments;
create policy blog_comments_read on public.sspace_blog_comments for select to authenticated using(exists(select 1 from public.sspace_blog_articles a where a.id=article_id and (a.published or a.author_id=auth.uid())));
drop policy if exists blog_comments_insert on public.sspace_blog_comments;
create policy blog_comments_insert on public.sspace_blog_comments for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.sspace_blog_articles a where a.id=article_id and a.published));
drop policy if exists blog_comments_delete on public.sspace_blog_comments;
create policy blog_comments_delete on public.sspace_blog_comments for delete to authenticated using(user_id=auth.uid() or exists(select 1 from public.sspace_blog_articles a where a.id=article_id and a.author_id=auth.uid()));
drop policy if exists blog_votes_all on public.sspace_blog_comment_votes;
create policy blog_votes_all on public.sspace_blog_comment_votes for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists blog_votes_read on public.sspace_blog_comment_votes;
create policy blog_votes_read on public.sspace_blog_comment_votes for select to authenticated using(exists(select 1 from public.sspace_blog_comments c join public.sspace_blog_articles a on a.id=c.article_id where c.id=comment_id and a.published=true));

drop policy if exists music_read on public.sspace_music_tracks;
create policy music_read on public.sspace_music_tracks for select to authenticated using(true);
drop policy if exists music_insert on public.sspace_music_tracks;
create policy music_insert on public.sspace_music_tracks for insert to authenticated with check(user_id=auth.uid());
drop policy if exists music_delete on public.sspace_music_tracks;
create policy music_delete on public.sspace_music_tracks for delete to authenticated using(user_id=auth.uid());
drop policy if exists challenges_read on public.sspace_challenges;
create policy challenges_read on public.sspace_challenges for select to authenticated using(active=true);
drop policy if exists progress_own on public.sspace_challenge_progress;
create policy progress_own on public.sspace_challenge_progress for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists activity_own on public.sspace_daily_activity;
create policy activity_own on public.sspace_daily_activity for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists memories_own on public.sspace_memory_items;
create policy memories_own on public.sspace_memory_items for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

drop policy if exists sspace_media_read_auth on storage.objects;
create policy sspace_media_read_auth on storage.objects for select to authenticated using(bucket_id='sspace-community-media');
drop policy if exists sspace_media_insert_own on storage.objects;
create policy sspace_media_insert_own on storage.objects for insert to authenticated with check(bucket_id='sspace-community-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists sspace_media_delete_own on storage.objects;
create policy sspace_media_delete_own on storage.objects for delete to authenticated using(bucket_id='sspace-community-media' and (storage.foldername(name))[1]=auth.uid()::text);

-- Active le flux temps réel pour le chat des clans (idempotent).
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_clan_messages') then
  alter publication supabase_realtime add table public.sspace_clan_messages;
 end if;
exception when undefined_object then null; end $$;
