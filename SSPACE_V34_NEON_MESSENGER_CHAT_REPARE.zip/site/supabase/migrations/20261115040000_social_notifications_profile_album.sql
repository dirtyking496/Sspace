-- SSPACE: centre unifie des notifications sociales + album photo de profil.
-- Idempotent: peut etre rejoue sans recreer les tables/trigger/policies.

create table if not exists public.user_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  notif_type text not null check (notif_type in ('message','friend_request','friend_accept','mention','comment','like','friend_activity')),
  entity_id uuid,
  preview_text text not null default '',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists user_notifications_user_idx
  on public.user_notifications(user_id, is_read, created_at desc);
alter table public.user_notifications enable row level security;
grant select, update, delete on public.user_notifications to authenticated;
drop policy if exists "Users read own notifications" on public.user_notifications;
create policy "Users read own notifications" on public.user_notifications
  for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "Users mark own notifications read" on public.user_notifications;
create policy "Users mark own notifications read" on public.user_notifications
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
drop policy if exists "Users delete own notifications" on public.user_notifications;
create policy "Users delete own notifications" on public.user_notifications
  for delete to authenticated using ((select auth.uid()) = user_id);

create or replace function private.trg_notify_social_event()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_target_user uuid;
  v_actor uuid;
  v_entity uuid;
  v_type text;
  v_preview text;
begin
  if tg_table_name = 'likes' then
    select p.user_id into v_target_user from public.posts p where p.id = new.post_id;
    v_actor := new.user_id; v_entity := new.post_id; v_type := 'like'; v_preview := 'a aimé ta publication.';
  elsif tg_table_name = 'comments' then
    select p.user_id into v_target_user from public.posts p where p.id = new.post_id;
    v_actor := new.user_id; v_entity := new.post_id; v_type := 'comment'; v_preview := left(new.content, 80);
  elsif tg_table_name = 'friend_requests' then
    if tg_op = 'INSERT' and new.status = 'pending' then
      v_target_user := new.receiver_id; v_actor := new.sender_id; v_entity := new.id;
      v_type := 'friend_request'; v_preview := 't’a envoyé une demande d’ami.';
    elsif tg_op = 'UPDATE' and old.status = 'pending' and new.status = 'accepted' then
      v_target_user := new.sender_id; v_actor := new.receiver_id; v_entity := new.id;
      v_type := 'friend_accept'; v_preview := 'a accepté ta demande d’ami.';
    end if;
  elsif tg_table_name = 'post_mentions' then
    v_target_user := new.mentioned_user_id; v_actor := new.tagged_by;
    v_entity := new.post_id; v_type := 'mention'; v_preview := 't’a identifié dans une publication.';
  elsif tg_table_name = 'follows' then
    v_target_user := new.following_id; v_actor := new.follower_id;
    v_entity := new.follower_id; v_type := 'friend_activity'; v_preview := 'a commencé à te suivre.';
  end if;
  if v_target_user is not null and v_actor is not null and v_target_user <> v_actor then
    insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
    values (v_target_user, v_actor, v_type, v_entity, coalesce(v_preview, 'Nouvelle activité sur ton profil.'));
  end if;
  return new;
end;
$$;
revoke all on function private.trg_notify_social_event() from public, anon, authenticated;

drop trigger if exists notify_on_like on public.likes;
create trigger notify_on_like after insert on public.likes for each row execute function private.trg_notify_social_event();
drop trigger if exists notify_on_comment on public.comments;
create trigger notify_on_comment after insert on public.comments for each row execute function private.trg_notify_social_event();
drop trigger if exists notify_on_friend_request on public.friend_requests;
create trigger notify_on_friend_request after insert or update on public.friend_requests for each row execute function private.trg_notify_social_event();
drop trigger if exists notify_on_mention on public.post_mentions;
create trigger notify_on_mention after insert on public.post_mentions for each row execute function private.trg_notify_social_event();
drop trigger if exists notify_on_follow on public.follows;
create trigger notify_on_follow after insert on public.follows for each row execute function private.trg_notify_social_event();

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='user_notifications') then
    alter publication supabase_realtime add table public.user_notifications;
  end if;
end $$;

create table if not exists public.profile_album_photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null unique,
  caption text not null default '' check (char_length(caption) <= 300),
  created_at timestamptz not null default now()
);
create index if not exists profile_album_photos_user_idx on public.profile_album_photos(user_id, created_at desc);
alter table public.profile_album_photos enable row level security;
grant select, insert, delete on public.profile_album_photos to authenticated;
drop policy if exists "Album photos visible to signed in members" on public.profile_album_photos;
create policy "Album photos visible to signed in members" on public.profile_album_photos for select to authenticated using (true);
drop policy if exists "Members add photos to own album" on public.profile_album_photos;
create policy "Members add photos to own album" on public.profile_album_photos for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "Members delete own album photos" on public.profile_album_photos;
create policy "Members delete own album photos" on public.profile_album_photos for delete to authenticated using ((select auth.uid()) = user_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profile-albums','profile-albums',true,12582912,array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public=excluded.public, file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "Album photos are publicly readable" on storage.objects;
create policy "Album photos are publicly readable" on storage.objects for select to authenticated using (bucket_id='profile-albums');
drop policy if exists "Members upload to own profile album" on storage.objects;
create policy "Members upload to own profile album" on storage.objects for insert to authenticated
  with check (bucket_id='profile-albums' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists "Members delete from own profile album" on storage.objects;
create policy "Members delete from own profile album" on storage.objects for delete to authenticated
  using (bucket_id='profile-albums' and (storage.foldername(name))[1]=(select auth.uid())::text);
