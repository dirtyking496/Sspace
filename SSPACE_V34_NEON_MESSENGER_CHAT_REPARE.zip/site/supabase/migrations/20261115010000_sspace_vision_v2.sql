-- ============================================================================
-- SSPACE VISION V2 — MIGRATION COMPLÈTE & POLITIQUES RLS SÉCURISÉES
-- ============================================================================

-- 1. PROFILS VIVANTS, SOUVENIRS & PRÉFÉRENCES (Sections D, E, F, G)
alter table public.profiles
  add column if not exists status_text text default '',
  add column if not exists mood text default 'neutral',
  add column if not exists favorite_music text default '',
  add column if not exists profile_badges jsonb not null default '[]'::jsonb,
  add column if not exists profile_decor text not null default 'none',
  add column if not exists memories_enabled boolean not null default true,
  add column if not exists is_private boolean not null default false,
  add column if not exists is_admin boolean not null default false,
  add column if not exists notification_prefs jsonb not null default '{"messages":true,"friend_requests":true,"mentions":true,"comments":true,"likes":true,"friend_activity":true}'::jsonb;

alter table public.profiles drop constraint if exists profiles_status_text_check;
alter table public.profiles add constraint profiles_status_text_check check (length(status_text) <= 120);

alter table public.profiles drop constraint if exists profiles_favorite_music_check;
alter table public.profiles add constraint profiles_favorite_music_check check (length(favorite_music) <= 140);

-- 2. BROUILLONS & ÉDITION DES PUBLICATIONS (Section I)
create table if not exists public.post_drafts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text default '',
  content text not null default '',
  media_url text,
  media_type text,
  poll_question text,
  poll_options jsonb default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists post_drafts_user_idx on public.post_drafts(user_id, updated_at desc);
alter table public.post_drafts enable row level security;
grant select, insert, update, delete on public.post_drafts to authenticated;

drop policy if exists "Users manage own drafts" on public.post_drafts;
create policy "Users manage own drafts" on public.post_drafts
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

alter table public.posts add column if not exists edited_at timestamptz;
grant update (title, content, edited_at), delete on public.posts to authenticated;

drop policy if exists "Users update own posts" on public.posts;
create policy "Users update own posts" on public.posts
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users delete own posts" on public.posts;
create policy "Users delete own posts" on public.posts
  for delete to authenticated
  using ((select auth.uid()) = user_id);

-- 3. SÉCURITÉ, BLOCAGE, MASQUAGE & SIGNALEMENTS (Section G)
create table if not exists public.user_blocks (
  id uuid primary key default gen_random_uuid(),
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint user_blocks_not_self check (blocker_id <> blocked_id),
  constraint user_blocks_unique unique (blocker_id, blocked_id)
);

create index if not exists user_blocks_blocker_idx on public.user_blocks(blocker_id);
create index if not exists user_blocks_blocked_idx on public.user_blocks(blocked_id);
alter table public.user_blocks enable row level security;
grant select, insert, delete on public.user_blocks to authenticated;

drop policy if exists "Users manage own blocks" on public.user_blocks;
create policy "Users manage own blocks" on public.user_blocks
  for all to authenticated
  using ((select auth.uid()) = blocker_id)
  with check ((select auth.uid()) = blocker_id);

create table if not exists public.hidden_posts (
  user_id uuid not null references auth.users(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

alter table public.hidden_posts enable row level security;
grant select, insert, delete on public.hidden_posts to authenticated;

drop policy if exists "Users manage own hidden posts" on public.hidden_posts;
create policy "Users manage own hidden posts" on public.hidden_posts
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create table if not exists public.content_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('post', 'user', 'comment', 'message')),
  target_id uuid not null,
  reason text not null check (length(reason) between 3 and 500),
  status text not null default 'pending' check (status in ('pending', 'reviewed', 'dismissed', 'action_taken')),
  created_at timestamptz not null default now()
);

alter table public.content_reports enable row level security;
grant select, insert, update on public.content_reports to authenticated;

drop policy if exists "Users create reports" on public.content_reports;
create policy "Users create reports" on public.content_reports
  for insert to authenticated
  with check ((select auth.uid()) = reporter_id);

drop policy if exists "Users read own reports or admins read all" on public.content_reports;
create policy "Users read own reports or admins read all" on public.content_reports
  for select to authenticated
  using (
    (select auth.uid()) = reporter_id
    or exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_admin = true)
  );

drop policy if exists "Admins update reports" on public.content_reports;
create policy "Admins update reports" on public.content_reports
  for update to authenticated
  using (exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.is_admin = true));

create or replace function private.enforce_post_rate_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if exists (
    select 1 from public.posts
    where user_id = new.user_id
      and created_at > now() - interval '10 seconds'
  ) then
    raise exception 'Anti-spam : attends quelques secondes avant de publier à nouveau.';
  end if;
  return new;
end;
$$;

drop trigger if exists check_post_rate_limit on public.posts;
create trigger check_post_rate_limit
  before insert on public.posts
  for each row execute function private.enforce_post_rate_limit();

-- 4. CENTRE DE NOTIFICATIONS UNIFIÉ (Section F)
create table if not exists public.user_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  notif_type text not null check (notif_type in ('message', 'friend_request', 'friend_accept', 'mention', 'comment', 'like', 'friend_activity')),
  entity_id uuid,
  preview_text text default '',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists user_notifications_user_idx on public.user_notifications(user_id, is_read, created_at desc);
alter table public.user_notifications enable row level security;
grant select, update, delete on public.user_notifications to authenticated;

drop policy if exists "Users read own notifications" on public.user_notifications;
create policy "Users read own notifications" on public.user_notifications
  for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users mark own notifications read" on public.user_notifications;
create policy "Users mark own notifications read" on public.user_notifications
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create or replace function private.trg_notify_social_event()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_target_user uuid;
begin
  if tg_table_name = 'likes' then
    select user_id into v_target_user from public.posts where id = new.post_id;
    if v_target_user is not null and v_target_user <> new.user_id then
      insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
      values (v_target_user, new.user_id, 'like', new.post_id, 'a aimé ta publication.');
    end if;
  elsif tg_table_name = 'comments' then
    select user_id into v_target_user from public.posts where id = new.post_id;
    if v_target_user is not null and v_target_user <> new.user_id then
      insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
      values (v_target_user, new.user_id, 'comment', new.post_id, left(new.content, 80));
    end if;
  elsif tg_table_name = 'friend_requests' then
    if tg_op = 'INSERT' and new.status = 'pending' then
      insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
      values (new.receiver_id, new.sender_id, 'friend_request', new.id, 't’a envoyé une demande d’ami.');
    elsif tg_op = 'UPDATE' and old.status = 'pending' and new.status = 'accepted' then
      insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
      values (new.sender_id, new.receiver_id, 'friend_accept', new.id, 'a accepté ta demande d’ami.');
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists notify_on_like on public.likes;
create trigger notify_on_like after insert on public.likes for each row execute function private.trg_notify_social_event();

drop trigger if exists notify_on_comment on public.comments;
create trigger notify_on_comment after insert on public.comments for each row execute function private.trg_notify_social_event();

drop trigger if exists notify_on_friend_request on public.friend_requests;
create trigger notify_on_friend_request after insert or update on public.friend_requests for each row execute function private.trg_notify_social_event();

-- 5. CATALOGUE BOUTIQUE & PREMIUM SANS PAIEMENT SIMULÉ (Section K)
create table if not exists public.store_catalog (
  id text primary key,
  category text not null check (category in ('chat_theme', 'profile_decor', 'badge', 'bundle')),
  title text not null,
  description text not null,
  is_premium boolean not null default true,
  preview_css text not null default '',
  active boolean not null default true
);

alter table public.store_catalog enable row level security;
grant select on public.store_catalog to authenticated;

drop policy if exists "Everyone reads active store catalog" on public.store_catalog;
create policy "Everyone reads active store catalog" on public.store_catalog
  for select to authenticated
  using (active = true);

insert into public.store_catalog (id, category, title, description, is_premium, preview_css)
values
  ('cyber-pulse', 'chat_theme', 'Cyber Pulse (Animé)', 'Ondes bleu électrique et violet néon réactives.', true, 'linear-gradient(135deg,#090d24,#1d1145,#0a2540)'),
  ('nebula-drift', 'chat_theme', 'Nébuleuse SSPACE (Animé)', 'Particules cosmiques lentes en arrière-plan.', true, 'radial-gradient(circle at 20% 20%,#3b1d7a,#080a15)'),
  ('matrix-grid', 'chat_theme', 'Grille Quantique (Animé)', 'Lignes de code lumineuses subtiles.', true, 'linear-gradient(180deg,#060b19,#101c3d)'),
  ('aurora-storm', 'chat_theme', 'Orage Boréal (Animé)', 'Vagues lumineuses cyan et magenta.', true, 'linear-gradient(120deg,#0c1e3e,#2c1250)'),
  ('void-starlight', 'chat_theme', 'Éclat Stellaire (Animé)', 'Scintillement profond noir et argent.', true, 'radial-gradient(circle,#181c36,#05060c)')
on conflict (id) do nothing;

-- 6. RPC SÉCURISÉ POUR SOUVENIRS SSPACE (Section D)
create or replace function public.get_sspace_memories()
returns setof public.posts
language sql
security definer
set search_path = ''
as $$
  select p.*
  from public.posts p
  join public.profiles pr on pr.id = p.user_id
  where p.user_id = (select auth.uid())
    and pr.memories_enabled = true
    and extract(month from p.created_at) = extract(month from now())
    and extract(day from p.created_at) = extract(day from now())
    and extract(year from p.created_at) < extract(year from now())
  order by p.created_at desc;
$$;

revoke all on function public.get_sspace_memories() from public, anon;
grant execute on function public.get_sspace_memories() to authenticated;
