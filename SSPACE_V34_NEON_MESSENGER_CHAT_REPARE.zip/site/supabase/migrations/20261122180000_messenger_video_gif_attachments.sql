-- Messenger : pièces jointes vidéo + GIF (bouton trombone et sélecteur GIF)
alter table public.messages drop constraint if exists messages_message_type_check;
alter table public.messages add constraint messages_message_type_check
  check (message_type in ('text','image','audio','link','video','gif'));

update storage.buckets
set file_size_limit = 52428800, -- 50 Mo (plafond du plan gratuit Supabase)
    allowed_mime_types = array[
      'image/jpeg','image/png','image/webp','image/gif','image/heic','image/heif',
      'video/mp4','video/webm','video/quicktime','video/3gpp',
      'audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav']
where id = 'chat-attachments';
