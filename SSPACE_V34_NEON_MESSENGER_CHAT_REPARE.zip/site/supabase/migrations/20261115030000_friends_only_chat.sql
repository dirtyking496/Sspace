-- Discussions privées réservées aux amis acceptés.
-- Applique la règle côté base de données : même un client modifié ne peut ni ouvrir de conversation
-- ni envoyer de message à quelqu'un dont la demande d'ami n'est pas acceptée.
-- Un ami peut recevoir des messages même hors ligne (ils s'affichent à sa prochaine connexion).

create schema if not exists private;

create or replace function private.are_friends(a uuid, b uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.friend_requests fr
    where fr.status = 'accepted'
      and ((fr.sender_id = a and fr.receiver_id = b) or (fr.sender_id = b and fr.receiver_id = a))
  );
$$;

create or replace function private.enforce_friends_conversation()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not private.are_friends(new.user_one, new.user_two) then
    raise exception 'Il faut être amis (demande acceptée) pour discuter ensemble.' using errcode = '42501';
  end if;
  return new;
end;
$$;

create or replace function private.enforce_friends_message()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  c record;
begin
  select user_one, user_two into c from public.conversations where id = new.conversation_id;
  if not found or not private.are_friends(c.user_one, c.user_two) then
    raise exception 'Il faut être amis (demande acceptée) pour discuter ensemble.' using errcode = '42501';
  end if;
  return new;
end;
$$;

revoke all on function private.are_friends(uuid, uuid) from public, anon, authenticated;
revoke all on function private.enforce_friends_conversation() from public, anon, authenticated;
revoke all on function private.enforce_friends_message() from public, anon, authenticated;

drop trigger if exists enforce_friends_before_conversation on public.conversations;
create trigger enforce_friends_before_conversation
  before insert on public.conversations
  for each row execute function private.enforce_friends_conversation();

drop trigger if exists enforce_friends_before_message on public.messages;
create trigger enforce_friends_before_message
  before insert on public.messages
  for each row execute function private.enforce_friends_message();
