-- SSPACE V16 : bibliothèque d'émeraudes 4D (80 émeraudes uniques, 5 pages de 16).
--  • chaque NOUVEAU compte reçoit 4 émeraudes différentes (tirées au hasard dans la page 1)
--  • chaque compte DÉJÀ existant reçoit 13 émeraudes différentes (tirées au hasard dans la page 1)
--  • demander une émeraude à un ami qui l'a (notification) / lui en envoyer une (elle apparaît dans sa bibliothèque)
--  • progression en % de chaque membre, mise à jour en temps réel
-- Remplace la migration V15 des gemmes (20261122230000) : tu n'as plus besoin de l'exécuter.
-- Idempotent. À exécuter dans Supabase SQL Editor.

create schema if not exists private;

-- Dépendance autonome : certaines bases SSPACE n'ont pas encore installé
-- private.are_friends, même si les autres migrations sociales sont présentes.
create or replace function private.are_friends(a uuid, b uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.friend_requests fr
    where fr.status = 'accepted'
      and ((fr.sender_id = a and fr.receiver_id = b)
        or (fr.sender_id = b and fr.receiver_id = a))
  );
$$;
revoke all on function private.are_friends(uuid, uuid) from public, anon, authenticated;

create or replace function public.album_users_blocked(a uuid, b uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.user_blocks x
    where (x.blocker_id = a and x.blocked_id = b) or (x.blocker_id = b and x.blocked_id = a)
  );
$$;
revoke all on function public.album_users_blocked(uuid, uuid) from public, anon;
grant execute on function public.album_users_blocked(uuid, uuid) to authenticated;

-- Types de notifications
do $$
declare c record;
begin
  for c in select conname from pg_constraint
           where conrelid = 'public.user_notifications'::regclass and contype = 'c'
             and pg_get_constraintdef(oid) ilike '%notif_type%'
  loop
    execute format('alter table public.user_notifications drop constraint %I', c.conname);
  end loop;
end $$;
alter table public.user_notifications add constraint user_notifications_notif_type_check
  check (notif_type in ('message','friend_request','friend_accept','mention','comment','like','friend_activity','gem_gift','gem_request','emerald_gift','emerald_request'));

-- Catalogue des 80 émeraudes (page 1 = Classiques, 2 = Précieuses, 3 = Prismatiques, 4 = Cosmiques, 5 = Légendaires)
create table if not exists public.emerald_catalog (
  id smallint primary key check (id between 1 and 80),
  page smallint not null check (page between 1 and 5),
  name text not null
);
insert into public.emerald_catalog(id, page, name) values
  (1, 1, 'Émeraude Forêt'),
  (2, 1, 'Menthe Glaciale'),
  (3, 1, 'Jade Impérial'),
  (4, 1, 'Pin Boréal'),
  (5, 1, 'Prairie d’Avril'),
  (6, 1, 'Lime Électrique'),
  (7, 1, 'Sapin Royal'),
  (8, 1, 'Olivine Dorée'),
  (9, 1, 'Océan Vert'),
  (10, 1, 'Lagon Tropical'),
  (11, 1, 'Mousse Enchantée'),
  (12, 1, 'Brume d’Eucalyptus'),
  (13, 1, 'Vert Néon'),
  (14, 1, 'Serpentine'),
  (15, 1, 'Matcha Crémeux'),
  (16, 1, 'Cœur de Jungle'),
  (17, 2, 'Aigue-Marine'),
  (18, 2, 'Turquoise Sacrée'),
  (19, 2, 'Cyan Polaire'),
  (20, 2, 'Lac Alpin'),
  (21, 2, 'Azur Profond'),
  (22, 2, 'Saphir Vert'),
  (23, 2, 'Opale d’Émeraude'),
  (24, 2, 'Glacier'),
  (25, 2, 'Paon Bleu-Vert'),
  (26, 2, 'Cobalt Lagon'),
  (27, 2, 'Brume Marine'),
  (28, 2, 'Nuit d’Océan'),
  (29, 2, 'Menthe Bleutée'),
  (30, 2, 'Perle des Mers'),
  (31, 2, 'Électrique Marin'),
  (32, 2, 'Abysse Émeraude'),
  (33, 3, 'Rubis Ardent'),
  (34, 3, 'Corail Solaire'),
  (35, 3, 'Ambre Miel'),
  (36, 3, 'Topaze Dorée'),
  (37, 3, 'Citrine Pâle'),
  (38, 3, 'Orange Couchant'),
  (39, 3, 'Quartz Rose'),
  (40, 3, 'Fuchsia Néon'),
  (41, 3, 'Magenta Royal'),
  (42, 3, 'Améthyste'),
  (43, 3, 'Lavande Brumeuse'),
  (44, 3, 'Indigo Nocturne'),
  (45, 3, 'Saphir Royal'),
  (46, 3, 'Bleu Ciel'),
  (47, 3, 'Cerise Noire'),
  (48, 3, 'Pêche Veloutée'),
  (49, 4, 'Nébuleuse Violette'),
  (50, 4, 'Supernova'),
  (51, 4, 'Aurore Boréale'),
  (52, 4, 'Comète Bleue'),
  (53, 4, 'Pulsar Rose'),
  (54, 4, 'Étoile Filante'),
  (55, 4, 'Trou Noir'),
  (56, 4, 'Voie Lactée'),
  (57, 4, 'Quasar Cyan'),
  (58, 4, 'Éclipse Rouge'),
  (59, 4, 'Galaxie d’Or'),
  (60, 4, 'Orbite Émeraude'),
  (61, 4, 'Météorite Cuivre'),
  (62, 4, 'Constellation'),
  (63, 4, 'Néon Cosmique'),
  (64, 4, 'Poussière d’Étoiles'),
  (65, 5, 'Émeraude Royale'),
  (66, 5, 'Couronne d’Or'),
  (67, 5, 'Platine Céleste'),
  (68, 5, 'Obsidienne Vivante'),
  (69, 5, 'Dragon d’Émeraude'),
  (70, 5, 'Phénix Rubis'),
  (71, 5, 'Cristal de Lune'),
  (72, 5, 'Soleil Levant'),
  (73, 5, 'Trident des Mers'),
  (74, 5, 'Foudre Pourpre'),
  (75, 5, 'Givre Éternel'),
  (76, 5, 'Cœur de Forêt Ancienne'),
  (77, 5, 'Étoile Polaire'),
  (78, 5, 'Opale Arc-en-ciel'),
  (79, 5, 'Reine des Gemmes'),
  (80, 5, 'Émeraude Mythique SSPACE')
on conflict (id) do update set page = excluded.page, name = excluded.name;

create table if not exists public.emerald_collection (
  user_id uuid not null references public.profiles(id) on delete cascade,
  emerald_id smallint not null references public.emerald_catalog(id),
  source text not null default 'pickup' check (source in ('start','welcome','pickup','gift')),
  acquired_at timestamptz not null default now(),
  primary key (user_id, emerald_id)
);
create index if not exists emerald_collection_emerald_idx on public.emerald_collection(emerald_id);

create table if not exists public.emerald_pickups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  emerald_id smallint not null,
  picked_day date not null default ((now() at time zone 'America/Toronto')::date),
  created_at timestamptz not null default now()
);
create index if not exists emerald_pickups_user_day_idx on public.emerald_pickups(user_id, picked_day);

create table if not exists public.emerald_gifts (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  emerald_id smallint not null references public.emerald_catalog(id),
  message text not null default '' check (char_length(message) <= 200),
  created_at timestamptz not null default now(),
  constraint emerald_gifts_not_self check (sender_id <> recipient_id)
);
create index if not exists emerald_gifts_recipient_idx on public.emerald_gifts(recipient_id, created_at desc);
create index if not exists emerald_gifts_sender_idx on public.emerald_gifts(sender_id, created_at desc);
create index if not exists emerald_gifts_emerald_idx on public.emerald_gifts(emerald_id);

create table if not exists public.emerald_requests (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  target_id uuid not null references public.profiles(id) on delete cascade,
  emerald_id smallint not null references public.emerald_catalog(id),
  message text not null default '' check (char_length(message) <= 200),
  status text not null default 'open' check (status in ('open','filled','cancelled')),
  created_at timestamptz not null default now(),
  filled_at timestamptz,
  constraint emerald_requests_not_self check (requester_id <> target_id)
);
create index if not exists emerald_requests_requester_idx on public.emerald_requests(requester_id, status);
create index if not exists emerald_requests_target_idx on public.emerald_requests(target_id, status);
create index if not exists emerald_requests_emerald_idx on public.emerald_requests(emerald_id);

alter table public.emerald_catalog enable row level security;
alter table public.emerald_collection enable row level security;
alter table public.emerald_pickups enable row level security;
alter table public.emerald_gifts enable row level security;
alter table public.emerald_requests enable row level security;
revoke all on public.emerald_catalog, public.emerald_collection, public.emerald_pickups, public.emerald_gifts, public.emerald_requests from anon, authenticated;
grant select on public.emerald_catalog, public.emerald_collection, public.emerald_pickups, public.emerald_gifts, public.emerald_requests to authenticated;

drop policy if exists "Catalog readable" on public.emerald_catalog;
create policy "Catalog readable" on public.emerald_catalog for select to authenticated using (true);
drop policy if exists "Libraries readable by members" on public.emerald_collection;
create policy "Libraries readable by members" on public.emerald_collection for select to authenticated using (true);
drop policy if exists "Own pickups readable" on public.emerald_pickups;
create policy "Own pickups readable" on public.emerald_pickups for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "Own gifts readable" on public.emerald_gifts;
create policy "Own gifts readable" on public.emerald_gifts for select to authenticated using ((select auth.uid()) in (sender_id, recipient_id));
drop policy if exists "Own requests readable" on public.emerald_requests;
create policy "Own requests readable" on public.emerald_requests for select to authenticated using ((select auth.uid()) in (requester_id, target_id));

-- Temps réel : un cadeau apparaît tout de suite dans la bibliothèque de l'autre
do $$
begin
  alter publication supabase_realtime add table public.emerald_collection;
exception when duplicate_object then null; when undefined_object then null;
end $$;

-- 4 émeraudes différentes pour chaque NOUVEAU compte
create or replace function private.trg_emerald_starter()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.emerald_collection(user_id, emerald_id, source)
  select new.id, g, 'start' from generate_series(1, 16) g order by random() limit 4
  on conflict do nothing;
  return new;
end $$;
revoke all on function private.trg_emerald_starter() from public, anon, authenticated;
drop trigger if exists emerald_starter_after_profile on public.profiles;
create trigger emerald_starter_after_profile after insert on public.profiles
  for each row execute function private.trg_emerald_starter();

-- 13 émeraudes différentes pour chaque compte DÉJÀ existant (une seule fois : seulement ceux qui n'ont encore rien)
insert into public.emerald_collection(user_id, emerald_id, source)
select p.id, x.g, 'welcome'
from public.profiles p
cross join lateral (
  select g from generate_series(1, 16) g
  order by md5(p.id::text || g::text || random()::text) limit 13
) x
where not exists (select 1 from public.emerald_collection c where c.user_id = p.id)
on conflict do nothing;

-- Ramassages restants aujourd'hui (10 par jour, heure du Québec)
create or replace function public.emerald_pickups_left()
returns int language sql stable security definer set search_path = '' as $$
  select greatest(0, 10 - count(*))::int from public.emerald_pickups
  where user_id = (select auth.uid()) and picked_day = ((now() at time zone 'America/Toronto')::date);
$$;
revoke all on function public.emerald_pickups_left() from public, anon;
grant execute on function public.emerald_pickups_left() to authenticated;

-- Ramasser une émeraude que tu n'as pas encore (les pages avancées sont plus rares)
create or replace function public.emerald_pickup()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  used int;
  remaining int;
  r numeric;
  pick int;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  select count(*) into used from public.emerald_pickups
    where user_id = me and picked_day = ((now() at time zone 'America/Toronto')::date);
  if used >= 10 then raise exception 'Limite de 10 ramassages par jour atteinte. Reviens demain !'; end if;
  select count(*) into remaining from public.emerald_catalog c
    where not exists (select 1 from public.emerald_collection x where x.user_id = me and x.emerald_id = c.id);
  if remaining = 0 then raise exception 'Collection complète ! Tu possèdes les 80 émeraudes 🏆'; end if;
  r := random();
  select s.id into pick from (
    select g.id, sum(g.w) over (order by g.id) as cw, sum(g.w) over () as tw from (
      select c.id, (case ((c.id - 1)::int / 16) when 0 then 5 when 1 then 3.5 when 2 then 2.2 when 3 then 1.2 else 0.5 end)::numeric as w
      from public.emerald_catalog c
      where not exists (select 1 from public.emerald_collection x where x.user_id = me and x.emerald_id = c.id)
    ) g
  ) s where s.cw >= r * s.tw order by s.cw limit 1;
  insert into public.emerald_pickups(user_id, emerald_id) values (me, pick);
  insert into public.emerald_collection(user_id, emerald_id, source) values (me, pick, 'pickup');
  return jsonb_build_object('emerald_id', pick, 'left', 10 - used - 1);
end $$;
revoke all on function public.emerald_pickup() from public, anon;
grant execute on function public.emerald_pickup() to authenticated;

-- Envoyer une de tes émeraudes à un ami qui ne l'a pas (tu la gardes : c'est un partage)
create or replace function public.emerald_send(p_recipient uuid, p_emerald int, p_message text default '')
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  msg text := left(btrim(coalesce(p_message, '')), 200);
  nm text;
  gid uuid;
  n int;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  if p_recipient is null or p_recipient = me then raise exception 'Choisis un autre membre.'; end if;
  select name into nm from public.emerald_catalog where id = p_emerald;
  if nm is null then raise exception 'Émeraude inconnue.'; end if;
  if not private.are_friends(me, p_recipient) then raise exception 'Tu ne peux envoyer des émeraudes qu’à tes amis.'; end if;
  if public.album_users_blocked(me, p_recipient) then raise exception 'Envoi impossible.'; end if;
  if not exists (select 1 from public.emerald_collection where user_id = me and emerald_id = p_emerald) then
    raise exception 'Tu ne possèdes pas encore cette émeraude.';
  end if;
  insert into public.emerald_collection(user_id, emerald_id, source) values (p_recipient, p_emerald, 'gift')
    on conflict do nothing;
  get diagnostics n = row_count;
  if n = 0 then raise exception 'Cet ami possède déjà cette émeraude.'; end if;
  insert into public.emerald_gifts(sender_id, recipient_id, emerald_id, message) values (me, p_recipient, p_emerald, msg) returning id into gid;
  update public.emerald_requests set status = 'filled', filled_at = now()
    where requester_id = p_recipient and emerald_id = p_emerald and status = 'open';
  insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
    values (p_recipient, me, 'emerald_gift', gid,
      't’a envoyé l’émeraude « ' || nm || ' » 💚 Elle est dans ta bibliothèque !' || case when msg <> '' then ' « ' || msg || ' »' else '' end);
  return jsonb_build_object('ok', true, 'emerald_id', p_emerald);
end $$;
revoke all on function public.emerald_send(uuid, int, text) from public, anon;
grant execute on function public.emerald_send(uuid, int, text) to authenticated;

-- Demander une émeraude manquante à un ami qui l'a
create or replace function public.emerald_request_create(p_target uuid, p_emerald int, p_message text default '')
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  msg text := left(btrim(coalesce(p_message, '')), 200);
  nm text;
  rid uuid;
  open_count int;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  if p_target is null or p_target = me then raise exception 'Choisis un autre membre.'; end if;
  select name into nm from public.emerald_catalog where id = p_emerald;
  if nm is null then raise exception 'Émeraude inconnue.'; end if;
  if not private.are_friends(me, p_target) then raise exception 'Tu ne peux demander des émeraudes qu’à tes amis.'; end if;
  if public.album_users_blocked(me, p_target) then raise exception 'Demande impossible.'; end if;
  if exists (select 1 from public.emerald_collection where user_id = me and emerald_id = p_emerald) then
    raise exception 'Tu possèdes déjà cette émeraude.';
  end if;
  if not exists (select 1 from public.emerald_collection where user_id = p_target and emerald_id = p_emerald) then
    raise exception 'Cet ami ne possède pas cette émeraude.';
  end if;
  if exists (select 1 from public.emerald_requests where requester_id = me and target_id = p_target and emerald_id = p_emerald and status = 'open') then
    raise exception 'Tu as déjà fait cette demande à cet ami.';
  end if;
  select count(*) into open_count from public.emerald_requests where requester_id = me and status = 'open';
  if open_count >= 10 then raise exception 'Maximum 10 demandes ouvertes à la fois.'; end if;
  insert into public.emerald_requests(requester_id, target_id, emerald_id, message) values (me, p_target, p_emerald, msg) returning id into rid;
  insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
    values (p_target, me, 'emerald_request', rid,
      'te demande l’émeraude « ' || nm || ' » 🙏 Ouvre ta bibliothèque pour la lui envoyer.' || case when msg <> '' then ' « ' || msg || ' »' else '' end);
  return rid;
end $$;
revoke all on function public.emerald_request_create(uuid, int, text) from public, anon;
grant execute on function public.emerald_request_create(uuid, int, text) to authenticated;

create or replace function public.emerald_request_cancel(p_id uuid)
returns void language sql security definer set search_path = '' as $$
  update public.emerald_requests set status = 'cancelled'
  where id = p_id and requester_id = (select auth.uid()) and status = 'open';
$$;
revoke all on function public.emerald_request_cancel(uuid) from public, anon;
grant execute on function public.emerald_request_cancel(uuid) to authenticated;

-- Progression des bibliothèques (p_ids = null → les 60 plus avancées)
create or replace function public.emerald_progress(p_ids uuid[] default null)
returns table(user_id uuid, owned int)
language sql stable security definer set search_path = '' as $$
  select c.user_id, count(*)::int as owned
  from public.emerald_collection c
  where p_ids is null or c.user_id = any(p_ids)
  group by c.user_id
  order by 2 desc
  limit case when p_ids is null then 60 else 500 end;
$$;
revoke all on function public.emerald_progress(uuid[]) from public, anon;
grant execute on function public.emerald_progress(uuid[]) to authenticated;
