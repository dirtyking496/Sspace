-- SSPACE Phase 2 — read-only Supabase permission snapshot
-- Run this single SELECT in Supabase SQL Editor and share the JSON result for review.
-- It does not change schema, data, policies, grants, or storage.

WITH target_tables AS (
  SELECT unnest(ARRAY[
    'profiles','posts','comments','likes','friend_requests','user_blocks',
    'conversations','messages','groups','group_members','user_notifications',
    'profile_album_photos','post_drafts','content_reports'
  ]) AS table_name
),
table_state AS (
  SELECT t.table_name,
         c.relrowsecurity AS rls_enabled,
         c.relforcerowsecurity AS rls_forced
  FROM target_tables t
  LEFT JOIN pg_namespace n ON n.nspname = 'public'
  LEFT JOIN pg_class c ON c.relnamespace = n.oid
                      AND c.relname = t.table_name
),
policies AS (
  SELECT jsonb_agg(jsonb_build_object(
    'schema', schemaname, 'table', tablename, 'name', policyname,
    'command', cmd, 'roles', roles, 'using', qual, 'with_check', with_check
  ) ORDER BY tablename, policyname) AS data
  FROM pg_policies
  WHERE schemaname = 'public' AND tablename IN (SELECT table_name FROM target_tables)
),
table_grants AS (
  SELECT jsonb_agg(jsonb_build_object(
    'table', table_name, 'grantee', grantee, 'privilege', privilege_type
  ) ORDER BY table_name, grantee, privilege_type) AS data
  FROM information_schema.table_privileges
  WHERE table_schema = 'public'
    AND table_name IN (SELECT table_name FROM target_tables)
    AND grantee IN ('anon','authenticated','service_role')
),
column_grants AS (
  SELECT jsonb_agg(jsonb_build_object(
    'table', table_name, 'column', column_name,
    'grantee', grantee, 'privilege', privilege_type
  ) ORDER BY table_name, column_name, grantee) AS data
  FROM information_schema.column_privileges
  WHERE table_schema = 'public'
    AND table_name IN (SELECT table_name FROM target_tables)
    AND grantee IN ('anon','authenticated','service_role')
),
storage_policies AS (
  SELECT jsonb_agg(jsonb_build_object(
    'name', policyname, 'command', cmd, 'roles', roles,
    'using', qual, 'with_check', with_check
  ) ORDER BY policyname) AS data
  FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects'
),
storage_buckets AS (
  SELECT jsonb_agg(jsonb_build_object(
    'id', id, 'public', public, 'file_size_limit', file_size_limit,
    'allowed_mime_types', allowed_mime_types
  ) ORDER BY id) AS data
  FROM storage.buckets
  WHERE id IN ('profile-albums','chat-attachments','post-images')
),
realtime_tables AS (
  SELECT jsonb_agg(jsonb_build_object(
    'schema', schemaname, 'table', tablename
  ) ORDER BY schemaname, tablename) AS data
  FROM pg_publication_tables
  WHERE pubname = 'supabase_realtime'
    AND schemaname = 'public'
    AND tablename IN ('user_notifications','groups','group_members','messages','conversations')
)
SELECT jsonb_pretty(jsonb_build_object(
  'captured_at', now(),
  'table_rls', (SELECT jsonb_agg(to_jsonb(table_state) ORDER BY table_name) FROM table_state),
  'table_grants', (SELECT data FROM table_grants),
  'column_grants', (SELECT data FROM column_grants),
  'rls_policies', (SELECT data FROM policies),
  'storage_buckets', (SELECT data FROM storage_buckets),
  'storage_object_policies', (SELECT data FROM storage_policies),
  'realtime_publication', (SELECT data FROM realtime_tables)
)) AS sspace_permission_audit;
