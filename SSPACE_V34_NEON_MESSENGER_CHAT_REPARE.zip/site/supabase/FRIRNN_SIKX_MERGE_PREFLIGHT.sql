-- SSPACE — inventaire préalable à la fusion FRIRNN -> SIKX
-- À exécuter séparément dans le SQL Editor de FRIRNN puis de SIKX.
-- SCRIPT DE DIAGNOSTIC SEULEMENT : ne copie, ne modifie et ne supprime aucune donnée.
-- Ne jamais partager de clé service_role, mot de passe ou jeton privé.

-- 1) Tables publiques et nombre de lignes (estimation exacte par COUNT).
create temporary table if not exists sspace_merge_table_inventory (
  schema_name text,
  table_name text,
  row_count bigint
) on commit preserve rows;
truncate table sspace_merge_table_inventory;

do $$
declare r record; n bigint;
begin
  for r in
    select schemaname, tablename
    from pg_tables
    where schemaname in ('public','storage')
    order by schemaname, tablename
  loop
    begin
      execute format('select count(*) from %I.%I', r.schemaname, r.tablename) into n;
      insert into sspace_merge_table_inventory values (r.schemaname, r.tablename, n);
    exception when others then
      insert into sspace_merge_table_inventory values (r.schemaname, r.tablename, null);
    end;
  end loop;
end $$;

select schema_name, table_name, row_count
from sspace_merge_table_inventory
order by schema_name, table_name;

-- 2) Colonnes : indispensable pour faire correspondre les deux schémas.
select table_schema, table_name, ordinal_position, column_name,
       data_type, udt_name, is_nullable, column_default
from information_schema.columns
where table_schema in ('public','storage')
order by table_schema, table_name, ordinal_position;

-- 3) Relations entre tables (clés étrangères).
select tc.table_schema, tc.table_name, kcu.column_name,
       ccu.table_schema as foreign_table_schema,
       ccu.table_name as foreign_table_name,
       ccu.column_name as foreign_column_name,
       tc.constraint_name
from information_schema.table_constraints tc
join information_schema.key_column_usage kcu
  on tc.constraint_name = kcu.constraint_name
 and tc.constraint_schema = kcu.constraint_schema
join information_schema.constraint_column_usage ccu
  on ccu.constraint_name = tc.constraint_name
 and ccu.constraint_schema = tc.constraint_schema
where tc.constraint_type = 'FOREIGN KEY'
  and tc.table_schema = 'public'
order by tc.table_name, kcu.ordinal_position;

-- 4) Comptes Auth : seulement le total, jamais les courriels ni les secrets.
select 'auth.users' as source, count(*)::bigint as row_count
from auth.users;

-- 5) Buckets Storage : seulement les noms, paramètres et volumes.
select b.id, b.name, b.public, b.file_size_limit,
       (select count(*) from storage.objects o where o.bucket_id = b.id) as object_count
from storage.buckets b
order by b.id;

-- 6) Fonctions applicatives publiques (noms/signatures seulement).
select n.nspname as schema_name, p.proname as function_name,
       pg_get_function_identity_arguments(p.oid) as arguments
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname in ('public','private')
order by n.nspname, p.proname;

-- 7) État des politiques RLS (noms seulement).
select schemaname, tablename, policyname, permissive, roles, cmd
from pg_policies
where schemaname in ('public','storage')
order by schemaname, tablename, policyname;

-- Fin : exporte les résultats de ces requêtes pour FRIRNN et SIKX.
-- La migration réelle sera construite à partir des différences observées,
-- avec correspondance des IDs, utilisateurs Auth et chemins Storage.
