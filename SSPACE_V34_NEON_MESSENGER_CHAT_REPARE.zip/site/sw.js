const CACHE='sspace-static-v22-live-chat';
const MEDIA_CACHE='sspace-media-v1';
const MAX_MEDIA_CACHE_ENTRIES=100;
const CORE_ASSETS=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./assets/gallery/sspace-neon-blue.webp','./assets/gallery/sspace-pink-hearts.webp','./assets/gallery/sspace-cosmic-wings.webp','./assets/gallery/sspace-rainbow-equalizer.webp','./assets/gallery/sspace-nebula-heart.webp','./assets/gallery/sspace-tropical-sunset.webp'];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE_ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys()
      .then(keys=>Promise.all(keys.filter(key=>key.startsWith('sspace-static-')&&key!==CACHE).map(key=>caches.delete(key))))
      .then(()=>self.clients.claim())
  );
});

self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET')return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin)return;
  if(url.pathname.startsWith('/messenger/')||url.pathname.startsWith('/jeux-espace/'))return;

  // Cache média borné : sert immédiatement une image déjà vue, puis actualise en arrière-plan.
  if(request.destination==='image'){
    event.respondWith((async()=>{
      const cache=await caches.open(MEDIA_CACHE);
      const cached=await cache.match(request);
      const refresh=fetch(request).then(async response=>{
        if(response&&response.ok&&response.type!=='opaque'){
          await cache.put(request,response.clone());
          const keys=await cache.keys();
          while(keys.length>MAX_MEDIA_CACHE_ENTRIES){const oldest=keys.shift();await cache.delete(oldest)}
        }
        return response;
      }).catch(()=>cached);
      if(cached){event.waitUntil(refresh.then(()=>undefined));return cached}
      return (await refresh)||Response.error();
    })());
    return;
  }

  if(request.mode==='navigate'){
    event.respondWith(
      fetch(request).then(response=>{
        if(response&&response.ok){
          const copy=response.clone();
          event.waitUntil(caches.open(CACHE).then(cache=>cache.put('./index.html',copy)));
        }
        return response;
      }).catch(()=>caches.match('./index.html'))
    );
    return;
  }

  if(request.destination==='document'||request.destination==='script'||request.destination==='style'||request.destination==='image'||url.pathname.endsWith('.webmanifest')){
    event.respondWith(
      caches.match(request).then(cached=>{
        const network=fetch(request).then(response=>{
          if(response&&response.ok){
            const copy=response.clone();
            event.waitUntil(caches.open(CACHE).then(cache=>cache.put(request,copy)));
          }
          return response;
        }).catch(()=>cached);
        if(cached){
          event.waitUntil(network.then(()=>undefined));
          return cached;
        }
        return network;
      })
    );
  }
});
