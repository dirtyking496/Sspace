# SSPACE V9 – Appels et envoi rapide

- Interface des appels vocaux et vidéo en plein écran.
- Flèche « Retour » pour réduire l'interface sans raccrocher.
- Appel vidéo : mini-fenêtre dans SSPACE, déplaçable et redimensionnable au toucher.
- Bouton « Miniature » tente d'utiliser Picture-in-Picture du navigateur Android; sa disponibilité dépend du navigateur et de la version Android.
- Appel audio : écran plein écran et bouton de réduction sans terminer l'appel.
- Dans les champs de message, Entrée envoie; Maj+Entrée ajoute une nouvelle ligne.
- Version du cache service worker augmentée pour forcer la mise à jour.

À tester sur l'appareil et l'hébergement réels : les permissions caméra/micro, la prise en charge Picture-in-Picture et le comportement en arrière-plan varient selon le navigateur et le mode d'installation PWA.
