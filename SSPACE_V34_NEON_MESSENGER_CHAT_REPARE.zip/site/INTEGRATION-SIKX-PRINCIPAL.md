# SSPACE — paquet intégré (SIKX principal)

Ce paquet reprend l'application SSPACE fusionnée V1/V2 et les fonctions présentes dans le ZIP source : profils, découverte, demandes d'amis, notifications, conversations privées, médias de chat, messages vocaux, fenêtres flottantes, publications, commentaires/réactions, groupes, thèmes et boutique, ainsi que les appels audio/vidéo privés WebRTC.

## Projet Supabase principal

L'application est configurée pour utiliser le projet SIKX :
`https://sikxoyylihsigzirewmi.supabase.co`

## Appels audio/vidéo

Le fichier de migration est inclus :
`supabase/migrations/20261120130000_private_video_audio_call_signals.sql`

Selon l'état réel du projet SIKX, cette migration doit être appliquée une seule fois si elle n'y est pas déjà présente. Vérifier d'abord l'historique des migrations et la table `public.call_signals`; ne pas exécuter à nouveau les anciennes migrations de fusion à l'aveugle.

Les appels utilisent WebRTC et les serveurs STUN publics configurés dans `index.html`. Certains réseaux peuvent nécessiter un serveur TURN.

## Fusion des données de FRIRNN

Le code du présent paquet pointe vers SIKX. Aucun export de base de données FRIRNN (schéma, données, utilisateurs Auth ou fichiers Storage) n'était inclus dans le ZIP source disponible. Les données FRIRNN ne sont donc pas copiées dans ce paquet. Pour les fusionner sans perte, il faut d'abord exporter FRIRNN et préparer une migration contrôlée vers SIKX. Conserver FRIRNN et ses sauvegardes jusqu'à validation complète.

## Déploiement

Déployer le contenu du dossier `sspace_sikx/` sur l'hébergement Web utilisé. Tester la connexion, les profils, les messages, les médias et les appels avec deux comptes distincts avant publication.
