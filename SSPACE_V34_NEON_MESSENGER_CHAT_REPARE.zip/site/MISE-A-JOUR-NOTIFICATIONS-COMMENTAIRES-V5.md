# SSPACE V5 — Notifications, demandes d'amis et commentaires

## Interface
- L'entrée « Notifications & amis » est maintenant la première entrée de la colonne latérale.
- L'onglet mobile « Alertes » est placé en premier.
- Le menu principal regroupe les notifications et les demandes d'amis dans un seul accès.
- Le compteur dans un cœur affiche le total des notifications non lues et des demandes d'amis en attente.
- Le centre de notifications conserve les deux panneaux : demandes d'amis en haut, notifications ensuite.

## Commentaires
- Les réponses imbriquées à un commentaire sont conservées et restent accessibles avec « Répondre ».
- La saisie de `@` propose des pseudos existants; choisir un membre insère son @pseudo.
- Les mentions sont enregistrées dans `comment_mentions` et créent une notification pour le membre identifié.
- L'appui long (2 secondes) sur la réaction d'un commentaire ouvre le sélecteur : 👍 ❤️ 😂 😮 😢 😠.

## Étape Supabase obligatoire
Dans le projet **SIKX**, ouvrir SQL Editor et exécuter une fois :
`supabase/migrations/20261120150000_comment_mentions_and_notifications.sql`

La nouvelle table est protégée par RLS. Les réponses et réactions de commentaires réutilisent les fonctions déjà présentes dans le projet. Aucun compte ni contenu existant n'est supprimé.

## Vérifications locales
- Syntaxe JavaScript vérifiée avec Node.js.
- Archive ZIP vérifiée après création.
- Les tests en direct nécessitent un déploiement et l'exécution de la migration sur SIKX.
