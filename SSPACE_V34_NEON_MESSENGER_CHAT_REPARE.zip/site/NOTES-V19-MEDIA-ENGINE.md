# SSPACE V19 — Centre des médias et optimisation

## Intégration
- Ajout du bouton « Médias » dans l'en-tête et d'un centre de gestion responsive.
- Optimisation avant téléversement des images JPEG, PNG et WebP : redimensionnement maximal 2560 px, conversion WebP qualité 0,84 lorsque le résultat est plus léger. GIF animés et vidéos ne sont pas modifiés.
- Chargement progressif des images : `loading="lazy"` hors zone haute, décodage asynchrone et priorité basse pour les images secondaires.
- Miniatures WebP (maximum 480 px) créées pour les images ajoutées au coffre local.
- Cache image Service Worker séparé, stratégie cache-first avec actualisation réseau en arrière-plan et limite de 100 entrées.
- Coffre local IndexedDB : ajout de fichiers, aperçu miniature, téléchargement individuel, suppression et export de l'index.
- Le coffre est local à l'appareil/navigateur; il ne remplace pas une sauvegarde distante Supabase et n'est pas synchronisé entre appareils.

## Fichiers touchés
- `site/index.html`
- `site/sw.js`
- `dist/index.html` et `dist/sw.js` synchronisés via `node scripts/copy-site.mjs`

## Vérifications exécutées
- `node --check` sur les scripts JavaScript inline extraits du HTML : réussi.
- `node --check site/sw.js` : réussi.
- Vérification des identifiants HTML : 563 occurrences; les doublons détectés sont des IDs présents dans des gabarits HTML générés dynamiquement, déjà présents dans le projet.
- Synchronisation `site/` vers `dist/` : réussie.

## Limites des tests
- Le build complet `npm run build` n'a pas été exécuté : `node_modules` n'est pas présent dans l'archive et aucune installation de dépendances n'a été effectuée.
- Les flux Supabase réels, la sauvegarde IndexedDB sur différents appareils et les performances doivent être testés dans un navigateur HTTPS après déploiement.
