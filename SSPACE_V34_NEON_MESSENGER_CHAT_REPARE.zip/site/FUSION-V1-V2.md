# SSPACE — fusion version 2 (Netlify/MODO) dans version 1 (Android/Bulles) — 18 nov. 2026

## Base conservée (version 1)
Navigation Android en haut, galerie de couvertures, thèmes gratuits, chat privé photo/vidéo (50 Mo), panneau (i), blocage 12 h, indicateur « écrit… », bulles flottantes.

## Ajouté depuis la version 2
Centre MODO Gold, connexion Google (PKCE), effets de texte, favoris, GIF dans le blogue, cœurs flottants, couverture rognable, menu en tiroir/colonne, boutique avec bouton « Appliquer », correctifs v5–v7.

## Nouveautés de cette fusion
- Demandes d'amis déplacées dans l'onglet Notifications; alertes EN DIRECT (Realtime + son + notification navigateur + pastille sur le menu).
- Appels vocaux WebRTC dans le chat privé (bouton 📞 dans le chat et les fenêtres flottantes).
- Nom du profil : fin du « Nouveau membre » (Google, courriel, fiche privée); enregistrement du profil avant les infos privées; brouillon automatique; sauvegarde locale de restauration.
- MODO : migration backend complète + application serveur (suspension, maintenance, anti-spam).

## Base de données (projet Supabase « Sspace »)
Vérifié le 19 nov. 2026 : les migrations appels vocaux, demandes d'amis en direct et backend MODO sont DÉJÀ appliquées (avec le correctif `fix_call_friendship_guard`). Rien à exécuter. Ne pas rejouer d'anciens scripts SQL : ils écraseraient le correctif d'amitié des appels.

## Réactions et commentaires (ajout du 19 nov.)
- Commentaires : réponses (fil indenté) et réaction sur chaque commentaire.
- Appui long de 2 s sur J'aime (publication ou commentaire) : choix 👍 / ❤️ / 😠. Un simple clic = J'aime.
- Base : migration `comment_reactions_types` déjà appliquée (colonne `reaction_type` + droit de modifier sa réaction).
- Notifications en premier dans le menu.

## Limites
- Appels : STUN public seulement; certains réseaux mobiles/entreprise exigent un serveur TURN (constante CALL_ICE_SERVERS). L'appel sonne seulement si l'autre personne a SSPACE ouvert (pas de push hors application).
- Non testé sur appareils réels ni avec deux comptes : à valider avant publication.

## Mise à jour du 20 nov. 2026 (v13)
- Profil : onglet du nom en doré (👑 animée + reflet) au-dessus de @utilisateur, sur ton profil et les profils publics; bouton « Modifier la couverture » en haut à droite.
- Album : titre « Album de [nom] » centré, dégradé doré animé, 🪙 et ✨ de chaque côté (aussi dans la fenêtre du profil public). Animations coupées si « réduire les animations » est activé.
- Écran de connexion recréé : bouton qui indique « Connexion… » pendant l'attente, délai maximal de 15 s avec message clair, messages d'erreur en français, validation du courriel et du mot de passe, bouton Afficher/Masquer le mot de passe, filet de sécurité si le profil ne se charge pas. Les identifiants (ids) du HTML sont inchangés.
- Cache du service worker : `sspace-static-v12` → `sspace-static-v13` (les appareils récupèrent ainsi le nouveau index.html).
- Aucune migration SQL à exécuter.

## Appels audio et vidéo privés — Supabase SIKX

Le client utilise le projet `https://sikxoyylihsigzirewmi.supabase.co`.
La migration `supabase/migrations/20261120130000_private_video_audio_call_signals.sql`
crée la table `public.call_signals`, ses règles RLS et son abonnement Realtime.
Elle doit être exécutée une fois dans le SQL Editor du projet SIKX avant les tests
entre deux comptes amis acceptés. Les appels vidéo utilisent WebRTC; pour les réseaux
qui bloquent les connexions directes, un service TURN peut aussi être nécessaire.
