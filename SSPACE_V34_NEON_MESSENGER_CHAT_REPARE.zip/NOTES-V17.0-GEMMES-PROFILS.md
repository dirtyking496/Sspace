# SSPACE V17.0 — Progression des gemmes sur les profils

## Ajout
- Affiche un badge gemme animé sur le profil personnel et sur chaque profil public.
- Affiche le pourcentage de collection complétée, calculé sur les 80 gemmes.
- Affiche le nombre de gemmes obtenues et une barre de progression.
- Utilise la fonction Supabase existante `emerald_progress` pour récupérer le nombre public de gemmes sans lire directement la table de collection.
- Actualise le badge du profil personnel au chargement de la collection, après les ramassages et les récompenses.

## Fichiers modifiés
- `site/index.html`
- `dist/index.html`

## Déploiement
Le code est prêt dans cette archive, mais la mise à jour du site Vercel n'est pas effectuée par la création de cette archive. Il faut publier les fichiers sur le dépôt connecté à Vercel.
