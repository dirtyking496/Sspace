# V24 — Fondation hébergement et stockage cloud

Cette version documente l'architecture unifiée Vercel + Supabase et ajoute une migration SQL idempotente pour les buckets privés/publics de médias, fichiers personnels et sauvegardes. Les chemins privés sont cloisonnés par UUID du propriétaire et protégés par RLS Storage.

Important : la migration prépare le stockage cloud mais ne prétend pas activer un déploiement externe, un compte Vercel/Supabase, une sauvegarde automatique planifiée ou une restauration automatique. Il faut exécuter la migration dans le bon projet Supabase et configurer les variables d'environnement Vercel. Voir `docs/SSPACE-V24-HEBERGEMENT-STOCKAGE.md`.
