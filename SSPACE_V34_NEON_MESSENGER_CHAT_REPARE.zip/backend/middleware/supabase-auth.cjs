module.exports = async function requireSupabaseUser(req, res, next) {
  const header = req.get('authorization') || '';
  const match = header.match(/^Bearer\s+(.+)$/i);
  const token = match?.[1]?.trim();
  if (!token) return res.status(401).json({ error: 'Session SSPACE requise.' });

  const supabaseUrl = process.env.SUPABASE_URL?.replace(/\/$/, '');
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!supabaseUrl || !anonKey) {
    return res.status(503).json({ error: 'Vérification Supabase non configurée.' });
  }

  try {
    // Vérifie chaque requête auprès de Supabase Auth : aucun JWT local ni cache
    // qui pourrait laisser passer une session révoquée après déconnexion.
    const response = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: { apikey: anonKey, Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(8000)
    });
    if (!response.ok) return res.status(401).json({ error: 'Session SSPACE invalide ou expirée.' });
    const user = await response.json();
    if (!user?.id) return res.status(401).json({ error: 'Session SSPACE invalide.' });
    req.user = { id: user.id, email: user.email };
    return next();
  } catch (error) {
    console.error('Supabase auth verification failed:', error.message);
    return res.status(503).json({ error: 'Service d’authentification temporairement indisponible.' });
  }
};
