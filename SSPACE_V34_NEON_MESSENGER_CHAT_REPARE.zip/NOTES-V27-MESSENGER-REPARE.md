# SSPACE V27 — Messenger réactivé et erreur Supabase corrigée

## Cause de « Messenger ne s'affiche plus »
Le fichier `messenger/.env.production` (URL + clé publique Supabase SIKX) était absent du ZIP.
Au build Vercel, `isSupabaseConfigured` valait `false` et Messenger affichait l'écran « Configuration requise » au lieu de l'application.

## Corrections
- Ajout de `messenger/.env.production` (et `.env.development`) avec l'URL et la clé publishable déjà utilisées par `site/index.html`.
- `messenger/src/lib/supabase.ts` : valeurs de secours intégrées, donc Messenger ne retombe plus sur l'écran de configuration si le fichier .env manque.
- `messenger/public/sw.js` : cache passé à `sspace-messenger-v4-fix` pour purger toute ancienne version mise en cache.
- Bouton « ↗ Messenger » du site conservé (en-tête, liaison de session par nonce) — aucune modification nécessaire.

## Base Supabase (projet sikxoyylihsigzirewmi) — déjà appliqué
Migration `messenger_allow_gif_message_type` : la contrainte `messages_message_type_check` n'acceptait pas `gif` (la migration `20261122180000` n'avait jamais été jouée). L'envoi de GIF depuis Messenger échouait avec une erreur Supabase. Types acceptés : text, image, audio, link, video, gif.

## À faire
1. Redéployer le dossier racine complet sur Vercel (le build génère `dist/messenger`).
2. Ouvrir `/messenger/` une fois et recharger (Ctrl+Maj+R) pour renouveler le service worker.
3. Facultatif : ajouter `VITE_GIPHY_API_KEY` dans Vercel pour le sélecteur de GIF, et un TURN pour les appels sur réseaux mobiles.

## Bowling 3D — recentrage (jeux-espace/bowling-3d.html)
- Scène entièrement recentrée : piste, quilles et boule partagent le même axe vertical, à toutes les tailles d'écran (zone de jeu centrée, hauteur bornée pour tenir sans défiler).
- Quilles à la bonne taille (elles masquaient la piste) et rack de 10 quilles en triangle.
- La boule est visible dès le départ, centrée dans l'espace joueur (zone d'élan + ligne de faute + anneau lumineux). Elle roule en perspective, avec trous qui tournent.
- Nouveau curseur « Position » (ou glisser la boule sur la piste, flèches ← →) ; la ligne de visée part de la boule et suit exactement la trajectoire réelle.
- Physique réelle boule/quilles/quilles-quilles, gouttières, balayage des quilles tombées.
- Score réécrit (strike, spare, 10e manche à 3 lancers) ; partie parfaite testée = 300.

## Base Supabase — corrections appliquées directement (23 nov. 2026)
- Migration `20261122200000_album_photo_likes_comments.sql` appliquée : tables `album_photo_likes` et `album_photo_comments` + RLS (J'aime et commentaires des photos d'album).
- Mode maintenance (`sspace_control_settings.maintenance_enabled`) remis à `false` : il bloquait les écritures des membres non-admin (messages, commentaires, publications). Réactivable depuis le Centre MODO.
- À surveiller : tâche planifiée IA `sspace_ai_cron_token_valid` (permission refusée chaque minute) — sans effet sur Messenger.
