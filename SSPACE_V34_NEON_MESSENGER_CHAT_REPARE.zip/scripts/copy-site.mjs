import { cp, mkdir, rm } from 'node:fs/promises';
await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
await cp('site', 'dist', { recursive: true });
await cp('jeux-espace', 'dist/jeux-espace', { recursive: true });
console.log('SSPACE Social, assets, migrations and games copied to dist/.');
