# SSPACE V25 — Stockage cloud additionnel désactivé

La demande de désactivation concerne la couche de stockage cloud ajoutée en V24. La migration qui créait les buckets `profile-media`, `album-media`, `user-files` et `user-backups` a été retirée de cette version. Aucun nouveau bucket ni aucune sauvegarde cloud planifiée ne sont demandés ou configurés par V25.

## Fonctions conservées
- Le coffre local IndexedDB de V19 : ajout, aperçu, miniatures, téléchargement, suppression et export de l’index.
- La compression et l’optimisation d’images, les miniatures HD, le chargement progressif et le cache local du navigateur.
- Les fonctionnalités sociales, profils, publications, albums, Messenger et jeux déjà présentes dans le projet.
- Les intégrations Supabase existantes nécessaires aux comptes, aux données et aux médias historiques de l’application.

## Limite importante
Cette version ne transforme pas toute la plateforme en application hors ligne. Les comptes, profils partagés, publications, conversations et certains médias existants continuent d’utiliser le backend Supabase déjà présent dans le projet. Les téléversements historiques vers les buckets existants (`profile-albums`, `post-images`, `post-media`, `chat-attachments`) ne sont pas supprimés ici, car les retirer sans remplacer leurs flux casserait des fonctions existantes.

Pour une désactivation totale de tout service distant, il faudrait une refonte distincte en mode local/offline, avec perte de la synchronisation entre membres et appareils.

## Vérifications
- La migration V24 de création des quatre buckets additionnels est absente de `site/supabase/migrations/`.
- Les notes et instructions Vercel demandant d’exécuter cette migration ont été remplacées.
- Les fichiers applicatifs et migrations Supabase historiques sont conservés.
